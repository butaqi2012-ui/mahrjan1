import React, { useState } from 'react';
import { motion } from 'motion/react';
import { CreditCard, Smartphone, X, CheckCircle, ShieldCheck } from 'lucide-react';

interface PaymentGatewayProps {
  amount: number;
  onSuccess: () => void;
  onCancel: () => void;
}

export default function PaymentGateway({ amount, onSuccess, onCancel }: PaymentGatewayProps) {
  const [method, setMethod] = useState<'card' | 'stcpay' | 'applepay'>('card');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handlePay = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    
    // Simulate payment processing
    setTimeout(() => {
      setIsProcessing(false);
      setIsSuccess(true);
      setTimeout(() => {
        onSuccess();
      }, 2000);
    }, 2500);
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm" dir="rtl">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        className="bg-white dark:bg-slate-900 w-full max-w-md rounded-[2.5rem] shadow-2xl relative overflow-hidden"
      >
        {/* Header */}
        <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-slate-50 dark:bg-slate-800/50">
          <div>
            <h3 className="text-xl font-black text-slate-900 dark:text-white">الدفع الإلكتروني</h3>
            <p className="text-sm font-bold text-slate-500 dark:text-slate-400 mt-1">بوابة دفع آمنة (نموذج تجريبي)</p>
          </div>
          <button 
            onClick={onCancel}
            disabled={isProcessing || isSuccess}
            className="p-2 bg-white dark:bg-slate-800 text-slate-400 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-700 transition disabled:opacity-50"
          >
            <X size={20} />
          </button>
        </div>

        {isSuccess ? (
          <div className="p-12 text-center">
            <motion.div 
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="w-24 h-24 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6"
            >
              <CheckCircle size={48} />
            </motion.div>
            <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-2">تم الدفع بنجاح!</h3>
            <p className="text-slate-500 dark:text-slate-400 font-bold">جاري تحويلك لإكمال التسجيل...</p>
          </div>
        ) : (
          <div className="p-6">
            {/* Amount Display */}
            <div className="bg-emerald-50 dark:bg-emerald-900/20 rounded-2xl p-6 mb-6 text-center border border-emerald-100 dark:border-emerald-800/30">
              <p className="text-emerald-600 dark:text-emerald-400 font-bold mb-1">المبلغ المطلوب</p>
              <div className="text-4xl font-black text-emerald-700 dark:text-emerald-300 flex items-center justify-center gap-2">
                {amount} <span className="text-xl">ر.س</span>
              </div>
            </div>

            {/* Payment Methods */}
            <div className="grid grid-cols-3 gap-2 mb-8">
              <button
                type="button"
                onClick={() => setMethod('card')}
                className={`p-3 rounded-xl border-2 font-bold flex flex-col items-center gap-2 transition text-xs ${method === 'card' ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400' : 'border-slate-100 dark:border-slate-800 text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'}`}
              >
                <CreditCard size={20} />
                بطاقة ائتمانية
              </button>
              <button
                type="button"
                onClick={() => setMethod('stcpay')}
                className={`p-3 rounded-xl border-2 font-bold flex flex-col items-center gap-2 transition text-xs ${method === 'stcpay' ? 'border-purple-500 bg-purple-50 dark:bg-purple-900/20 text-purple-700 dark:text-purple-400' : 'border-slate-100 dark:border-slate-800 text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'}`}
              >
                <Smartphone size={20} />
                STC Pay
              </button>
              <button
                type="button"
                onClick={() => setMethod('applepay')}
                className={`p-3 rounded-xl border-2 font-bold flex flex-col items-center gap-2 transition text-xs ${method === 'applepay' ? 'border-slate-900 bg-slate-900 text-white dark:border-white dark:bg-white dark:text-slate-900' : 'border-slate-100 dark:border-slate-800 text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'}`}
              >
                <svg viewBox="0 0 384 512" className="w-5 h-5 fill-current"><path d="M318.7 268.7c-.2-36.7 16.4-64.4 50-84.8-18.8-26.9-47.2-41.7-84.7-44.6-35.5-2.8-74.3 20.7-88.5 20.7-15 0-49.4-19.7-76.4-19.7C63.3 141.2 4 184.8 4 273.5q0 39.3 14.4 81.2c12.8 36.7 59 126.7 107.2 125.2 25.2-.6 43-17.9 75.8-17.9 31.8 0 48.3 17.9 76.4 17.9 48.6-.7 90.4-82.5 102.6-119.3-65.2-30.7-61.7-90-61.7-91.9zm-56.6-164.2c27.3-32.4 24.8-61.9 24-72.5-24.1 1.4-52 16.4-67.9 34.9-17.5 19.8-27.8 44.3-25.6 71.9 26.1 2 49.9-11.4 69.5-34.3z"/></svg>
                Apple Pay
              </button>
            </div>

            <form onSubmit={handlePay}>
              {method === 'card' && (
                <div className="space-y-4 mb-8">
                  <div>
                    <label className="block text-xs font-black text-slate-700 dark:text-slate-300 mb-2">رقم البطاقة</label>
                    <input type="text" placeholder="0000 0000 0000 0000" className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 font-mono text-left" required />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-black text-slate-700 dark:text-slate-300 mb-2">تاريخ الانتهاء</label>
                      <input type="text" placeholder="MM/YY" className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 font-mono text-left" required />
                    </div>
                    <div>
                      <label className="block text-xs font-black text-slate-700 dark:text-slate-300 mb-2">رمز التحقق (CVC)</label>
                      <input type="text" placeholder="123" className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 font-mono text-left" required />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-black text-slate-700 dark:text-slate-300 mb-2">الاسم على البطاقة</label>
                    <input type="text" placeholder="الاسم الكامل" className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 font-bold" required />
                  </div>
                </div>
              )}

              {method === 'stcpay' && (
                <div className="space-y-4 mb-8">
                  <div>
                    <label className="block text-xs font-black text-slate-700 dark:text-slate-300 mb-2">رقم الجوال (STC Pay)</label>
                    <div className="relative">
                      <input type="text" placeholder="05X XXX XXXX" className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-purple-500 font-mono text-left pl-16" required />
                      <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-sm" dir="ltr">+966</div>
                    </div>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-bold text-center mt-4">سيتم إرسال طلب دفع إلى تطبيق STC Pay الخاص بك</p>
                </div>
              )}

              {method === 'applepay' && (
                <div className="space-y-4 mb-8 text-center py-8">
                  <p className="text-sm text-slate-500 dark:text-slate-400 font-bold mb-4">انقر على الزر أدناه لإتمام الدفع عبر Apple Pay</p>
                </div>
              )}

              <button 
                type="submit" 
                disabled={isProcessing}
                className={`w-full py-4 text-white rounded-xl font-black transition shadow-lg flex items-center justify-center gap-2 ${
                  method === 'applepay' 
                    ? 'bg-slate-900 hover:bg-black shadow-slate-200 dark:bg-white dark:text-slate-900 dark:hover:bg-slate-100 dark:shadow-none' 
                    : method === 'stcpay'
                    ? 'bg-purple-600 hover:bg-purple-700 shadow-purple-100 dark:shadow-none'
                    : 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-100 dark:shadow-none'
                } disabled:opacity-50`}
              >
                {isProcessing ? (
                  <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <>
                    {method === 'applepay' ? 'دفع باستخدام Apple Pay' : `دفع ${amount} ر.س`}
                  </>
                )}
              </button>
              
              <div className="mt-4 flex items-center justify-center gap-2 text-xs font-bold text-slate-400">
                <ShieldCheck size={14} />
                <span>مدفوعات آمنة ومشفرة</span>
              </div>
            </form>
          </div>
        )}
      </motion.div>
    </div>
  );
}
