/**
 * Sibling Pricing Logic Utility
 */

export function calculateSiblingPricing(
  reg: any,
  festival: any,
  allRegistrations: any[]
): {
  individualFee: number;
  brotherIndex: number;
  totalGroupCount: number;
  siblingsList: any[];
} {
  const baseFee = Number(festival?.fees || 0);
  const siblingDiscountType = festival?.siblingDiscountType || 'none';
  const twoBrothersFees = Number(festival?.twoBrothersFees || 0);
  const threeBrothersFees = Number(festival?.threeBrothersFees || 0);

  if (siblingDiscountType === 'none') {
    return { individualFee: baseFee, brotherIndex: 0, totalGroupCount: 1, siblingsList: [] };
  }

  // Find all registrations for this festival
  const festivalRegs = allRegistrations.filter(r => r.festivalId === festival.id);

  const visited = new Set<string>();
  const siblingGroup: any[] = [];

  function dfs(currentReg: any) {
    if (!currentReg || visited.has(currentReg.id)) return;
    visited.add(currentReg.id);
    siblingGroup.push(currentReg);

    // Find direct siblings:
    festivalRegs.forEach(other => {
      if (visited.has(other.id)) return;
      
      const isSibling = 
        (currentReg.groomId && other.siblingId && currentReg.groomId === other.siblingId) ||
        (other.groomId && currentReg.siblingId && other.groomId === currentReg.siblingId) ||
        (currentReg.siblingId && other.siblingId && currentReg.siblingId === other.siblingId && currentReg.groomId !== other.groomId);

      if (isSibling) {
        dfs(other);
      }
    });
  }

  // Start DFS with the current registration
  dfs(reg);

  // Sort sibling group by createdAt to determine who is 1st, 2nd, 3rd brother
  siblingGroup.sort((a, b) => {
    const timeA = a.createdAt?.seconds 
      ? a.createdAt.seconds * 1000 
      : (a.createdAt ? new Date(a.createdAt).getTime() : 0);
    const timeB = b.createdAt?.seconds 
      ? b.createdAt.seconds * 1000 
      : (b.createdAt ? new Date(b.createdAt).getTime() : 0);
    return timeA - timeB;
  });

  const myIndex = siblingGroup.findIndex(item => item.id === reg.id);
  const totalCount = siblingGroup.length;

  // Now calculate the individual fee based on index
  let individualFee = baseFee;

  if (totalCount >= 2) {
    if (siblingDiscountType === 'second_free') {
      if (myIndex === 1) {
        individualFee = 0;
      } else {
        individualFee = baseFee;
      }
    } else if (siblingDiscountType === 'third_free') {
      if (myIndex === 2) {
        individualFee = 0;
      } else {
        individualFee = baseFee;
      }
    } else if (siblingDiscountType === 'custom_prices') {
      if (myIndex === 0) {
        individualFee = baseFee;
      } else if (myIndex === 1) {
        individualFee = Math.max(0, twoBrothersFees - baseFee);
      } else if (myIndex === 2) {
        individualFee = Math.max(0, threeBrothersFees - twoBrothersFees);
      } else {
        individualFee = baseFee;
      }
    }
  }

  return {
    individualFee,
    brotherIndex: myIndex,
    totalGroupCount: totalCount,
    siblingsList: siblingGroup.filter(item => item.id !== reg.id)
  };
}
