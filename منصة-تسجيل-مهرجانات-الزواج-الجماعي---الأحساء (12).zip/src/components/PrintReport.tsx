import React from 'react';
import { FileText, MapPin, Phone, User, Calendar, CheckCircle } from 'lucide-react';

interface Registration {
  id: string;
  festivalId: string;
  festivalName: string;
  groomName: string;
  groomId: string;
  groomPhone: string;
  groomGuardianName: string;
  groomGuardianPhone: string;
  groomGuardianRelation: string;
  brideName: string;
  brideId: string;
  bridePhone: string;
  guardianName: string;
  guardianPhone: string;
  guardianRelation: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: any;
}

interface PrintReportProps {
  registration: Registration;
}

const PrintReport: React.FC<PrintReportProps> = ({ registration }) => {
  const today = new Date().toLocaleDateString('ar-SA');
  const submissionDate = registration.createdAt?.toDate 
    ? registration.createdAt.toDate().toLocaleDateString('ar-SA') 
    : new Date().toLocaleDateString('ar-SA');

  return (
    <div className="bg-white p-10 w-[210mm] h-[297mm] mx-auto text-slate-900 font-sans leading-relaxed border-[10px] border-double border-slate-100 relative overflow-hidden" dir="rtl">
      {/* Watermark */}
      <div className="absolute inset-0 flex items-center justify-center opacity-[0.02] pointer-events-none select-none rotate-[-45deg]">
        <h1 className="text-[100px] font-black">تقرير رسمي</h1>
      </div>

      {/* Header */}
      <div className="flex justify-between items-start mb-10 border-b border-slate-300 pb-6">
        <div className="text-right space-y-1">
          <h2 className="text-lg font-black tracking-tight">المملكة العربية السعودية</h2>
          <h3 className="text-base font-bold">وزارة الموارد البشرية والتنمية الاجتماعية</h3>
          <h4 className="text-sm font-bold text-emerald-800">الجمعية الخيرية لتيسير الزواج ورعاية الأسرة</h4>
          <p className="text-[9px] font-bold text-slate-400">ترخيص رقم: (١٢٣٤)</p>
        </div>
        <div className="flex flex-col items-center">
          <img 
            src="https://www.reaayah.sa/rafed/uploads/system/cover_66ccddc5caa47.jpeg" 
            alt="Logo" 
            className="h-24 w-auto object-contain"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="text-left space-y-1">
          <p className="text-[10px] font-bold">التاريخ: {today}</p>
          <p className="text-[10px] font-bold">رقم الطلب: <span className="text-emerald-700">{registration.id}</span></p>
          <p className="text-[10px] font-bold">المرفقات: (٣) مرفقات</p>
        </div>
      </div>

      {/* Title */}
      <div className="text-center mb-8">
        <h1 className="text-2xl font-black text-slate-900 border-b-2 border-emerald-500 inline-block pb-2">نموذج طلب تسجيل في مهرجان الزواج الجماعي</h1>
        <p className="text-slate-500 font-bold mt-3 text-sm italic">إقرار وتعهد بصحة البيانات والالتزام بالشروط</p>
      </div>

      {/* Content Section */}
      <div className="space-y-6">
        {/* Festival Info */}
        <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200">
          <h5 className="text-base font-black mb-3 text-slate-800 border-r-4 border-emerald-600 pr-3">بيانات المهرجان</h5>
          <div className="grid grid-cols-2 gap-4 text-xs font-bold">
            <p className="text-slate-500">اسم المهرجان: <span className="text-slate-900">{registration.festivalName}</span></p>
            <p className="text-slate-500">تاريخ التقديم: <span className="text-slate-900">{submissionDate}</span></p>
          </div>
        </div>

        {/* Groom & Bride Info */}
        <div className="grid grid-cols-2 gap-4">
          <div className="border border-slate-100 p-5 rounded-2xl bg-white shadow-sm">
            <h5 className="text-sm font-black mb-4 flex items-center gap-2 text-emerald-800">
              <User size={16} /> بيانات الزوج (العريس)
            </h5>
            <div className="space-y-2 text-[11px] font-bold">
              <p className="text-slate-400">الاسم: <span className="text-slate-800">{registration.groomName}</span></p>
              <p className="text-slate-400">الهوية: <span className="text-slate-800">{registration.groomId}</span></p>
              <p className="text-slate-400">الجوال: <span className="text-slate-800">{registration.groomPhone}</span></p>
              <p className="text-slate-400">الممثل: <span className="text-slate-800">{registration.groomGuardianName}</span></p>
              <p className="text-slate-400">الصلة: <span className="text-slate-800">{registration.groomGuardianRelation}</span></p>
            </div>
          </div>
          <div className="border border-slate-100 p-5 rounded-2xl bg-white shadow-sm">
            <h5 className="text-sm font-black mb-4 flex items-center gap-2 text-emerald-800">
              <User size={16} /> بيانات الزوجة
            </h5>
            <div className="space-y-2 text-[11px] font-bold">
              <p className="text-slate-400">الاسم: <span className="text-slate-800">{registration.brideName}</span></p>
              <p className="text-slate-400">الهوية: <span className="text-slate-800">{registration.brideId}</span></p>
              <p className="text-slate-400">الجوال: <span className="text-slate-800">{registration.bridePhone}</span></p>
              <p className="text-slate-400">الممثل: <span className="text-slate-800">{registration.guardianName}</span></p>
              <p className="text-slate-400">الصلة: <span className="text-slate-800">{registration.guardianRelation}</span></p>
            </div>
          </div>
        </div>

        {/* Declaration */}
        <div className="bg-slate-900 text-white p-6 rounded-[2rem] relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/10 rounded-full -mr-12 -mt-12 blur-2xl"></div>
          <h5 className="text-lg font-black mb-4 flex items-center gap-2">
            <CheckCircle size={20} className="text-emerald-400" /> الإقرار والتعهد
          </h5>
          <p className="text-sm leading-relaxed font-bold text-slate-300 text-justify">
            أنا الموضح بياناتي أعلاه، أتقدم بطلبي هذا للمشاركة في <span className="text-emerald-400">"{registration.festivalName}"</span> المنظم من قبل الجمعية، وأقر بصدق ومسؤولية أن جميع البيانات والمستندات المرفقة صحيحة تماماً. كما أعلن موافقتي الكاملة على الرسوم المقررة وكافة الشروط والضوابط المنظمة للمهرجان، وأتعهد بالالتزام بها.
          </p>
        </div>

        {/* Signatures */}
        <div className="grid grid-cols-3 gap-6 pt-10">
          <div className="text-center">
            <p className="font-black text-xs text-slate-900 border-b border-slate-100 pb-2 mb-10">توقيع المتقدم</p>
            <p className="text-[10px] text-slate-300 italic">..........................</p>
          </div>
          <div className="text-center">
            <p className="font-black text-xs text-slate-900 border-b border-slate-100 pb-2 mb-4">ختم الجمعية</p>
            <div className="h-20 w-20 border-2 border-double border-slate-100 rounded-full mx-auto flex items-center justify-center">
              <div className="text-[6px] font-black text-slate-200 rotate-12">الختم الرسمي</div>
            </div>
          </div>
          <div className="text-center">
            <p className="font-black text-xs text-slate-900 border-b border-slate-100 pb-2 mb-10">اعتماد المشرف</p>
            <p className="text-[10px] text-slate-300 italic">..........................</p>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="absolute bottom-10 left-10 right-10 border-t border-slate-100 pt-5 flex justify-between items-center text-[9px] font-bold text-slate-300 uppercase tracking-widest">
        <span>المملكة العربية السعودية - المنطقة الشرقية</span>
        <span className="flex items-center gap-1"><Phone size={10} /> ٩٢٠٠٠٠٠٠٠</span>
        <span>صفحة ١ / ١</span>
      </div>
    </div>
  );
};

export default PrintReport;
