import React, { useState, useEffect } from 'react';
import { Plus, Edit, Trash2, Calendar, Clock, User, MapPin, Search, X, Check, Eye, Award, CheckCircle, XCircle } from 'lucide-react';
import { collection, addDoc, updateDoc, deleteDoc, doc, onSnapshot, setDoc } from 'firebase/firestore';
import { db, auth } from '../../firebase';
import { motion, AnimatePresence } from 'motion/react';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

const handleFirestoreError = (error: unknown, operationType: OperationType, path: string | null) => {
  const errorMessage = error instanceof Error ? error.message : String(error);
  
  const errInfo: FirestoreErrorInfo = {
    error: errorMessage,
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };

  // Handle specific "soft" errors
  if (errorMessage.includes('No document to update')) {
    console.warn('Firestore Warning (Soft): ', JSON.stringify(errInfo));
    return; // Don't throw for missing documents during updates
  }

  console.error('Firestore Error in CoursesTab: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
};

interface Course {
  id?: string;
  title: string;
  date: string;
  time: string;
  lecturer: string;
  location: string;
  heldType?: 'in_person' | 'online';
  meetingLink?: string;
  createdAt?: string;
}

interface CourseAttendance {
  id?: string;
  courseId: string;
  registrationId: string;
  groomId: string;
  groomName: string;
  isAttended: boolean;
  attended?: boolean;
  attendanceDate: string;
  markedBy?: string;
}

interface CoursesTabProps {
  registrations: any[]; // Approved and all registrations from Dashboard
  userProfile: {
    role: string;
    [key: string]: any;
  };
}

export function CoursesTab({ registrations, userProfile }: CoursesTabProps) {
  const [courses, setCourses] = useState<Course[]>([]);
  const [attendance, setAttendance] = useState<CourseAttendance[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  // Tab/View Mode: 'list' (Courses List) or 'attendance' (Marking Attendance for a course)
  const [viewMode, setViewMode] = useState<'list' | 'attendance'>('list');
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  
  // Search states
  const [courseSearch, setCourseSearch] = useState('');
  const [groomSearch, setGroomSearch] = useState('');

  // Course Form state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCourse, setEditingCourse] = useState<Course | null>(null);
  const [title, setTitle] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [lecturer, setLecturer] = useState('');
  const [location, setLocation] = useState('');
  const [heldType, setHeldType] = useState<'in_person' | 'online'>('in_person');
  const [meetingLink, setMeetingLink] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Delete confirm state
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Subscriptions to Firestore collections
  useEffect(() => {
    setIsLoading(true);
    const unsubCourses = onSnapshot(collection(db, 'courses'), (snap) => {
      const list: Course[] = [];
      snap.forEach((docSnap) => {
        list.push({ id: docSnap.id, ...docSnap.data() } as Course);
      });
      // Sort: nearest upcoming courses first
      list.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
      setCourses(list);
      setIsLoading(false);
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'courses');
    });

    const unsubAttendance = onSnapshot(collection(db, 'course_attendance'), (snap) => {
      const list: CourseAttendance[] = [];
      snap.forEach((docSnap) => {
        list.push({ id: docSnap.id, ...docSnap.data() } as CourseAttendance);
      });
      setAttendance(list);
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'course_attendance');
    });

    return () => {
      unsubCourses();
      unsubAttendance();
    };
  }, []);

  // Filter approved registrations only for attendance
  const approvedRegistrations = registrations.filter(r => r.status === 'approved');

  const openAddModal = () => {
    setEditingCourse(null);
    setTitle('');
    setDate('');
    setTime('');
    setLecturer('');
    setLocation('مقر الجمعية بالمنيزلة');
    setHeldType('in_person');
    setMeetingLink('');
    setError('');
    setIsModalOpen(true);
  };

  const openEditModal = (course: Course) => {
    setEditingCourse(course);
    setTitle(course.title);
    setDate(course.date);
    setTime(course.time);
    setLecturer(course.lecturer);
    setLocation(course.location || '');
    setHeldType(course.heldType || 'in_person');
    setMeetingLink(course.meetingLink || '');
    setError('');
    setIsModalOpen(true);
  };

  const handleCourseSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !date || !time || !lecturer) {
      setError('يرجى تعبئة جميع الحقول المطلوبة');
      return;
    }
    if (heldType === 'in_person' && !location) {
      setError('يرجى تحديد مكان ومقر التدريب للدورات الحضورية');
      return;
    }

    setIsSubmitting(true);
    setError('');

    const courseData = {
      title,
      date,
      time,
      lecturer,
      location: heldType === 'online' ? 'عن بُعد / أونلاين' : location,
      heldType,
      meetingLink: heldType === 'online' ? meetingLink : '',
      createdAt: editingCourse?.createdAt || new Date().toISOString()
    };

    try {
      if (editingCourse?.id) {
        // Edit existing
        const docRef = doc(db, 'courses', editingCourse.id);
        await updateDoc(docRef, courseData);
      } else {
        // Add new
        await addDoc(collection(db, 'courses'), courseData);
      }
      setIsModalOpen(false);
    } catch (err: any) {
      console.error('Error saving course:', err);
      setError('حدث خطأ غير متوقع أثناء حفظ بيانات الدورة');
      handleFirestoreError(err, editingCourse?.id ? OperationType.UPDATE : OperationType.CREATE, editingCourse?.id ? `courses/${editingCourse.id}` : 'courses');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteCourse = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'courses', id));
      setDeleteConfirmId(null);
    } catch (err) {
      console.error('Error deleting course:', err);
      handleFirestoreError(err, OperationType.DELETE, `courses/${id}`);
    }
  };

  const handleToggleAttendance = async (courseId: string, registration: any, isPresent: boolean) => {
    const docId = `${courseId}_${registration.id}`;
    const docRef = doc(db, 'course_attendance', docId);

    try {
      if (isPresent) {
        // Record attendance
        await setDoc(docRef, {
          courseId,
          registrationId: registration.id,
          groomId: registration.groomId || '',
          groomName: registration.groomName || registration.fullName || '',
          isAttended: true,
          attendanceDate: new Date().toISOString(),
          markedBy: auth.currentUser?.email || 'System'
        });
      } else {
        // Mark as absent (unattended) by deleting the document to ensure clean states
        await deleteDoc(docRef);
      }
    } catch (err) {
      console.error('Error updating attendance:', err);
      handleFirestoreError(err, OperationType.WRITE, `course_attendance/${docId}`);
    }
  };

  // Filter courses by search title
  const filteredCourses = courses.filter(c => 
    c.title.includes(courseSearch) || 
    c.lecturer.includes(courseSearch) ||
    c.location.includes(courseSearch)
  );

  // Filter approved newlyweds for active course attendance
  const filteredGrooms = approvedRegistrations.filter(r => {
    const name = (r.groomName || r.fullName || '').toLowerCase();
    const phone = (r.groomPhone || r.phone || '').toLowerCase();
    const nid = (r.groomId || '').toLowerCase();
    const queryStr = groomSearch.toLowerCase();
    return name.includes(queryStr) || phone.includes(queryStr) || nid.includes(queryStr);
  });

  // Calculate attendees count for each course
  const getCourseAttendeesCount = (courseId: string) => {
    return attendance.filter(a => a.courseId === courseId && (a.isAttended || a.attended)).length;
  };

  return (
    <div className="p-4 sm:p-8" id="courses-section">
      <AnimatePresence mode="wait">
        {viewMode === 'list' ? (
          <motion.div
            key="list-view"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="space-y-6"
          >
            {/* Header section */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-2xl sm:text-3xl font-black text-slate-900 mb-1">
                  الدورة التأهيلية للمقبلين على الزواج
                </h3>
                <p className="text-sm sm:text-base text-slate-500 font-bold">
                  إدارة الدورات والمحاضرات التدريبية وتحضير حضور العرسان إلكترونياً
                </p>
              </div>

              {userProfile.role === 'admin' && (
                <button
                  onClick={openAddModal}
                  className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-sm sm:text-base font-black rounded-xl transition duration-200 shadow-md shadow-emerald-200 dark:shadow-none shrink-0"
                >
                  <Plus size={16} />
                  إضافة دورة/محاضرة جديدة
                </button>
              )}
            </div>

            {/* Filter and search */}
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search size={18} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  placeholder="البحث عن دورة، محاضر، أو موقع..."
                  value={courseSearch}
                  onChange={(e) => setCourseSearch(e.target.value)}
                  className="w-full pl-4 pr-11 py-2.5 bg-slate-50 border border-slate-200/80 rounded-xl text-sm sm:text-base text-slate-800 placeholder-slate-400 font-bold focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition duration-200"
                />
                {courseSearch && (
                  <button 
                    onClick={() => setCourseSearch('')} 
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  >
                    <X size={16} />
                  </button>
                )}
              </div>
            </div>

            {/* Courses grid */}
            {isLoading ? (
              <div className="flex flex-col items-center justify-center py-20">
                <div className="w-10 h-10 border-4 border-dashed border-emerald-600 rounded-full animate-spin mb-4" />
                <span className="text-slate-400 text-sm sm:text-base font-bold">جاري تحميل الدورات واللقاءات...</span>
              </div>
            ) : filteredCourses.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 bg-slate-50 rounded-2xl border border-dashed border-slate-200 text-center">
                <Calendar size={48} className="text-slate-300 mb-3" />
                <h4 className="text-base sm:text-lg font-black text-slate-800 mb-1">لا توجد دورات مسجلة حالياً</h4>
                <p className="text-sm text-slate-400 font-bold">يمكنك إنشاء دورات وتعيين مواعيدها وضيافتها عبر الضغط على إضافة دورة جديدة.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredCourses.map((course) => {
                  const attendeesCount = getCourseAttendeesCount(course.id || '');
                  return (
                    <div 
                      key={course.id} 
                      className="bg-white rounded-2xl border border-slate-100 p-5 hover:border-emerald-100 hover:shadow-lg hover:shadow-emerald-500/[0.02] transition-all duration-200 flex flex-col justify-between"
                    >
                      <div className="space-y-3">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex flex-wrap gap-1.5">
                            <span className="inline-flex items-center gap-1 text-[10px] sm:text-xs font-black text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full">
                              <Award size={12} />
                              دورة تأهيلية معتمدة
                            </span>
                            {course.heldType === 'online' ? (
                              <span className="inline-flex items-center gap-1 text-[10px] sm:text-xs font-black text-blue-600 bg-blue-50 px-2.5 py-1 rounded-full">
                                <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse" />
                                عن بُعد (أونلاين)
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 text-[10px] sm:text-xs font-black text-amber-600 bg-amber-50 px-2.5 py-1 rounded-full">
                                <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                                حضوريًا
                              </span>
                            )}
                          </div>

                          {userProfile.role === 'admin' && (
                            <div className="flex items-center gap-1.5 opacity-80">
                              <button
                                onClick={() => openEditModal(course)}
                                className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-slate-50 rounded-lg transition"
                                title="تعديل الدورة"
                              >
                                <Edit size={14} />
                              </button>
                              
                              {deleteConfirmId === course.id ? (
                                <div className="flex items-center gap-1">
                                  <button
                                    onClick={() => handleDeleteCourse(course.id || '')}
                                    className="px-2 py-1 bg-rose-500 text-white text-[10px] font-bold rounded hover:bg-rose-600"
                                  >
                                    تأكيد حذف
                                  </button>
                                  <button
                                    onClick={() => setDeleteConfirmId(null)}
                                    className="p-1 bg-slate-100 text-slate-500 text-[10px] font-bold rounded"
                                  >
                                    إلغاء
                                  </button>
                                </div>
                              ) : (
                                <button
                                  onClick={() => setDeleteConfirmId(course.id || null)}
                                  className="p-1.5 text-slate-400 hover:text-rose-500 hover:bg-slate-50 rounded-lg transition"
                                  title="حذف الدورة"
                                >
                                  <Trash2 size={14} />
                                </button>
                              )}
                            </div>
                          )}
                        </div>

                        <h4 className="text-lg sm:text-xl font-black text-slate-900 leading-tight">
                          {course.title}
                        </h4>

                        {/* Metas */}
                        <div className="grid grid-cols-2 gap-2 text-xs text-slate-500 font-bold pt-1">
                          <div className="flex items-center gap-1.5">
                            <Calendar size={14} className="text-emerald-500 shrink-0" />
                            <span>{course.date}</span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <Clock size={14} className="text-amber-500 shrink-0" />
                            <span>{course.time}</span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <User size={14} className="text-indigo-500 shrink-0" />
                            <span className="truncate">{course.lecturer}</span>
                          </div>
                          <div className="flex items-center gap-1.5 col-span-2">
                            {course.heldType === 'online' ? (
                              <>
                                <span className="text-blue-500 text-xs font-black">🌐 المنصة:</span>
                                <span className="truncate text-slate-700 font-extrabold">{course.meetingLink || 'عن بُعد / أونلاين'}</span>
                              </>
                            ) : (
                              <>
                                <MapPin size={14} className="text-rose-500 shrink-0" />
                                <span className="truncate">{course.location}</span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between gap-4">
                        <div className="text-sm text-slate-400 font-bold">
                          المحضرين إلكترونياً: <strong className="text-slate-800 font-extrabold">{attendeesCount} عريساً</strong> / <span className="text-xs">{approvedRegistrations.length}</span>
                        </div>

                        <button
                          onClick={() => {
                            setSelectedCourse(course);
                            setViewMode('attendance');
                          }}
                          className="px-3.5 py-2 bg-slate-100 hover:bg-emerald-600 hover:text-white text-slate-700 text-xs font-black rounded-lg transition duration-200 flex items-center gap-1"
                        >
                          <CheckCircle size={14} />
                          تحضير الحضور
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </motion.div>
        ) : (
          /* Attendance verification / registration mode */
          <motion.div
            key="attendance-view"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="space-y-6"
          >
            {/* Header block with back action */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
              <div>
                <button
                  onClick={() => {
                    setViewMode('list');
                    setSelectedCourse(null);
                  }}
                  className="text-emerald-600 hover:text-emerald-700 text-xs sm:text-sm font-black mb-2 inline-flex items-center gap-1"
                >
                  &rarr; العودة لجدول الدورات
                </button>
                
                <h3 className="text-xl sm:text-2xl font-black text-slate-900 leading-tight">
                  تحضير الحضور: {selectedCourse?.title}
                </h3>
                
                <p className="text-xs text-slate-500 font-bold mt-1 flex flex-wrap gap-x-4 gap-y-1">
                  <span>المحاضر: {selectedCourse?.lecturer}</span>
                  <span>التاريخ: {selectedCourse?.date} ({selectedCourse?.time})</span>
                </p>
              </div>

              <div className="text-left py-1.5 px-3 bg-emerald-50 rounded-xl border border-emerald-100 shrink-0">
                <span className="text-[10px] text-emerald-600 font-black block">إجمالي المسجلين الحاضرين</span>
                <strong className="text-base sm:text-lg font-black text-emerald-700">
                  {getCourseAttendeesCount(selectedCourse?.id || '')} من {approvedRegistrations.length}
                </strong>
              </div>
            </div>

            {/* Groom Searcher */}
            <div className="relative">
              <Search size={18} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="ابحث باسم العريس، الهوية الوطنية، أو رقم الجوال..."
                value={groomSearch}
                onChange={(e) => setGroomSearch(e.target.value)}
                className="w-full pl-4 pr-11 py-2.5 bg-slate-50 border border-slate-200/80 rounded-xl text-xs sm:text-sm text-slate-800 placeholder-slate-400 font-bold focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition duration-200"
              />
              {groomSearch && (
                <button 
                  onClick={() => setGroomSearch('')} 
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  <X size={16} />
                </button>
              )}
            </div>

            {/* Newlyweds List */}
            {filteredGrooms.length === 0 ? (
              <div className="py-12 bg-slate-50 rounded-2xl text-center border border-dashed border-slate-200">
                <User size={36} className="text-slate-300 mx-auto mb-2" />
                <span className="text-xs sm:text-sm text-slate-500 font-bold block">لا يوجد عرسان مقبولين بالاسم المبحوث</span>
                <p className="text-[10px] text-slate-400 mt-0.5">يرجى التأكد من أن حالة الطلب للعريس "مقبول" في بوابة الطلبات ليظهر في التحضير.</p>
              </div>
            ) : (
              <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden shadow-sm">
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse text-right text-xs sm:text-sm">
                    <thead>
                      <tr className="bg-slate-50/80 text-slate-500 font-black border-b border-slate-100">
                        <th className="py-4 px-4 sm:px-6">اسم العريس</th>
                        <th className="py-4 px-3">رقم الهوية الوطنية</th>
                        <th className="py-4 px-3">رقم الجوال</th>
                        <th className="py-4 px-4 sm:px-6 text-center">إثبات حضور الدورة</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredGrooms.map((reg) => {
                        const isAttended = attendance.some(a => a.courseId === selectedCourse?.id && a.registrationId === reg.id && (a.isAttended || a.attended));
                        return (
                          <tr key={reg.id} className="hover:bg-slate-50/40 transition">
                            <td className="py-4 px-4 sm:px-6">
                              <span className="block font-black text-slate-900">{reg.groomName || reg.fullName}</span>
                              <span className="text-[10px] text-slate-400 font-bold block mt-0.5">طلب رقم: {reg.id}</span>
                            </td>
                            <td className="py-4 px-3 font-mono font-bold text-slate-600">{reg.groomId}</td>
                            <td className="py-4 px-3 font-mono font-bold text-slate-600">{reg.groomPhone}</td>
                            <td className="py-4 px-4 sm:px-6 text-center">
                              {isAttended ? (
                                <div className="inline-flex items-center gap-2">
                                  <span className="inline-flex items-center gap-1 text-[10px] sm:text-xs font-black text-emerald-700 bg-emerald-50 border border-emerald-100 px-3 py-1.5 rounded-full">
                                    <Check size={12} strokeWidth={3} />
                                    تم إثبات الحضور
                                  </span>
                                  
                                  {userProfile.role === 'admin' && (
                                    <button
                                      onClick={() => handleToggleAttendance(selectedCourse?.id || '', reg, false)}
                                      className="p-1 px-2.5 text-rose-500 hover:bg-rose-50 rounded-lg text-[10px] font-black border border-rose-100 transition"
                                    >
                                      إلغاء التحضير
                                    </button>
                                  )}
                                </div>
                              ) : (
                                <>
                                  {userProfile.role === 'admin' && (
                                    <button
                                      onClick={() => handleToggleAttendance(selectedCourse?.id || '', reg, true)}
                                      className="inline-flex items-center gap-1.5 px-4 py-1.5 bg-slate-100 hover:bg-emerald-600 hover:text-white text-slate-700 text-[10px] sm:text-xs font-black rounded-full transition duration-200/50"
                                    >
                                      <CheckCircle size={12} />
                                      تحضير الآن
                                    </button>
                                  )}
                                </>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Course Add/Edit Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-[2rem] w-full max-w-lg border border-slate-100 overflow-hidden shadow-2xl"
            >
              {/* Modal header */}
              <div className="relative p-6 sm:p-8 bg-slate-50 border-b border-slate-100">
                <button
                  onClick={() => setIsModalOpen(false)}
                  className="absolute left-6 top-6 sm:top-8 text-slate-400 hover:text-slate-600 bg-white p-1 rounded-full border border-slate-100 transition shadow"
                >
                  <X size={16} />
                </button>
                <h4 className="text-lg sm:text-xl font-black text-slate-900">
                  {editingCourse ? 'تعديل بيانات الدورة' : 'إضافة دورة/محاضرة تدريبية'}
                </h4>
                <p className="text-xs text-slate-400 font-bold mt-1">المقبلين على الزواج - فرع المنيزلة</p>
              </div>

              {/* Modal body & Form */}
              <form onSubmit={handleCourseSubmit} className="p-6 sm:p-8 space-y-4">
                {error && (
                  <div className="p-3 bg-rose-50 text-rose-600 text-xs font-bold rounded-xl flex items-center gap-2">
                    <XCircle size={16} />
                    <span>{error}</span>
                  </div>
                )}

                <div className="space-y-1">
                  <label className="text-xs font-black text-slate-700">عنوان الدورة أو المحاضرة *</label>
                  <input
                    type="text"
                    required
                    placeholder="مثل: أسس العلاقة الزوجية الناجحة"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-black text-slate-700">تاريخ اللقاء *</label>
                    <input
                      type="date"
                      required
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-black text-slate-700">الوقت والزمن *</label>
                    <input
                      type="text"
                      required
                      placeholder="مثل: 05:30 مساءً"
                      value={time}
                      onChange={(e) => setTime(e.target.value)}
                      className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-black text-slate-700">فضيلة المحاضر/المدرب *</label>
                  <input
                    type="text"
                    required
                    placeholder="مثل: الشيخ د. بندر الراجح"
                    value={lecturer}
                    onChange={(e) => setLecturer(e.target.value)}
                    className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-black text-slate-700">طريقة إقامة الدورة *</label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setHeldType('in_person')}
                      className={`py-2 px-4 rounded-xl border text-xs sm:text-sm font-black transition text-center ${
                        heldType === 'in_person'
                          ? 'border-emerald-600 bg-emerald-50 text-emerald-700'
                          : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      📍 حضوريًا
                    </button>
                    <button
                      type="button"
                      onClick={() => setHeldType('online')}
                      className={`py-2 px-4 rounded-xl border text-xs sm:text-sm font-black transition text-center ${
                        heldType === 'online'
                          ? 'border-blue-600 bg-blue-50 text-blue-700'
                          : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      🌐 عن بُعد / أونلاين
                    </button>
                  </div>
                </div>

                {heldType === 'in_person' ? (
                  <div className="space-y-1">
                    <label className="text-xs font-black text-slate-700">مكان ومقر التدريب *</label>
                    <input
                      type="text"
                      required
                      placeholder="مثال: مقر الجمعية بالمنيزلة"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                    />
                  </div>
                ) : (
                  <div className="space-y-1">
                    <label className="text-xs font-black text-slate-700">رابط اللقاء أو اسم المنصة المضيفة *</label>
                    <input
                      type="text"
                      required
                      placeholder="مثال: منصة زووم (سيتم إرسال رابط الدخول قبل الموعد)"
                      value={meetingLink}
                      onChange={(e) => setMeetingLink(e.target.value)}
                      className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                    />
                  </div>
                )}

                {/* Modal footer */}
                <div className="flex justify-end gap-2 pt-4 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-4 py-2 border border-slate-200 text-slate-500 text-xs sm:text-sm font-black rounded-xl hover:bg-slate-50"
                  >
                    إلغاء
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-5 py-2 bg-emerald-600 text-white text-xs sm:text-sm font-black rounded-xl hover:bg-emerald-700 shadow transition disabled:opacity-50"
                  >
                    {isSubmitting ? 'جاري الحفظ...' : 'حفظ البيانات'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
