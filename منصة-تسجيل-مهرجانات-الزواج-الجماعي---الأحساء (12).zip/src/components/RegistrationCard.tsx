import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Eye, Printer, Edit, History, Trash2, Phone, Send, MessageCircle, Users } from 'lucide-react';
import { format } from 'date-fns';
import { motion, AnimatePresence } from 'motion/react';
import { updateDoc, doc } from 'firebase/firestore';
import { db } from '../firebase';
import { notifyAdminsAndSupervisor } from '../utils/notifications';

interface RegistrationCardProps {
  registration: any;
  selected: boolean;
  onToggleSelect: (id: string) => void;
  onUpdateStatus: (id: string, status: string, name: string) => void;
  onUpdateStep: (id: string, step: number) => void;
  userProfile: any;
  festivals: any[];
  onViewDetails: (r: any) => void;
  onPrint: (r: any) => void;
  onEdit: (r: any) => void;
  onShowLogs: (id: string) => void;
  onWhatsAppReminder: (reg: any) => void;
  onEmailReminder: (reg: any) => void;
}

export const RegistrationCard: React.FC<RegistrationCardProps> = ({
  registration,
  selected,
  onToggleSelect,
  onUpdateStatus,
  onUpdateStep,
  userProfile,
  festivals,
  onViewDetails,
  onPrint,
  onEdit,
  onShowLogs,
  onWhatsAppReminder,
  onEmailReminder,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const r = registration;

  return (
    <div className={`bg-white p-4 rounded-[2rem] border transition-all duration-300 ${selected ? 'border-emerald-500 ring-4 ring-emerald-50 shadow-lg' : 'border-slate-100 shadow-sm'}`}>
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="relative">
            <input 
              type="checkbox" 
              className="w-5 h-5 text-emerald-600 rounded-lg border-slate-200 focus:ring-emerald-500/20 cursor-pointer transition-all" 
              checked={selected} 
              onChange={() => onToggleSelect(r.id)} 
            />
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <h4 className="font-black text-slate-900 text-sm leading-tight mb-1">{r.groomName}</h4>
              {r.hasSibling && (
                <div className="flex items-center gap-1 bg-emerald-50 text-emerald-600 text-[9px] font-black px-2 py-0.5 rounded-md border border-emerald-200/50" title="طلب عائلي مترابط">
                  <Users size={10} />
                </div>
              )}
            </div>
            <div className="flex items-center gap-1.5 font-mono text-[11px] font-bold text-slate-400">
              <span>{r.groomId}</span>
              <div className="w-1 h-1 bg-slate-200 rounded-full" />
              <span>{r.groomPhone}</span>
            </div>
          </div>
        </div>
        <div className="flex flex-col items-end gap-1">
          {r.paymentStatus === 'paid' && (
            <span className="bg-emerald-50 text-emerald-700 text-[10px] font-black px-2 py-1 rounded-full border border-emerald-100">تم السداد</span>
          )}
          {r.paymentStatus === 'pending_verification' && (
            <span className="bg-amber-50 text-amber-700 text-[10px] font-black px-2 py-1 rounded-full border border-amber-100 animate-pulse">قيد التحقق</span>
          )}
          {r.paymentStatus === 'pending' && (
            <span className="bg-slate-50 text-slate-500 text-[10px] font-black px-2 py-1 rounded-full border border-slate-100">بانتظار السداد</span>
          )}
          {r.paymentStatus === 'rejected' && (
            <span className="bg-rose-50 text-rose-700 text-[10px] font-black px-2 py-1 rounded-full border border-rose-100">وصل مرفوض</span>
          )}
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="bg-slate-50/50 p-2.5 rounded-2xl border border-slate-100/50">
          <span className="block text-xs text-slate-400 font-black uppercase tracking-wider mb-1">المهرجان</span>
          <span className="block text-xs font-black text-slate-700 truncate">{r.festivalName}</span>
        </div>
        <div className="bg-slate-50/50 p-2.5 rounded-2xl border border-slate-100/50">
          <span className="block text-xs text-slate-400 font-black uppercase tracking-wider mb-1">تاريخ التسجيل</span>
          <span className="block text-xs font-black text-slate-700 tracking-tight">
            {r.createdAt?.toDate ? format(r.createdAt.toDate(), 'yyyy/MM/dd') : '-'}
          </span>
        </div>
      </div>
      
      <div className="space-y-3 mb-4">
        <div className="flex items-center justify-between gap-3">
          <span className="text-sm font-black text-slate-400">الحالة:</span>
          <div className="flex-1 relative">
            <select 
              value={r.status} 
              onChange={(e) => onUpdateStatus(r.id, e.target.value, r.groomName)}
              className={`w-full text-sm font-black rounded-xl px-3 py-1.5 border-none focus:ring-2 focus:ring-offset-1 transition-all appearance-none ${
                r.status === 'approved' ? 'bg-emerald-50 text-emerald-700 focus:ring-emerald-500/20' : 
                r.status === 'rejected' ? 'bg-rose-50 text-rose-700 focus:ring-rose-500/20' : 
                r.status === 'needs_info' ? 'bg-amber-50 text-amber-700 focus:ring-amber-500/20' : 
                'bg-blue-50 text-blue-700 focus:ring-blue-500/20'
              }`}
            >
              <option value="pending">قيد الدراسة</option>
              <option value="needs_info">نقص بيانات</option>
              <option value="approved">مقبول</option>
              <option value="rejected">مرفوض</option>
            </select>
          </div>
        </div>
        
        <div className="flex items-center justify-between gap-3">
          <span className="text-sm font-black text-slate-400">المرحلة:</span>
          <div className="flex-1 relative">
            <select 
              value={r.currentStep || 0} 
              onChange={(e) => onUpdateStep(r.id, Number(e.target.value))}
              className="w-full text-sm font-black rounded-xl px-3 py-1.5 border border-slate-100 bg-white text-slate-700 focus:ring-2 focus:ring-offset-1 focus:ring-slate-100 transition-all appearance-none shadow-sm"
            >
              {r.status === 'approved' ? (
                <option value={3}>الموافقة النهائية</option>
              ) : (r.status === 'pending' || r.status === 'needs_info') ? (
                <>
                  <option value={0}>استلام الطلب</option>
                  <option value={1}>تدقيق الطلب</option>
                  <option value={2}>مراجعة السداد</option>
                </>
              ) : (
                <>
                  <option value={0}>استلام الطلب</option>
                  <option value={1}>تدقيق الطلب</option>
                  <option value={2}>مراجعة السداد</option>
                  <option value={3}>الموافقة النهائية</option>
                </>
              )}
            </select>
          </div>
        </div>
      </div>

      <div className="flex gap-2">
        <button 
          onClick={() => onViewDetails(r)}
          className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-slate-900 text-white rounded-xl text-sm font-black hover:bg-slate-800 transition-all shadow-lg shadow-slate-200 active:scale-95"
        >
          <Eye size={14} /> عرض التفاصيل
        </button>
        <button 
          onClick={() => setIsExpanded(!isExpanded)}
          className={`px-3 flex items-center justify-center rounded-xl border transition-all ${isExpanded ? 'bg-slate-100 border-slate-200 text-slate-900' : 'bg-white border-slate-100 text-slate-400'}`}
        >
          {isExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
        </button>
      </div>

      <AnimatePresence>
        {isExpanded && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="mt-4 pt-4 border-t border-slate-100 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-slate-400 tracking-wider uppercase">أدوات إضافية:</span>
                <div className="flex items-center gap-2">
                  <button onClick={() => onPrint(r)} className="p-2 bg-slate-50 text-slate-600 rounded-xl hover:bg-slate-100 transition-colors" title="طباعة">
                    <Printer size={16} />
                  </button>
                  <button onClick={() => onEdit(r)} className="p-2 bg-slate-50 text-slate-600 rounded-xl hover:bg-slate-100 transition-colors" title="تعديل">
                    <Edit size={16} />
                  </button>
                  {(userProfile.role === 'admin' || userProfile.role === 'supervisor') && (
                    <button onClick={() => onShowLogs(r.id)} className="p-2 bg-slate-50 text-slate-600 rounded-xl hover:bg-slate-100 transition-colors" title="السجل">
                      <History size={16} />
                    </button>
                  )}
                </div>
              </div>
              
              <div className="flex items-center justify-between bg-emerald-50/50 p-3 rounded-2xl border border-emerald-100/50">
                <span className="text-xs font-black text-emerald-700">تواصل سريع:</span>
                <div className="flex items-center gap-3">
                  <button 
                    onClick={() => onWhatsAppReminder(r)} 
                    className="flex items-center gap-1.5 text-emerald-600 font-black text-xs"
                  >
                    <MessageCircle size={14} /> واتساب
                  </button>
                  <div className="w-px h-3 bg-emerald-200" />
                  <button 
                    onClick={() => onEmailReminder(r)} 
                    className="flex items-center gap-1.5 text-blue-600 font-black text-xs"
                  >
                    <Send size={14} /> بريد
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
