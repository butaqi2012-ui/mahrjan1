import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User, 
  Phone, 
  LogOut, 
  CheckCircle, 
  Clock, 
  XCircle, 
  AlertCircle,
  Download,
  Edit3,
  Star,
  MessageSquare,
  Send,
  CreditCard,
  Search,
  X,
  Eye,
  History,
  Calendar,
  Hash,
  Gift,
  Tag,
  Copy,
  ExternalLink,
  MapPin,
  Award,
  Printer,
  BookOpen
} from 'lucide-react';
import { collection, query, where, getDocs, doc, getDoc, limit, updateDoc, onSnapshot } from 'firebase/firestore';
import { db, auth } from '../firebase';
import { compressImage } from '../utils/image';
import { notifyAdminsAndSupervisor } from '../utils/notifications';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

const handleFirestoreError = (error: unknown, operationType: OperationType, path: string | null) => {
  const errorMessage = error instanceof Error ? error.message : String(error);
  
  const errInfo: FirestoreErrorInfo = {
    error: errorMessage,
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }

  // Handle specific "soft" errors
  if (errorMessage.includes('No document to update')) {
    console.warn('Firestore Warning (Soft): ', JSON.stringify(errInfo));
    return; // Don't throw for missing documents during updates
  }

  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

interface GroomPortalProps {
  onClose: () => void;
  siteSettings: any;
  festivals?: any[];
  onEditRequest: (registration: any) => void;
  quotaExceeded?: boolean;
}

function RegistrationProgressBar({ registration }: { registration: any }) {
  const steps = [
    { 
      label: 'استلام الطلب', 
      desc: 'تم استلام بيانات طلبك الأولي بنجاح وتوثيقه في النظام لمطابقة الفرز الأول.', 
      icon: Send 
    },
    { 
      label: 'تدقيق الطلب', 
      desc: 'مراجعة وتدقيق المرفقات والهويات والتحقق من موافقة الاشتراطات الفنية.', 
      icon: Search 
    },
    { 
      label: 'مراجعة السداد', 
      desc: 'فحص إيصال التحويل، توافق البيانات المالية مع الحساب البنكي للمؤسسة وتأكيده.', 
      icon: CreditCard 
    },
    { 
      label: 'الموافقة النهائية', 
      desc: 'الاعتماد الكلي للطلب وإضافته رسمياً لقوائم المستفيدين المعتمدة بالمهرجان.', 
      icon: CheckCircle 
    },
  ];

  const isFullyCompleted = registration.status === 'approved' && registration.paymentStatus === 'paid';
  
  let currentStep = typeof registration.currentStep === 'number' ? registration.currentStep : 0;
  if (isFullyCompleted) {
    currentStep = 3;
  } else if (typeof registration.currentStep !== 'number') {
    if (registration.status === 'pending') {
      currentStep = 1;
    } else if (registration.status === 'approved') {
      currentStep = 2; // Default to payment review if approved but not marked paid
    } else if (registration.status === 'needs_info') {
      currentStep = 1;
    }
  }

  let completionPercentage = 25;
  if (isFullyCompleted) {
    completionPercentage = 100;
  } else {
    if (currentStep === 0) completionPercentage = 25;
    else if (currentStep === 1) completionPercentage = 50;
    else if (currentStep === 2) completionPercentage = 75;
    else if (currentStep === 3) completionPercentage = 90; // Approved but awaiting payment verification/clearing
  }

  const activeStepObj = steps[currentStep] || steps[0];

  return (
    <div className="space-y-8 mt-6">
      {/* Visual Stepper Progress Bar */}
      <div className="relative flex justify-between items-center px-4 sm:px-8">
        {/* Background Line */}
        <div className="absolute top-1/2 left-0 w-full h-1 bg-slate-100 dark:bg-slate-755 -translate-y-1/2 z-0 rounded-full" />
        
        {/* Progress Line */}
        <motion.div 
          initial={{ width: 0 }}
          animate={{ width: `${((isFullyCompleted ? 3 : currentStep) / (steps.length - 1)) * 100}%` }}
          className="absolute top-1/2 left-0 h-1 bg-gradient-to-l from-emerald-500 to-emerald-400 -translate-y-1/2 z-0 rounded-full"
          transition={{ duration: 0.5, ease: 'easeOut' }}
        />

        {steps.map((step, index) => {
          const Icon = step.icon;
          const isCompleted = isFullyCompleted || index < currentStep;
          const isActive = isFullyCompleted || index <= currentStep;
          const isCurrent = !isFullyCompleted && index === currentStep;

          return (
            <div key={`step-${index}`} className="relative z-10 flex flex-col items-center">
              <motion.div 
                initial={false}
                animate={{ 
                  backgroundColor: isCurrent 
                    ? 'rgb(16, 185, 129)' 
                    : isCompleted 
                      ? 'rgba(16, 185, 129, 0.9)' 
                      : 'rgb(241, 245, 249)',
                  borderColor: isCurrent 
                    ? 'rgb(248, 250, 252)' 
                    : isCompleted 
                      ? 'rgb(248, 250, 252)' 
                      : 'rgb(255, 255, 255)',
                  scale: isCurrent ? 1.15 : 1
                }}
                className={`w-11 h-11 rounded-full flex items-center justify-center shadow-lg border-4 ${
                  isActive 
                    ? 'border-emerald-100 dark:border-emerald-950/40 text-white' 
                    : 'border-white dark:border-slate-800 text-slate-400 dark:text-slate-600'
                }`}
              >
                {isCompleted ? (
                  <CheckCircle size={18} className="stroke-[3]" />
                ) : (
                  <Icon size={16} className={isCurrent ? 'animate-pulse stroke-[2.5]' : 'stroke-[2]'} />
                )}
              </motion.div>
              <span className={`absolute -bottom-8 whitespace-nowrap text-[10px] sm:text-xs font-black tracking-tight ${
                isCurrent 
                  ? 'text-emerald-600 dark:text-emerald-400 scale-105' 
                  : isCompleted 
                    ? 'text-emerald-500/80 dark:text-emerald-450' 
                    : 'text-slate-400 dark:text-slate-600'
              }`}>
                {step.label}
              </span>
            </div>
          );
        })}
      </div>

      {registration.status === 'needs_info' && registration.deficiencies && registration.deficiencies.length > 0 && (
        <div className="bg-amber-50 dark:bg-amber-900/20 p-6 rounded-3xl border border-amber-100 dark:border-amber-800/50 mt-12">
          <h4 className="font-black text-amber-700 dark:text-amber-300 text-sm mb-4">نواقص الطلب المطلوب إكمالها:</h4>
          <ul className="list-disc list-inside space-y-2">
            {registration.deficiencies.map((def: string, i: number) => (
              <li key={i} className="text-amber-800 dark:text-amber-200 text-sm font-bold">{def}</li>
            ))}
          </ul>
        </div>
      )}

      {/* Detailed Status Breakdown Card */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-12 bg-slate-50/50 dark:bg-slate-900/10 p-6 rounded-3xl border border-slate-100 dark:border-slate-850">
        {/* Left column: Current Stage Analysis */}
        <div className="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-slate-100 dark:border-slate-755/60 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className={`w-2.5 h-2.5 rounded-full bg-emerald-500 ${isFullyCompleted ? '' : 'animate-ping'}`} />
              <h4 className="text-xs font-black text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">
                {isFullyCompleted ? 'حالة الطلب النهائية' : 'المرحلة الحالية قيد المعالجة'}
              </h4>
            </div>
            <h3 className="text-base font-black text-slate-900 dark:text-white mb-2">
              {isFullyCompleted ? 'تمت الموافقة النهائية واعتماد السداد' : activeStepObj.label}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed font-semibold">
              {isFullyCompleted 
                ? 'تهانينا! تم قبول طلبك واعتماده بشكل كلي من قبل إدارة المهرجان بعد مطابقة سداد الرسوم. نتمنى لك حياة زوجية سعيدة ومباركة.'
                : registration.status === 'needs_info' && currentStep === 1 
                  ? 'لقد طلبت منك الإدارة تحديث بعض المرفقات أو البيانات غير الواضحة. يرجى الضغط على زر "تحديث البيانات" وتعديلها لتسريع المعاملة.' 
                  : activeStepObj.desc}
            </p>
          </div>

          <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-700/50 flex items-center justify-between">
            <span className="text-[10px] font-black text-slate-400">معدل الإنجاز العام للطلب</span>
            <span className="text-xs font-sans font-black text-emerald-600 dark:text-emerald-455">{completionPercentage}%</span>
          </div>
        </div>

        {/* Right column: Target / Remaining Checklists */}
        <div className="space-y-4">
          <h4 className="text-xs font-black text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-2">تفصيل خطوات معالجة الطلب</h4>
          <div className="space-y-3">
            {steps.map((step, index) => {
              const isDone = isFullyCompleted || index < currentStep;
              const isCurrent = !isFullyCompleted && index === currentStep;
              
              let stateIcon = null;
              let itemClass = '';
              
              if (isDone) {
                stateIcon = <CheckCircle size={14} className="text-emerald-500 shrink-0" />;
                itemClass = 'line-through text-slate-400 dark:text-slate-650';
              } else if (isCurrent) {
                stateIcon = <Clock size={14} className="text-emerald-500 animate-spin shrink-0" style={{ animationDuration: '3s' }} />;
                itemClass = 'font-bold text-slate-800 dark:text-slate-200 bg-white dark:bg-slate-800 border-l-4 border-l-emerald-500 shadow-sm p-2 rounded-xl';
              } else {
                stateIcon = <div className="w-3.5 h-3.5 rounded-full border border-slate-300 dark:border-slate-700 shrink-0" />;
                itemClass = 'text-slate-450 dark:text-slate-500';
              }

              return (
                <div key={`chk-${index}`} className={`flex items-start gap-2.5 text-xs transition duration-200 ${itemClass}`}>
                  <div className="mt-0.5">{stateIcon}</div>
                  <div className="flex-1">
                    <span className="font-extrabold block text-[11px]">{step.label}</span>
                    {isCurrent && (
                      <span className="text-[10px] text-slate-400 block mt-0.5 font-bold">بانتظار استكمال هذه المرحلة للعبور للمراحل التالية</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

function BankDetail({ label, value, isMono = false }: { label: string; value: string; isMono?: boolean }) {
  return (
    <div className="flex justify-between items-center bg-white dark:bg-slate-800 p-3 rounded-xl border border-slate-100 dark:border-slate-700">
      <span className="text-[10px] font-bold text-slate-400">{label}</span>
      <span className={`text-[10px] font-black text-slate-700 dark:text-slate-200 ${isMono ? 'font-mono' : ''}`}>{value}</span>
    </div>
  );
}

function FileText({ size, className }: { size: number; className?: string }) {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
      <polyline points="14 2 14 8 20 8" />
      <line x1="16" y1="13" x2="8" y2="13" />
      <line x1="16" y1="17" x2="8" y2="17" />
      <line x1="10" y1="9" x2="8" y2="9" />
    </svg>
  );
}

const getStatusLabelText = (status: string) => {
  switch (status) {
    case 'pending': return 'قيد الدراسة والمراجعة';
    case 'approved': return 'مقبول';
    case 'needs_info': return 'نحتاج معلومات إضافية';
    case 'rejected': return 'مرفوض';
    case 'paid': return 'تم السداد المعتمد';
    case 'pending_verification': return 'قيد تدقيق السداد وتحقق المالية';
    case 'unpaid': return 'في انتظار السداد';
    default: return status || '---';
  }
};

const getLogEventDetails = (log: any) => {
  const action = log.action || '';
  let title = action;
  let description = '';

  const oldValText = getStatusLabelText(log.oldValue);
  const newValText = getStatusLabelText(log.newValue);

  if (action === 'تغيير حالة الطلب' || action === 'تغيير حالة الطلب (جماعي)') {
    title = 'تحديث حالة الطلب';
    description = `تم تعديل حالة طلبك من [${oldValText}] إلى [${newValText}]`;
  } else if (action === 'تغيير حالة السداد' || action === 'تأكيد السداد (جماعي)') {
    title = 'تحديث حالة السداد والرسوم';
    description = `بناءً على الفحص المالي، تم تحديث حالة سداد الرسوم من [${oldValText}] إلى [${newValText}]`;
  } else if (action === 'تغيير مرحلة الطلب') {
    title = 'تحديث خطة تتبع الطلب';
    const phaseLabels = ['إرسال الطلب', 'تدقيق البيانات المرفقة', 'مراجعة السداد والرسوم', 'الموافقة والاعتماد النهائي'];
    const oldPhaseIndex = parseInt(log.oldValue);
    const newPhaseIndex = parseInt(log.newValue);
    const oldPhase = !isNaN(oldPhaseIndex) && phaseLabels[oldPhaseIndex] ? phaseLabels[oldPhaseIndex] : `المرحلة ${log.oldValue}`;
    const newPhase = !isNaN(newPhaseIndex) && phaseLabels[newPhaseIndex] ? phaseLabels[newPhaseIndex] : `المرحلة ${log.newValue}`;
    description = `انتقل الطلب بنجاح من مرحلة [${oldPhase}] إلى مرحلة [${newPhase}]`;
  } else if (action === 'رفض الطلب') {
    title = 'عدم قبول الطلب';
    description = `نعتذر، لم يتم قبول طلبكم للإدارة حالياً وذلك بناءً على نواقص في الأوراق أو الملاحظات المرفقة بالطلب.`;
  } else if (action === 'تأكيد السداد (جماعي)') {
    title = 'اعتماد سداد الرسوم';
    description = `تم اعتماد وتأكيد إيصال سداد الرسوم لطلبكم بنجاح ومطابقته لدى الحسابات.`;
  } else {
    description = `تمت ترقية حالة السجل من [${oldValText}] إلى [${newValText}]`;
  }

  return { title, description };
};

export default function GroomPortal({ onClose, siteSettings, festivals = [], onEditRequest, quotaExceeded }: GroomPortalProps) {
  const [groomId, setGroomId] = useState('');
  const [groomPhone, setGroomIdPhone] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [registration, setRegistration] = useState<any | null>(null);
  const [activeTab, setActiveTab] = useState<'status' | 'evaluation' | 'payment' | 'offers' | 'courses'>('status');
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [vendorQuery, setVendorQuery] = useState<string>('');
  const [isUpdating, setIsUpdating] = useState(false);
  const [evaluation, setEvaluation] = useState({ rating: 0, comment: '' });
  const [festivalEval, setFestivalEval] = useState({ rating: 0, comment: '' });
  const [viewingAttachment, setViewingAttachment] = useState<{url: string, type: string, name: string} | null>(null);
  const [paymentReceipt, setPaymentReceipt] = useState<{ name: string; file?: File; preview: string; type?: string; size?: number } | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<'online' | 'transfer'>('transfer');
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [vendors, setVendors] = useState<any[]>([]);
  const [showOffersTabSetting, setShowOffersTabSetting] = useState(true);
  const [showCoursesTabSetting, setShowCoursesTabSetting] = useState(true);
  const [courses, setCourses] = useState<any[]>([]);
  const [attendance, setAttendance] = useState<any[]>([]);
  const [selectedCourseForCert, setSelectedCourseForCert] = useState<any | null>(null);
  const [showPaymentSuccessModal, setShowPaymentSuccessModal] = useState(false);
  const [isReplacingExistingReceipt, setIsReplacingExistingReceipt] = useState(false);
  const [showEvalPromptModal, setShowEvalPromptModal] = useState(false);

  // Prompt evaluation if payment is paid and evaluation is not done yet
  useEffect(() => {
    if (registration?.paymentStatus === 'paid' && (!registration?.evaluation || !registration?.evaluation?.rating)) {
      const alreadyShown = localStorage.getItem(`eval_prompt_${registration.id}`);
      if (!alreadyShown) {
        setShowEvalPromptModal(true);
      }
    } else {
      setShowEvalPromptModal(false);
    }
  }, [registration?.paymentStatus, registration?.id, registration?.evaluation]);

  // Listen to courses and attendance
  useEffect(() => {
    if (!registration?.id || quotaExceeded) return;

    // Subscribe to courses
    const unsubscribeCourses = onSnapshot(collection(db, 'courses'), (snapshot) => {
      const list = snapshot.docs.map(docSnap => ({ id: docSnap.id, ...docSnap.data() }));
      list.sort((a: any, b: any) => b.date?.localeCompare(a.date || '') || 0);
      setCourses(list);
    }, (err) => {
      console.error('Error listing courses: ', err);
    });

    // Subscribe to attendance for this registrationId
    const attendanceQuery = query(collection(db, 'course_attendance'), where('registrationId', '==', registration.id));
    const unsubscribeAttendance = onSnapshot(attendanceQuery, (snapshot) => {
      const list = snapshot.docs.map(docSnap => ({ id: docSnap.id, ...docSnap.data() }));
      setAttendance(list);
    }, (err) => {
      console.error('Error listing attendance: ', err);
    });

    return () => {
      unsubscribeCourses();
      unsubscribeAttendance();
    }
  }, [registration?.id]);

  // Listen to the registration document itself for live updates (e.g., payment status)
  useEffect(() => {
    if (!registration?.id || quotaExceeded) return;

    const unsubscribe = onSnapshot(doc(db, 'registrations', registration.id), (docSnap) => {
      if (docSnap.exists()) {
        const newData = { id: docSnap.id, ...docSnap.data() };
        // Only update if something changed to avoid unnecessary re-renders
        // We use a simple JSON string comparison for brevity here as it's a small object
        setRegistration((prev: any) => {
          if (JSON.stringify(prev) !== JSON.stringify(newData)) {
            return newData;
          }
          return prev;
        });
      }
    }, (err) => {
      console.error('Error listening to registration:', err);
    });

    return () => unsubscribe();
  }, [registration?.id]);

  // Listen to global settings for showOffersTab
  useEffect(() => {
    if (quotaExceeded) return;
    const unsubscribe = onSnapshot(doc(db, 'settings', 'global'), (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        setShowOffersTabSetting(data.showOffersTab !== false);
        setShowCoursesTabSetting(data.showCoursesTab !== false);
      }
    }, (err) => {
      console.error('Error listening to settings:', err);
    });
    return () => unsubscribe();
  }, []);

  // Listen to vendors list
  useEffect(() => {
    if (quotaExceeded) return;
    const unsubscribe = onSnapshot(collection(db, 'vendors'), (snapshot) => {
      let list: any[] = snapshot.docs.map(docSnap => ({ id: docSnap.id, ...docSnap.data() }));
      list.sort((a: any, b: any) => b.createdAt?.localeCompare(a.createdAt || '') || 0);

      if (snapshot.empty) {
        const DEFAULT_VENDORS = [
          {
            id: 'v1',
            name: 'قصر الأوركيد للأفراح والاحتفالات',
            category: 'halls',
            categoryLabel: 'قاعات الأفراح',
            discount: '25% خصم',
            desc: 'حسم خاص وحصري على حجز القاعات الكبرى وتجهيز طاولات الملكة مع باقة الضيافة وعصائر الترحيب المجانية.',
            code: 'ORCHID25',
            phone: '0501234567',
            address: 'الرياض - حي الياسمين'
          },
          {
            id: 'v2',
            name: 'مفروشات المطلق الفاخرة',
            category: 'furniture',
            categoryLabel: 'الأثاث والأجهزة الكهربائية',
            discount: '30% خصم',
            desc: 'خصومات حصرية على جميع أطقم غرف النوم الكاملة والمجالس الكلاسيكية الفاخرة مع التوصيل والتركيب المجاني.',
            code: 'MUTLAQ30',
            phone: '0502345678',
            address: 'الدمام - طريق الملك فهد'
          },
          {
            id: 'v3',
            name: 'استوديو زوايا الفنية للتصوير والإنتاج',
            category: 'photography',
            categoryLabel: 'استوديوهات التصوير',
            discount: '40% خصم',
            desc: 'باقة التصوير المتكاملة للزوجين (جلسة تصوير خارجية + ألبوم ديجيتال فاخر + تصوير سينمائي 4K احترافي).',
            code: 'ZAWAYA40',
            phone: '0503456789',
            address: 'جدة - شارع التحلية'
          },
          {
            id: 'v4',
            name: 'مطابخ الرياض والضيافة العربية',
            category: 'catering',
            categoryLabel: 'المطابخ والضيافة',
            discount: '15% خصم',
            desc: 'تجهيز ولائم المناسبات بأسعار مخفضة وتقديم بوفيه حلى ترحيبي مجانًا عند حجز وجبات لـ 100 شخص فأكثر.',
            code: 'DIYAF15',
            phone: '0554567890',
            address: 'القصيم - بريدة'
          },
          {
            id: 'v5',
            name: 'فندق هيلتون هوني مون ريزورت',
            category: 'hotels',
            categoryLabel: 'فنادق وشهر العسل',
            discount: '20% خصم',
            desc: 'إقامة فاخرة شاملة جناح خاص لشهر العسل، بوفيه الإفطار الصباحي، خدمة تزيين الجناح بالورد وسلة فواكه طبيعية.',
            code: 'HILTONHONEY',
            phone: '0505678901',
            address: 'جدة - طريق الكورنيش'
          }
        ];
        setVendors(DEFAULT_VENDORS);
      } else {
        setVendors(list);
      }
    }, (err) => {
      console.error('Error listening to vendors in portal:', err);
    });
    return () => unsubscribe();
  }, []);

  // Listen to registration real-time changes
  useEffect(() => {
    if (!registration?.id || quotaExceeded) return;

    const docRef = doc(db, 'registrations', registration.id);
    const unsubscribe = onSnapshot(docRef, (docSnap) => {
      if (docSnap.exists()) {
        setRegistration({ id: docSnap.id, ...docSnap.data() });
      }
    }, (err) => {
      console.error('Error listening to registration details:', err);
      handleFirestoreError(err, OperationType.GET, `registrations/${registration.id}`);
    });

    return () => unsubscribe();
  }, [registration?.id ? registration.id : '']);

  // Listen to audit logs real-time changes
  useEffect(() => {
    if (!registration?.id || quotaExceeded) {
      if (!registration?.id) setAuditLogs([]);
      return;
    }

    const q = query(
      collection(db, 'audit_logs'),
      where('registrationId', '==', registration.id)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const logs = snapshot.docs.map(docSnap => ({ id: docSnap.id, ...docSnap.data() }));
      setAuditLogs(logs);
    }, (err) => {
      console.error('Error listening to audit logs:', err);
      handleFirestoreError(err, OperationType.LIST, `audit_logs?registrationId=${registration.id}`);
    });

    return () => unsubscribe();
  }, [registration?.id ? registration.id : '']);

  const handleCopyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => {
      setCopiedCode(null);
    }, 2000);
  };

  const handleReceiptChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const maxSizeBytes = (siteSettings?.maxFileSizeMB || 5) * 1024 * 1024;
    if (file.size > maxSizeBytes) {
      alert(`المرفق يتجاوز الحد المسموح (${siteSettings?.maxFileSizeMB || 5} ميجابايت)`);
      return;
    }

    try {
      let preview = '';
      if (file.type.includes('image')) {
        preview = await compressImage(file);
      } else {
        preview = await new Promise((resolve) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result as string);
          reader.readAsDataURL(file);
        });
      }

      setPaymentReceipt({ 
        name: file.name, 
        file, 
        preview, 
        type: file.type,
        size: file.size
      });
    } catch (err) {
      console.error('File operation error:', err);
      alert('حدث خطأ أثناء معالجة الملف');
    }
  };

  const handlePaymentSubmit = async () => {
    if (!registration) return;

    setIsUpdating(true);
    try {
      const docRef = doc(db, 'registrations', registration.id);
      const updateData: any = {
        paymentMethod,
        paymentStatus: paymentMethod === 'online' ? 'paid' : 'pending_verification',
        updatedAt: new Date().toISOString()
      };

      if (paymentMethod === 'transfer' && paymentReceipt) {
        updateData.paymentReceipt = {
          name: paymentReceipt.name,
          url: paymentReceipt.preview,
          type: paymentReceipt.type || paymentReceipt.file?.type || 'application/octet-stream'
        };
      }

      await updateDoc(docRef, updateData);
      setRegistration({ ...registration, ...updateData });
      setPaymentReceipt(null);
      setIsReplacingExistingReceipt(false);

      // Notify admins and supervisor
      if (updateData.paymentStatus === 'pending_verification') {
        const message = `تم تقديم طلب سداد جديد لطلب العريس: ${registration.groomName || 'غير معروف'}`;
        await notifyAdminsAndSupervisor(
          registration.festivalId,
          registration.festivalName,
          message,
          'payment_submitted',
          registration.id,
          registration.supervisorId
        );
      }

      setShowPaymentSuccessModal(true);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `registrations/${registration.id}`);
    } finally {
      setIsUpdating(false);
    }
  };

  const handleSubmitEvaluation = async () => {
    if (!registration || evaluation.rating === 0) return;

    setIsUpdating(true);
    try {
      const docRef = doc(db, 'registrations', registration.id);
      const evalData = {
        ...evaluation,
        createdAt: new Date().toISOString()
      };
      await updateDoc(docRef, { evaluation: evalData });
      setRegistration({ ...registration, evaluation: evalData });
      alert('شكراً لك على تقييمك!');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `registrations/${registration.id}`);
    } finally {
      setIsUpdating(false);
    }
  };

  const handleSubmitFestivalEvaluation = async () => {
    if (!registration || festivalEval.rating === 0) return;

    setIsUpdating(true);
    try {
      const docRef = doc(db, 'registrations', registration.id);
      const festivalEvalData = {
        ...festivalEval,
        createdAt: new Date().toISOString()
      };
      await updateDoc(docRef, { festivalEvaluation: festivalEvalData });
      setRegistration({ ...registration, festivalEvaluation: festivalEvalData });
      alert('شكراً لك على تقييمك للمهرجان!');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `registrations/${registration.id}`);
    } finally {
      setIsUpdating(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!groomId || !groomPhone) {
      setError('يرجى إدخال رقم الهوية ورقم الجوال');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      const currentYear = new Date().getFullYear();
      const yearsToTry = [currentYear, currentYear - 1, currentYear - 2];
      let foundDoc = null;

      for (const year of yearsToTry) {
        try {
          const docId = `${year}-${groomId}`;
          const docRef = doc(db, 'registrations', docId);
          const docSnap = await getDoc(docRef);
          
          if (docSnap.exists()) {
            const data = docSnap.data();
            if (data.groomPhone === groomPhone) {
              foundDoc = { id: docSnap.id, ...data };
              break;
            }
          }
        } catch (e) {
          console.log(`Direct lookup for ${year}-${groomId} failed, falling back to query`);
        }
      }

      if (!foundDoc) {
        const q = query(
          collection(db, 'registrations'), 
          where('groomId', '==', groomId),
          where('groomPhone', '==', groomPhone),
          limit(1)
        );
        const snapshot = await getDocs(q);
        
        if (!snapshot.empty) {
          foundDoc = { id: snapshot.docs[0].id, ...snapshot.docs[0].data() };
        }
      }

      if (!foundDoc) {
        setError('بيانات الدخول غير صحيحة أو لا يوجد طلب مسجل بهذه البيانات.');
      } else {
        setRegistration(foundDoc);
      }
    } catch (err: any) {
      console.error('Error logging in groom:', err);
      if (err.message?.includes('permission')) {
        setError('عذراً، لا تملك الصلاحيات الكافية للوصول إلى هذه البيانات.');
      } else {
        setError('حدث خطأ أثناء تسجيل الدخول. يرجى المحاولة مرة أخرى.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = () => {
    setRegistration(null);
    setGroomId('');
    setGroomIdPhone('');
  };

  const currentFestival = festivals.find(f => f.id === registration?.festivalId);
  const festivalFees = currentFestival?.fees || siteSettings.festivalFees;

  if (!registration) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-900 flex items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white dark:bg-slate-800 p-8 rounded-3xl shadow-xl w-full max-w-md border border-slate-100 dark:border-slate-700"
        >
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <User size={32} />
            </div>
            <h2 className="text-2xl font-black text-slate-900 dark:text-white">بوابة العرسان</h2>
            <p className="text-slate-500 dark:text-slate-400 mt-2 font-bold text-sm">تسجيل الدخول لمتابعة طلبك</p>
          </div>

          {error && (
            <div className="mb-6 p-4 bg-red-50 dark:bg-red-900/20 border border-red-100 dark:border-red-800/30 text-red-600 dark:text-red-400 rounded-xl flex items-center gap-3 text-sm font-bold">
              <AlertCircle size={18} />
              {error}
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-5">
            <div>
              <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">رقم الهوية</label>
              <div className="relative">
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-slate-400">
                  <User size={18} />
                </div>
                <input
                  type="text"
                  value={groomId}
                  onChange={(e) => setGroomId(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl py-3 pl-4 pr-10 text-slate-900 dark:text-white font-bold focus:ring-2 focus:ring-emerald-500 outline-none transition"
                  placeholder="أدخل رقم الهوية (10 أرقام)"
                  maxLength={10}
                  dir="ltr"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-700 dark:text-slate-300 mb-2">رقم الجوال</label>
              <div className="relative">
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-slate-400">
                  <Phone size={18} />
                </div>
                <input
                  type="text"
                  value={groomPhone}
                  onChange={(e) => setGroomIdPhone(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl py-3 pl-4 pr-10 text-slate-900 dark:text-white font-bold focus:ring-2 focus:ring-emerald-500 outline-none transition"
                  placeholder="05xxxxxxxx"
                  maxLength={10}
                  dir="ltr"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black py-3 rounded-xl transition shadow-lg shadow-emerald-200 dark:shadow-emerald-900/20 disabled:opacity-70"
            >
              {isLoading ? 'جاري التحقق...' : 'دخول'}
            </button>
            
            <button
              type="button"
              onClick={onClose}
              className="w-full bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 font-bold py-3 rounded-xl transition"
            >
              العودة للرئيسية
            </button>
          </form>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 p-4 sm:p-8">
      <div className="max-w-6xl mx-auto">
        <div className="bg-emerald-600 dark:bg-emerald-950/45 p-6 sm:p-4 md:p-8 text-white relative flex-shrink-0 rounded-3xl shadow-lg border border-emerald-550/10 dark:border-emerald-500/20 mb-8 flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6 overflow-hidden group">
          {/* Decorative background patterns */}
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -mr-8 -mt-8 transition-transform duration-500 group-hover:scale-125 pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/5 rounded-full -ml-8 -mb-8 transition-transform duration-500 group-hover:scale-125 pointer-events-none" />

          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 w-full lg:w-auto relative z-10">
            <div className="w-14 h-14 bg-white/20 text-white rounded-2xl flex items-center justify-center shrink-0 shadow-inner">
              <User size={28} />
            </div>
            <div className="space-y-1.5 flex-1 min-w-0">
              <h1 className="text-xl sm:text-2xl font-black text-white truncate">مرحباً، {registration.groomName}</h1>
              <p className="text-emerald-100/90 font-black text-sm">بوابة العرسان - {registration.festivalName}</p>
              
              {/* Persistent Glassmorphic Info-Strip */}
              <div className="flex flex-wrap items-center gap-x-4 gap-y-2 mt-4 p-3 sm:px-4 sm:py-3 bg-white/10 dark:bg-black/20 backdrop-blur-md border border-white/15 dark:border-white/5 rounded-2xl text-white text-xs font-semibold shadow-inner">
                <div className="flex items-center gap-2">
                  <Hash size={13} className="text-emerald-200 shrink-0" />
                  <span className="text-emerald-100 font-bold opacity-90">رقم الطلب:</span>
                  <span className="font-mono font-black text-white bg-white/20 px-2 py-0.5 rounded-lg text-[10px] tracking-wide shadow-sm">{registration.id}</span>
                </div>
                <div className="hidden sm:block w-px h-4 bg-white/20" />
                <div className="flex items-center gap-2">
                  <Calendar size={13} className="text-emerald-200 shrink-0" />
                  <span className="text-emerald-100 font-bold opacity-90">تاريخ التسجيل:</span>
                  <span className="font-black text-white">
                    {registration.createdAt?.toDate 
                      ? new Date(registration.createdAt.toDate()).toLocaleDateString('ar-SA') 
                      : (registration.createdAt ? new Date(registration.createdAt).toLocaleDateString('ar-SA') : 'غير متوفر')}
                  </span>
                </div>
                <div className="hidden sm:block w-px h-4 bg-white/20" />
                <div className="flex items-center gap-2">
                  <Phone size={13} className="text-emerald-200 shrink-0" />
                  <span className="text-emerald-100 font-bold opacity-90">رقم الجوال:</span>
                  <span className="font-mono font-black text-white dir-ltr">{registration.groomPhone}</span>
                </div>
              </div>
            </div>
          </div>
          <button 
            onClick={handleLogout}
            className="relative z-10 flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl font-bold border border-white/10 transition shrink-0 shadow-sm"
          >
            <LogOut size={18} />
            تسجيل خروج
          </button>
        </div>

        {/* Tabs */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:flex lg:flex-row lg:flex-nowrap lg:items-stretch gap-2.5 mb-8 w-full">
          <button 
            onClick={() => setActiveTab('status')}
            className={`flex items-center justify-center lg:justify-start gap-2 px-4 py-3 rounded-2xl font-black text-xs sm:text-sm transition-all duration-200 lg:flex-1 whitespace-nowrap ${activeTab === 'status' ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-200 dark:shadow-emerald-900/20' : 'bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-400 border border-slate-100 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700'}`}
          >
            <Clock size={16} />
            حالة الطلب
          </button>
          
          {registration.status === 'approved' && registration.paymentStatus === 'paid' && showOffersTabSetting && (
            <button 
              onClick={() => setActiveTab('offers')}
              className={`flex items-center justify-center lg:justify-start gap-2 px-4 py-3 rounded-2xl font-black text-xs sm:text-sm transition-all duration-200 lg:flex-1 whitespace-nowrap ${activeTab === 'offers' ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-200 dark:shadow-emerald-900/20' : 'bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-400 border border-slate-100 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700'}`}
            >
              <Gift size={16} className="animate-pulse text-rose-500 dark:text-rose-400" />
              عروض وخصومات مميزة لكم
            </button>
          )}

          {(registration.status === 'approved' || registration.status === 'pending') && (
            <button 
              onClick={() => setActiveTab('payment')}
              className={`flex items-center justify-center lg:justify-start gap-2 px-4 py-3 rounded-2xl font-black text-xs sm:text-sm transition-all duration-200 lg:flex-1 whitespace-nowrap ${activeTab === 'payment' ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-200 dark:shadow-emerald-900/20' : 'bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-400 border border-slate-100 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700'}`}
            >
              <CreditCard size={16} />
              بيانات السداد
            </button>
          )}

          {registration.status === 'approved' && registration.paymentStatus === 'paid' && (
            <button 
              onClick={() => setActiveTab('evaluation')}
              className={`flex items-center justify-center lg:justify-start gap-2 px-4 py-3 rounded-2xl font-black text-xs sm:text-sm transition-all duration-200 lg:flex-1 whitespace-nowrap ${activeTab === 'evaluation' ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-200 dark:shadow-emerald-900/20' : 'bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-400 border border-slate-100 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700'}`}
            >
              <Star size={16} />
              تقييم الخدمة
            </button>
          )}

          {showCoursesTabSetting && (
            <button 
              onClick={() => setActiveTab('courses')}
              className={`flex items-center justify-center lg:justify-start gap-2 px-4 py-3 rounded-2xl font-black text-xs sm:text-sm transition-all duration-200 lg:flex-1 whitespace-nowrap ${activeTab === 'courses' ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-200 dark:shadow-emerald-900/20' : 'bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-400 border border-slate-100 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700'}`}
            >
              <Award size={16} className="text-amber-500 animate-bounce" />
              الدورة التأهيلية والشهادات
            </button>
          )}
        </div>

        <div className="space-y-8">
          {activeTab === 'status' && (
            <>
              {/* Rejection Alert */}
              {registration.status === 'rejected' && (
                <motion.div 
                  initial={{ opacity: 0, y: -20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-red-50 dark:bg-red-900/20 border-2 border-red-200 dark:border-red-900/30 rounded-3xl p-6 sm:p-8 relative overflow-hidden mb-4"
                >
                  <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
                    <XCircle size={120} />
                  </div>
                  <div className="flex flex-col sm:flex-row items-start gap-4 sm:gap-6 relative z-10">
                    <div className="w-14 h-14 bg-red-100 dark:bg-red-900/40 text-red-600 dark:text-red-400 rounded-2xl flex items-center justify-center shrink-0 shadow-sm">
                      <XCircle size={32} />
                    </div>
                    <div className="flex-1">
                      <h4 className="text-xl font-black text-red-900 dark:text-red-200 mb-2 mt-1">عذراً، طلبك يحتاج إلى إجراء</h4>
                      <p className="text-sm font-bold text-red-700/80 dark:text-red-300/80 mb-5 leading-relaxed">
                        نحيطكم علماً بأنه قد تم رفض الطلب حالياً لوجود ملاحظات تتطلب التصحيح. يرجى الاطلاع على سبب الرفض المذكور أدناه، والقيام بتعديل الطلب وإعادة إرساله ليتمكن المشرف من مراجعته مرة أخرى.
                      </p>
                      
                      <div className="bg-white/60 dark:bg-black/30 p-5 rounded-2xl border border-red-100 dark:border-red-900/20 mb-6 group">
                        <div className="flex items-center gap-2 mb-2 text-red-600 dark:text-red-400">
                          <AlertCircle size={16} />
                          <span className="text-xs font-black uppercase tracking-wider">سبب الرفض والملاحظات</span>
                        </div>
                        <p className="text-base font-bold text-slate-800 dark:text-slate-100 leading-relaxed italic">
                          {registration.rejectionReason || 'لم يتم تحديد سبب محدد، يرجى مراجعة كافة البيانات والمرفقات والتأكد من وضوحها.'}
                        </p>
                      </div>

                      <div className="flex flex-wrap gap-3">
                        <button 
                          onClick={() => onEditRequest(registration)}
                          className="px-8 py-3.5 bg-red-600 hover:bg-red-700 text-white rounded-2xl font-black transition-all flex items-center gap-2 shadow-xl shadow-red-200 dark:shadow-none hover:scale-[1.02] active:scale-[0.98]"
                        >
                          <Edit3 size={18} />
                          تعديل الطلب وإعادة الإرسال
                        </button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              <div className="bg-white dark:bg-slate-800 p-8 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-700">
                <div className="flex justify-between items-center mb-8">
                  <div className="flex items-center gap-3">
                    <div className="w-1.5 h-6 bg-emerald-500 rounded-full" />
                    <h3 className="text-lg font-black text-slate-900 dark:text-white">حالة الطلب</h3>
                  </div>
                  <div className={`px-4 py-1.5 rounded-full text-[10px] font-black ${
                    registration.paymentStatus === 'paid' ? 'bg-emerald-100 text-emerald-700' :
                    registration.paymentStatus === 'rejected' ? 'bg-red-100 text-red-700' :
                    registration.paymentStatus === 'pending_verification' ? 'bg-amber-100 text-amber-700' :
                    'bg-slate-100 text-slate-500'
                  }`}>
                    {registration.paymentStatus === 'paid' ? 'تم سداد الرسوم' :
                     registration.paymentStatus === 'rejected' ? 'مرفوض وصل السداد' :
                     registration.paymentStatus === 'pending_verification' ? 'قيد مراجعة السداد' :
                     'في انتظار السداد'}
                  </div>
                </div>
                
                {/* 1. Request Status Section */}
                <div className="mb-10">
                  {registration.attachments && registration.attachments.length > 0 && (
                    <div className="mb-6 overflow-x-auto pb-2 scrollbar-hide">
                      <div className="flex items-center gap-3">
                        {registration.attachments.map((att: any, i: number) => (
                          <div key={att.id || `att-${i}`} className="flex-shrink-0 group">
                            <button 
                              onClick={() => setViewingAttachment(att)}
                              className="flex items-center gap-2 px-4 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-slate-700 rounded-xl hover:bg-emerald-50 dark:hover:bg-emerald-900/20 hover:border-emerald-200 transition group-hover:shadow-md"
                            >
                              <div className="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-800 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                                <Eye size={16} />
                              </div>
                              <div className="text-right">
                                <p className="text-[10px] font-black text-slate-800 dark:text-slate-200 truncate max-w-[100px]">{att.name}</p>
                                <p className="text-[8px] font-bold text-slate-400">عرض المرفق</p>
                              </div>
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  <div className="flex items-center gap-4 p-6 rounded-2xl border-2 border-dashed border-slate-200 dark:border-slate-700">
                    {registration.status === 'pending' && (
                      <>
                        <div className="w-12 h-12 bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 rounded-full flex items-center justify-center shrink-0">
                          <Clock size={24} />
                        </div>
                        <div>
                          <h4 className="text-lg font-black text-amber-600 dark:text-amber-400">قيد المراجعة والدراسة</h4>
                          <p className="text-slate-500 dark:text-slate-400 font-bold text-sm mt-1">طلبك قيد المراجعة من قبل إدارة المهرجان. سيتم إشعارك فور تحديث الحالة.</p>
                        </div>
                      </>
                    )}
                    {registration.status === 'approved' && (
                      <>
                        <div className={`w-12 h-12 ${registration.paymentStatus === 'paid' ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400' : 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400'} rounded-full flex items-center justify-center shrink-0`}>
                          <CheckCircle size={24} />
                        </div>
                        <div>
                          <h4 className="text-lg font-black text-emerald-600 dark:text-emerald-400">
                            {registration.paymentStatus === 'paid' ? 'تم اعتماد السداد' : 'تم القبول'}
                          </h4>
                          <p className="text-slate-500 dark:text-slate-400 font-bold text-sm mt-1">
                            {registration.paymentStatus === 'paid' ? (
                              <>
                                ألف مبروك انضمامك للمهرجان. وبإمكانك التواصل معنا لأي استفسار.
                              </>
                            ) : (
                              <>
                                مبارك! تم قبول طلبك للانضمام في المهرجان. <span className="text-amber-600 font-black">بقي سداد الرسوم</span>
                              </>
                            )}
                          </p>
                        </div>
                      </>
                    )}
                    {registration.status === 'needs_info' && (
                      <>
                        <div className="w-12 h-12 bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 rounded-full flex items-center justify-center shrink-0">
                          <AlertCircle size={24} />
                        </div>
                        <div>
                          <h4 className="text-lg font-black text-amber-600 dark:text-amber-400">نحتاج إلى بيانات إضافية</h4>
                          <p className="text-slate-500 dark:text-slate-400 font-bold text-sm mt-1">يرجى تعديل البيانات بناءً على ملاحظات الإدارة.</p>
                        </div>
                      </>
                    )}
                    {registration.status === 'rejected' && (
                      <>
                        <div className="w-12 h-12 bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 rounded-full flex items-center justify-center shrink-0">
                          <XCircle size={24} />
                        </div>
                        <div>
                          <h4 className="text-lg font-black text-red-600 dark:text-red-400">نعتذر، لم يتم القبول</h4>
                          <p className="text-slate-500 dark:text-slate-400 font-bold text-sm mt-1">
                            {registration.rejectionReason || 'نعتذر لعدم قبول طلبك في الوقت الحالي.'}
                          </p>
                        </div>
                      </>
                    )}
                  </div>
                </div>

                {/* 2. Request Phase Section */}
                {registration.status !== 'rejected' && (
                  <div className="pt-8 border-t border-slate-50 dark:border-slate-700/50">
                    <p className="text-center text-[10px] font-black text-slate-400 mb-8">مرحلة الطلب</p>
                    <RegistrationProgressBar registration={registration} />
                  </div>
                )}

                {(registration.status === 'pending' || registration.status === 'rejected') && (
                  <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-800/30 p-6 rounded-2xl flex items-start gap-4">
                    <AlertCircle size={24} className="text-blue-600 dark:text-blue-400 shrink-0 mt-1" />
                    <div>
                      <h4 className="font-black text-blue-900 dark:text-blue-300 mb-2">تحديث البيانات</h4>
                      <p className="text-blue-700 dark:text-blue-400 font-bold text-sm mb-4">
                        {registration.status === 'rejected' 
                          ? 'يمكنك تحديث بياناتك واستكمال النواقص بناءً على ملاحظات الإدارة وإعادة إرسال الطلب.'
                          : 'يمكنك تحديث بياناتك أو استكمال النواقص طالما أن طلبك لا يزال قيد المراجعة.'}
                      </p>
                      <button 
                        onClick={() => onEditRequest(registration)}
                        className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold transition shadow-md"
                      >
                        <Edit3 size={16} />
                        تعديل بيانات الطلب
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Detailed Progress and Admin Notes Tracking vertical timeline */}
              {(() => {
                const historyEvents: any[] = [];

                // 1. Add audit logs
                if (auditLogs && auditLogs.length > 0) {
                  auditLogs.forEach(log => {
                    const parsedTimestamp = log.createdAt?.toDate ? log.createdAt.toDate() : (log.createdAt?.seconds ? new Date(log.createdAt.seconds * 1000) : (log.createdAt ? new Date(log.createdAt) : null));
                    if (!parsedTimestamp) return;

                    const { title, description } = getLogEventDetails(log);
                    historyEvents.push({
                      id: log.id,
                      timestamp: parsedTimestamp,
                      title,
                      description,
                      type: 'audit',
                      raw: log
                    });
                  });
                }

                // 2. Add administrative notes
                if (registration.internalNotes && registration.internalNotes.length > 0) {
                  registration.internalNotes.forEach((note: any, idx: number) => {
                    const parsedTimestamp = note.createdAt?.toDate ? note.createdAt.toDate() : (note.createdAt?.seconds ? new Date(note.createdAt.seconds * 1000) : (note.createdAt ? new Date(note.createdAt) : null));
                    if (!parsedTimestamp) return;

                    let title = 'توجيه / ملاحظة إدارية';
                    let description = note.text;
                    if (note.type === 'task') {
                      title = 'مهمة عمل مطلوب استكمالها';
                      description = `الإجراء المطلوب: ${note.text}`;
                    }

                    historyEvents.push({
                      id: note.id || `note-${idx}`,
                      timestamp: parsedTimestamp,
                      title,
                      description,
                      status: note.status,
                      type: 'note',
                      raw: note
                    });
                  });
                }

                // 3. System created timestamp
                const initialTimestamp = registration.createdAt?.toDate ? registration.createdAt.toDate() : (registration.createdAt?.seconds ? new Date(registration.createdAt.seconds * 1000) : (registration.createdAt ? new Date(registration.createdAt) : new Date(Date.now() - 86400000)));
                historyEvents.push({
                  id: 'initial-registration',
                  timestamp: initialTimestamp,
                  title: 'تسجيل وإرسال الطلب بنجاح',
                  description: 'تم استقبال بيانات طلبك الأولي وبدء مرحلة المراجعة وفرز المستندات بموجب قواعد المهرجان.',
                  type: 'system'
                });

                // Sort all events by timestamp descending
                historyEvents.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());

                const getEventIcon = (event: any) => {
                  if (event.type === 'system') {
                    return <Send size={12} />;
                  }
                  if (event.type === 'note') {
                    if (event.raw?.type === 'task') {
                      return <Clock size={12} />;
                    }
                    return <MessageSquare size={12} />;
                  }
                  if (event.raw?.action === 'رفض الطلب') {
                    return <XCircle size={12} />;
                  }
                  if (event.raw?.newValue === 'approved' || event.raw?.newValue === 'paid') {
                    return <CheckCircle size={12} />;
                  }
                  return <Clock size={12} />;
                };

                return (
                  <div className="bg-white dark:bg-slate-800 p-8 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-700">
                    <div className="flex items-center gap-3 mb-8">
                      <div className="w-12 h-12 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-2xl flex items-center justify-center shrink-0 shadow-sm">
                        <History size={22} />
                      </div>
                      <div>
                        <h3 className="text-lg font-black text-slate-900 dark:text-white">مسار وحركات تتبع حالة الطلب</h3>
                        <p className="text-xs font-bold text-slate-400 mt-1">عرض زمني فوري يوضح المعالجات والملاحظات المدونة على طلبك مع التحديثات الإدارية أولاً بأول</p>
                      </div>
                    </div>

                    <div className="relative border-r-2 border-slate-100 dark:border-slate-850 pr-6 mr-3 space-y-6">
                      {historyEvents.map((event, index) => {
                        let indicatorClass = '';
                        if (event.type === 'system') {
                          indicatorClass = 'bg-emerald-500 text-white border-emerald-100 dark:border-emerald-950/40 shadow-sm shadow-emerald-100 dark:shadow-none';
                        } else if (event.type === 'note') {
                          if (event.raw?.type === 'task') {
                            indicatorClass = event.status === 'completed'
                              ? 'bg-emerald-500 text-white border-emerald-100 dark:border-emerald-950/40'
                              : 'bg-amber-500 text-white border-amber-100 dark:border-amber-950/40 shadow-sm shadow-amber-100 dark:shadow-none';
                          } else {
                            indicatorClass = 'bg-indigo-500 text-white border-indigo-100 dark:border-indigo-950/40 shadow-sm shadow-indigo-100 dark:shadow-none';
                          }
                        } else {
                          if (event.raw?.action === 'رفض الطلب') {
                            indicatorClass = 'bg-red-500 text-white border-red-100 dark:border-red-950/40 shadow-sm shadow-red-100/30 dark:shadow-none';
                          } else if (event.raw?.newValue === 'approved' || event.raw?.newValue === 'paid') {
                            indicatorClass = 'bg-emerald-500 text-white border-emerald-100 dark:border-emerald-950/40 shadow-sm shadow-emerald-100 dark:shadow-none';
                          } else if (event.raw?.newValue === 'needs_info') {
                            indicatorClass = 'bg-amber-500 text-white border-amber-100 dark:border-amber-950/40 shadow-sm shadow-amber-100/20 dark:shadow-none';
                          } else {
                            indicatorClass = 'bg-slate-400 text-white border-slate-100 dark:border-slate-800';
                          }
                        }

                        return (
                          <div key={event.id || `event-${index}`} className="relative">
                            {index < historyEvents.length - 1 && (
                              <div className="absolute -right-[33px] top-8 w-0.5 h-full bg-slate-100 dark:bg-slate-800/80 animate-pulse" />
                            )}

                            <div className={`absolute -right-[37px] top-1.5 w-7 h-7 rounded-full border-4 flex items-center justify-center z-10 ${indicatorClass}`}>
                              {getEventIcon(event)}
                            </div>

                            <div className="bg-slate-50 dark:bg-slate-900/30 p-5 rounded-2xl border border-slate-100 dark:border-slate-850 hover:border-emerald-500/20 dark:hover:border-emerald-500/20 transition duration-300">
                              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 mb-2">
                                <span className="text-xs font-black text-slate-800 dark:text-slate-100 flex items-center gap-1.5 font-sans">
                                  {event.title}
                                  {event.raw?.type === 'task' && (
                                    <span className={`px-2 py-0.5 rounded-full text-[8px] font-black ${
                                      event.raw.status === 'completed' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400' : 'bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400'
                                    }`}>
                                      {event.raw.status === 'completed' ? 'مكتمل' : 'معلق'}
                                    </span>
                                  )}
                                </span>
                                <span className="text-[10px] font-bold text-slate-450 dir-ltr text-right">
                                  {event.timestamp.toLocaleString('ar-SA', { 
                                    year: 'numeric', 
                                    month: '2-digit', 
                                    day: '2-digit', 
                                    hour: '2-digit', 
                                    minute: '2-digit',
                                    hour12: true 
                                  })}
                                </span>
                              </div>
                              <p className="text-slate-600 dark:text-slate-400 font-bold text-[11px] leading-relaxed">
                                {event.description}
                              </p>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })()}
            </>
          )}

          {activeTab === 'payment' && (
            <div className="bg-white dark:bg-slate-800 p-8 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-700">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-2xl flex items-center justify-center">
                    <CreditCard size={24} />
                  </div>
                  <div>
                    <h3 className="text-xl font-black text-slate-900 dark:text-white">بيانات السداد</h3>
                    <div className="mt-1 flex flex-col gap-1">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider">رسوم التسجيل المعتمدة:</span>
                        <span className="px-2 py-0.5 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 rounded-lg text-xs font-black border border-emerald-100 dark:border-emerald-800/60">
                          {registration.calculatedFees !== undefined ? registration.calculatedFees : (festivalFees || '---')} ريال
                        </span>
                      </div>
                      {registration.hasSibling && (
                        <div className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold bg-emerald-50/50 dark:bg-emerald-950/20 px-2 py-1 rounded-lg border border-emerald-100 dark:border-emerald-900/40 inline-flex items-center gap-1 self-start">
                          👥 الأخ المسجل: {registration.siblingName} ({registration.siblingId})
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                
                <div className={`px-4 py-2 rounded-xl text-xs font-black flex items-center gap-2 ${
                  registration.paymentStatus === 'paid' ? 'bg-emerald-100 text-emerald-700' :
                  registration.paymentStatus === 'pending_verification' ? 'bg-amber-100 text-amber-700' :
                  registration.paymentStatus === 'rejected' ? 'bg-red-100 text-red-700' :
                  'bg-slate-100 text-slate-600'
                }`}>
                  {registration.paymentStatus === 'paid' ? <CheckCircle size={14} /> : 
                   registration.paymentStatus === 'pending_verification' ? <Clock size={14} /> : 
                   <AlertCircle size={14} />}
                  {registration.paymentStatus === 'paid' ? 'تم قبول السداد' :
                   registration.paymentStatus === 'pending_verification' ? 'قيد المراجعة والتدقيق' :
                   registration.paymentStatus === 'rejected' ? 'إيصال مرفوض' :
                   'في انتظار السداد'}
                </div>
              </div>

              {registration.paymentStatus === 'paid' ? (
                <div className="bg-emerald-50 dark:bg-emerald-900/20 border-2 border-emerald-100 dark:border-emerald-800 p-10 rounded-[2.5rem] text-center">
                  <div className="w-24 h-24 bg-emerald-500 text-white rounded-full flex items-center justify-center mx-auto mb-6 shadow-xl shadow-emerald-200 dark:shadow-none">
                    <CheckCircle size={48} />
                  </div>
                  <h4 className="text-2xl font-black text-slate-900 dark:text-white mb-3">تم قبول السداد وتأكيد طلبك!</h4>
                  <p className="text-slate-600 dark:text-slate-400 font-bold max-w-sm mx-auto">لقد تم التحقق من عملية السداد بنجاح ومطابقتها مع الحساب البنكي.</p>
                  
                  {registration.paymentReceipt && (
                    <div className="mt-8 pt-8 border-t border-emerald-100 dark:border-emerald-800">
                      <p className="text-[10px] font-black text-emerald-600 mb-4 opacity-60">نسخة من إيصالك المعتمد</p>
                      <div className="w-32 h-32 mx-auto rounded-2xl overflow-hidden border-4 border-white dark:border-slate-800 shadow-md">
                        {registration.paymentReceipt.type?.includes('pdf') ? (
                          <div className="w-full h-full bg-white flex items-center justify-center text-slate-400">
                            <FileText size={40} />
                          </div>
                        ) : (
                          <img src={registration.paymentReceipt.url} alt="receipt" className="w-full h-full object-cover" />
                        )}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="space-y-8">
                  {registration.paymentStatus === 'rejected' && (
                    <motion.div 
                      initial={{ opacity: 0, x: -10 }} 
                      animate={{ opacity: 1, x: 0 }}
                      className="p-5 bg-red-50 dark:bg-red-900/20 border-2 border-red-100 dark:border-red-800 rounded-3xl flex items-start gap-4"
                    >
                      <div className="w-12 h-12 bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 rounded-2xl flex items-center justify-center shrink-0">
                        <AlertCircle size={24} />
                      </div>
                      <div>
                        <h4 className="font-black text-red-700 dark:text-red-400 mb-1">تم رفض إيصال السداد</h4>
                        <p className="text-red-600 dark:text-red-300 font-bold text-xs leading-relaxed">
                          سبب الرفض: {registration.paymentNote || 'الإيصال غير واضح أو لا يطابق المبلغ المطلوب.'}
                        </p>
                        <p className="text-[10px] font-black text-red-500 mt-2">يرجى التثبت من الملف المرفوع وإعادة إرساله مرة أخرى.</p>
                      </div>
                    </motion.div>
                  )}

                  {registration.paymentStatus === 'pending_verification' && (
                    <div className="space-y-6">
                      <div className="p-5 bg-amber-50 dark:bg-amber-900/20 border border-amber-100 dark:border-amber-800 rounded-3xl flex items-center gap-4">
                        <div className="w-12 h-12 bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 rounded-2xl flex items-center justify-center shrink-0">
                          <Clock size={24} />
                        </div>
                        <div>
                          <h4 className="font-black text-amber-700 dark:text-amber-400 mb-1">تم الإرسال وبانتظار المراجعة والتدقيق</h4>
                          <p className="text-amber-600 dark:text-amber-300 font-bold text-xs">
                            طلبك الآن تحت الدراسة والمراجعة للتأكد من وصول المبلغ للحساب.
                          </p>
                          <p className="text-[10px] font-black text-amber-500 mt-1">سيصلك إشعار فور اعتماد الطلب أو وجود ملاحظات.</p>
                        </div>
                      </div>

                      {registration.paymentReceipt && (
                        <div className="bg-slate-50 dark:bg-slate-900/50 p-6 rounded-[2rem] border border-slate-100 dark:border-slate-800 text-center">
                          <p className="text-xs font-black text-slate-500 mb-4">إيصال السداد الذي تم إرساله للمراجعة</p>
                          <div className="w-48 h-48 mx-auto rounded-3xl overflow-hidden border-4 border-white dark:border-slate-700 shadow-xl relative group">
                            {registration.paymentReceipt.type?.includes('pdf') ? (
                              <div className="w-full h-full bg-white dark:bg-slate-900 flex flex-col items-center justify-center text-slate-400">
                                <FileText size={64} className="text-emerald-500 mb-2" />
                                <span className="text-xs font-black text-slate-400 px-4 truncate w-full">{registration.paymentReceipt.name}</span>
                              </div>
                            ) : (
                              <img src={registration.paymentReceipt.url} alt="receipt" className="w-full h-full object-cover" />
                            )}
                            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                              <a 
                                href={registration.paymentReceipt.url} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="p-3 bg-white text-slate-900 rounded-full hover:scale-110 transition shadow-xl"
                                title="عرض بحجم كامل"
                              >
                                <Eye size={24} />
                              </a>
                            </div>
                          </div>
                          <p className="text-xs font-black text-slate-700 dark:text-slate-200 mt-4 truncate max-w-[250px] mx-auto">
                            {registration.paymentReceipt.name}
                          </p>
                        </div>
                      )}
                    </div>
                  )}

                  {registration.paymentStatus !== 'pending_verification' && (
                    <>
                      <div className="bg-slate-50 dark:bg-slate-900/50 p-6 rounded-[2rem] border border-slate-100 dark:border-slate-800">
                        <h4 className="text-sm font-black text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                          <div className="w-2 h-2 bg-emerald-500 rounded-full" />
                          بيانات التحويل البنكي
                        </h4>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                          <div className="space-y-4">
                            <BankDetail label="اسم البنك" value={siteSettings.bankName} />
                            <BankDetail label="رقم الحساب" value={siteSettings.accountNumber} isMono />
                            <BankDetail label="IBAN" value={siteSettings.iban} isMono />
                          </div>
                          <div className="bg-gradient-to-br from-white to-emerald-50/30 dark:from-slate-800 dark:to-emerald-950/10 p-6 rounded-3xl border-2 border-emerald-100/50 dark:border-emerald-900/30 flex flex-col items-center justify-center text-center shadow-xl shadow-emerald-500/5 transition hover:scale-[1.02] duration-300">
                            <div className="w-14 h-14 bg-emerald-500/10 text-emerald-600 rounded-full flex items-center justify-center mb-3">
                              <CreditCard size={28} />
                            </div>
                            <p className="text-xs font-black text-slate-400 mb-1 uppercase tracking-tighter">المبلغ المطلوب سداده الآن</p>
                            <div className="flex items-baseline gap-1.5">
                              <span className="text-4xl font-black text-emerald-600 dark:text-emerald-400 drop-shadow-sm">{festivalFees || '---'}</span>
                              <span className="text-sm font-black text-slate-500">ريال سعودي</span>
                            </div>
                            <div className="mt-4 px-4 py-1.5 bg-emerald-600 text-white text-[10px] font-black rounded-full shadow-lg shadow-emerald-200 dark:shadow-none animate-pulse">
                              يجب سداد هذا المبلغ لاعتماد الطلب
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <h4 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-2">
                          <div className="w-2 h-2 bg-emerald-500 rounded-full" />
                          إرفاق إيصال السداد
                        </h4>
                        
                        <div className={`border-3 border-dashed rounded-[2.5rem] p-10 text-center transition-all ${
                          (paymentReceipt || (registration.paymentReceipt && !isReplacingExistingReceipt)) ? 'border-emerald-500 bg-emerald-50/20' : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 hover:border-emerald-500'
                        }`}>
                          {(paymentReceipt || (registration.paymentReceipt && !isReplacingExistingReceipt)) ? (
                            <div className="relative group">
                              <div className="flex flex-col items-center">
                                <div className="relative w-48 h-48 mb-4">
                                  {(paymentReceipt?.type || registration.paymentReceipt?.type)?.includes('pdf') ? (
                                    <div className="w-full h-full bg-white dark:bg-slate-900 rounded-3xl border-4 border-white dark:border-slate-700 shadow-2xl flex flex-col items-center justify-center">
                                      <FileText size={64} className="text-emerald-500 mb-2" />
                                      <span className="text-xs font-black text-slate-400 px-4 truncate w-full">{paymentReceipt?.name || registration.paymentReceipt?.name}</span>
                                    </div>
                                  ) : (
                                    <img 
                                      src={paymentReceipt?.preview || registration.paymentReceipt?.url} 
                                      alt="receipt" 
                                      className="w-full h-full object-cover rounded-3xl border-4 border-white dark:border-slate-700 shadow-2xl" 
                                    />
                                  )}
                                  {!(paymentReceipt?.type || registration.paymentReceipt?.type)?.includes('pdf') && (
                                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center rounded-3xl">
                                      <a 
                                        href={paymentReceipt?.preview || registration.paymentReceipt?.url} 
                                        target="_blank" 
                                        rel="noopener noreferrer"
                                        className="p-3 bg-white text-slate-900 rounded-full hover:scale-110 transition shadow-xl"
                                        title="عرض بحجم كامل"
                                      >
                                        <Eye size={24} />
                                      </a>
                                    </div>
                                  )}
                                  {!paymentReceipt && registration.paymentReceipt && (
                                    <div className="absolute -top-3 -right-3 bg-emerald-500 text-white text-[10px] font-black px-4 py-1.5 rounded-full shadow-lg backdrop-blur-sm z-10">
                                       إيصال مرفوع سابقاً
                                    </div>
                                  )}
                                </div>
                                
                                <div className="bg-white dark:bg-slate-800 px-6 py-3 rounded-2xl shadow-xl border border-slate-100 dark:border-slate-700">
                                  <p className="text-xs font-black text-slate-700 dark:text-slate-200 truncate max-w-[250px] mb-1">
                                    {paymentReceipt?.name || registration.paymentReceipt?.name}
                                  </p>
                                  {paymentReceipt && (
                                    <p className="text-[10px] font-bold text-emerald-600">جاهز للإرسال</p>
                                  )}
                                </div>

                                <button 
                                  onClick={() => {
                                    if (paymentReceipt) {
                                      setPaymentReceipt(null);
                                    } else {
                                      setIsReplacingExistingReceipt(true);
                                    }
                                  }}
                                  className="mt-6 flex items-center gap-2 px-6 py-3 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 rounded-2xl font-black text-xs hover:bg-red-100 transition shadow-sm"
                                >
                                  <X size={16} />
                                  حذف واستبدال الملف
                                </button>
                              </div>
                            </div>
                          ) : (
                            <div className="flex flex-col items-center">
                              <label className="cursor-pointer flex flex-col items-center gap-4 py-8 group w-full">
                                <div className="w-20 h-20 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 rounded-3xl flex items-center justify-center group-hover:scale-110 transition-transform shadow-sm">
                                  <Download size={40} />
                                </div>
                                <div className="space-y-1">
                                  <span className="font-black text-lg block text-slate-800 dark:text-slate-200">اختر صورة الحوالة</span>
                                  <p className="text-xs font-bold text-slate-400">يمكنك رفع صورة (JPG, PNG) أو ملف PDF</p>
                                </div>
                                <input type="file" onChange={handleReceiptChange} className="hidden" accept="image/*,.pdf" />
                              </label>
                              {isReplacingExistingReceipt && (
                                <button
                                  type="button"
                                  onClick={() => setIsReplacingExistingReceipt(false)}
                                  className="mt-2 text-xs font-black text-red-600 hover:text-red-700 bg-red-50 hover:bg-red-100 dark:bg-red-900/20 dark:text-red-400 px-4 py-2 rounded-xl transition duration-200"
                                >
                                  إلغاء واستعادة الإيصال الحالي
                                </button>
                              )}
                            </div>
                          )}
                        </div>

                        {paymentReceipt && (
                          <motion.button
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            onClick={handlePaymentSubmit}
                            disabled={isUpdating}
                            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black py-5 rounded-[2rem] transition shadow-xl shadow-emerald-200 dark:shadow-none flex items-center justify-center gap-3 active:scale-95"
                          >
                            {isUpdating ? <span className="animate-spin text-2xl">⏳</span> : <Send size={20} />}
                            {isUpdating ? 'جاري الإرسال والتحميل...' : 'إرسال إيصال السداد للمراجعة'}
                          </motion.button>
                        )}
                      </div>
                    </>
                  )}
                </div>
              )}
            </div>
          )}

          {activeTab === 'offers' && (() => {
            const categories = [
              { id: 'all', label: 'كل العروض' },
              { id: 'halls', label: 'قاعات الأفراح' },
              { id: 'hospitality_teams', label: 'فرق ضيافة وتجهيز' },
              { id: 'furniture', label: 'الأثاث والأجهزة' },
              { id: 'catering', label: 'المطابخ والضيافة' },
              { id: 'photography', label: 'استوديوهات التصوير' },
              { id: 'hotels', label: 'فنادق وشهر العسل' }
            ];

            const filtered = vendors.filter(v => {
              const matchesCategory = selectedCategory === 'all' || v.category === selectedCategory;
              const matchesQuery = v.name.toLowerCase().includes(vendorQuery.toLowerCase()) || 
                                   v.desc.toLowerCase().includes(vendorQuery.toLowerCase()) ||
                                   v.categoryLabel.toLowerCase().includes(vendorQuery.toLowerCase());
              return matchesCategory && matchesQuery;
            });

            return (
              <div className="space-y-6">
                {/* Header Card */}
                <div className="bg-gradient-to-l from-emerald-600 to-teal-600 text-white p-6 sm:p-8 rounded-3xl shadow-lg relative overflow-hidden group">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -mr-8 -mt-8 pointer-events-none animate-pulse" />
                  <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/5 rounded-full -ml-8 -mb-8 pointer-events-none" />
                  <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
                    <div className="max-w-xl">
                      <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/20 backdrop-blur-md rounded-full text-emerald-100 text-[10px] font-black mb-3">
                        <Gift size={12} className="animate-spin" style={{ animationDuration: '4s' }} />
                        هدايا وخصومات شركاء النجاح
                      </div>
                      <h3 className="text-xl sm:text-2xl font-black mb-2">عروض وخصومات مميزة لكم 🎁</h3>
                      <p className="text-emerald-100/90 text-xs sm:text-sm font-semibold leading-relaxed">
                        دليل شركاء النجاح يدعم المهرجان ويقدم لكم كوبونات خصم وعروض حصرية لتيسير تكاليف الزواج وبناء عش الزوجية السعيد بأقل التكاليف.
                      </p>
                    </div>
                    <div className="bg-white/10 backdrop-blur-md border border-white/15 px-6 py-4 rounded-2xl text-center shrink-0">
                      <p className="text-xs text-emerald-200 font-bold mb-0.5">مجموع الشركاء المتاحين</p>
                      <span className="text-3xl font-black font-sans text-white">{vendors.length}</span>
                      <p className="text-[10px] text-emerald-100 font-black mt-1">شريك نجاح مفعّل</p>
                    </div>
                  </div>
                </div>

                {/* Filters and Search Bar */}
                <div className="bg-white dark:bg-slate-800 p-5 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-700 flex flex-col gap-4">
                  <div className="flex flex-col sm:flex-row gap-4 items-stretch sm:items-center justify-between">
                    <div className="flex-1 max-w-md relative">
                      <span className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400">
                        <Search size={18} />
                      </span>
                      <input 
                        type="text" 
                        value={vendorQuery}
                        onChange={(e) => setVendorQuery(e.target.value)}
                        placeholder="ابحث عن شركة، مجال أو عرض خاص..."
                        className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl pr-11 pl-4 py-3 text-slate-900 dark:text-white font-bold focus:ring-2 focus:ring-emerald-500 outline-none transition text-sm"
                      />
                      {vendorQuery && (
                        <button 
                          onClick={() => setVendorQuery('')}
                          className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                        >
                          <X size={16} />
                        </button>
                      )}
                    </div>
                    <div className="text-xs text-slate-400 font-black text-left sm:text-right shrink-0">
                      يظهر {filtered.length} من أصل {vendors.length} عرض
                    </div>
                  </div>

                  {/* Horizontal Scroll categories */}
                  <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
                    {categories.map((cat) => (
                      <button
                        key={cat.id}
                        onClick={() => setSelectedCategory(cat.id)}
                        className={`px-4 py-2 rounded-xl text-xs font-black transition whitespace-nowrap ${
                          selectedCategory === cat.id 
                            ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 border-2 border-emerald-500/20' 
                            : 'bg-slate-50 dark:bg-slate-900/60 text-slate-500 dark:text-slate-400 border-2 border-transparent hover:bg-slate-100 dark:hover:bg-slate-800'
                        }`}
                      >
                        {cat.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Vendors Grid */}
                {filtered.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {filtered.map((vendor) => {
                      const isNewlyCopied = copiedCode === vendor.id || copiedCode === vendor.code;
                      return (
                        <motion.div 
                          key={vendor.id}
                          layout
                          initial={{ opacity: 0, y: 12 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-sm overflow-hidden flex flex-col justify-between hover:shadow-md transition-all group"
                        >
                          <div className="p-6 space-y-4">
                            {/* Card Header Info */}
                            <div className="flex justify-between items-start gap-3">
                              <span className="px-2.5 py-1 bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-lg text-[10px] font-black shrink-0">
                                {vendor.categoryLabel}
                              </span>
                              <div className="flex items-center gap-1 px-3 py-1 bg-rose-50 dark:bg-rose-950/30 text-rose-600 dark:text-rose-400 rounded-full font-black text-[11px] border border-rose-100/50 dark:border-rose-950/50 shadow-sm shrink-0">
                                <Tag size={12} />
                                {vendor.discount}
                              </div>
                            </div>

                            {/* Vendor Title */}
                            <div>
                              <h4 className="text-base font-black text-slate-900 dark:text-white group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                                {vendor.name}
                              </h4>
                              <p className="text-slate-500 dark:text-slate-400 text-xs font-semibold leading-relaxed mt-2">
                                {vendor.desc}
                              </p>
                            </div>

                            {/* Contact, Address list */}
                            <div className="space-y-2 pt-2 border-t border-slate-50 dark:border-slate-700 text-[11px] font-bold text-slate-400">
                              <div className="flex items-center gap-2">
                                <MapPin size={12} className="text-slate-300 shrink-0" />
                                <span className="text-slate-500 dark:text-slate-300 text-xs">{vendor.address}</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <Phone size={12} className="text-slate-300 shrink-0" />
                                <span className="font-mono text-slate-500 dark:text-slate-300 text-xs dir-ltr">{vendor.phone}</span>
                              </div>
                            </div>
                          </div>

                          {/* Copiable code & Action button footer */}
                          <div className="bg-slate-50 dark:bg-slate-900/60 px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-slate-100/70 dark:border-slate-700">
                            {/* Code placeholder */}
                            <div className="w-full sm:w-auto">
                              <span className="block text-[9px] text-slate-400 font-bold mb-1">كود الخصم الحصري</span>
                              <button 
                                onClick={() => handleCopyCode(vendor.code)}
                                className={`w-full flex items-center justify-center gap-2 px-3 py-1.5 border-2 border-dashed rounded-xl font-mono text-sm font-black transition-all ${
                                  isNewlyCopied 
                                    ? 'bg-emerald-50 dark:bg-emerald-950/20 border-emerald-500 text-emerald-600 dark:text-emerald-400' 
                                    : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 hover:border-emerald-500 text-slate-800 dark:text-slate-100'
                                }`}
                              >
                                {isNewlyCopied ? (
                                  <>
                                    <CheckCircle size={14} className="text-emerald-500 animate-bounce" />
                                    <span className="text-xs font-black">تم نسخ الكود!</span>
                                  </>
                                ) : (
                                  <>
                                    <Copy size={13} className="text-slate-400 group-hover:text-emerald-500" />
                                    <span>{vendor.code}</span>
                                  </>
                                )}
                              </button>
                            </div>

                            {/* Contact Action button */}
                            <a 
                              href={`https://wa.me/${vendor.phone.replace(/^0/, '966')}`}
                              target="_blank" 
                              rel="noreferrer"
                              className="w-full sm:w-auto shrink-0 flex items-center justify-center gap-1.5 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl transition shadow-sm active:scale-95"
                            >
                              <ExternalLink size={12} />
                              اتصل واحجز خصمك
                            </a>
                          </div>
                        </motion.div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="bg-white dark:bg-slate-800 py-12 px-6 rounded-3xl text-center border border-slate-100 dark:border-slate-700">
                    <div className="w-16 h-16 bg-slate-100 dark:bg-slate-900 text-slate-400 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Gift size={28} />
                    </div>
                    <h5 className="text-base font-black text-slate-900 dark:text-white mb-1">لا توجد عروض حالياً لهذا التصنيف</h5>
                    <p className="text-xs text-slate-400 font-bold max-w-sm mx-auto leading-relaxed">
                      جرب مسح شريط البحث أو التنقل بين باقي التصنيفات المتوفرة لعرض عروض أخرى مميزة.
                    </p>
                  </div>
                )}
              </div>
            );
          })()}

          {activeTab === 'evaluation' && (() => {
            const todayStr = new Date().toISOString().split('T')[0];
            const currentFestival = festivals.find(f => f.id === registration?.festivalId);
            const isFestivalEnded = currentFestival?.isArchived === true || (currentFestival?.date && currentFestival.date < todayStr);

            return (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Card 1: Service Evaluation */}
                <div className="bg-white dark:bg-slate-800 p-8 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-700 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center gap-3 mb-6">
                      <div className="w-10 h-10 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-xl flex items-center justify-center">
                        <Star size={20} />
                      </div>
                      <h3 className="text-lg font-black text-slate-900 dark:text-white">تقييم الخدمة والتسجيل</h3>
                    </div>

                    {registration.evaluation ? (
                      <div className="text-center py-8">
                        <div className="w-16 h-16 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-full flex items-center justify-center mx-auto mb-4">
                          <CheckCircle size={32} />
                        </div>
                        <h4 className="text-lg font-black text-slate-900 dark:text-white mb-2">شكراً لك!</h4>
                        <p className="text-slate-500 dark:text-slate-400 font-bold text-sm">لقد تم استلام تقييمك للخدمة بنجاح.</p>
                        
                        <div className="mt-6 flex justify-center gap-1.5">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <Star 
                              key={`service-star-${star}`} 
                              size={20} 
                              className={star <= registration.evaluation.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-200 dark:text-slate-700'} 
                            />
                          ))}
                        </div>
                        {registration.evaluation.comment && (
                          <div className="mt-6 p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl text-slate-600 dark:text-slate-400 italic text-xs font-semibold">
                            "{registration.evaluation.comment}"
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="space-y-6">
                        <p className="text-slate-500 dark:text-slate-400 font-bold text-xs">يسعدنا تقييم تجربة التسجيل في المهرجان لمساعدتنا في تحسين خدماتنا مستقبلاً.</p>
                        
                        <div className="flex flex-col items-center gap-3 bg-slate-50/50 dark:bg-slate-900/40 p-4 rounded-2xl border border-slate-100 dark:border-slate-800">
                          <p className="font-black text-slate-700 dark:text-slate-300 text-xs">ما هو تقييمك العام للخدمة؟</p>
                          <div className="flex gap-2">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <button
                                key={`eval-star-btn-${star}`}
                                onClick={() => setEvaluation({ ...evaluation, rating: star })}
                                className="transition-transform hover:scale-110"
                              >
                                <Star 
                                  size={32} 
                                  className={`${star <= evaluation.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-200 dark:text-slate-700'} transition-colors`} 
                                />
                              </button>
                            ))}
                          </div>
                        </div>

                        <div className="space-y-2">
                          <label className="block text-xs font-black text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                            <MessageSquare size={16} className="text-slate-400" />
                            ملاحظات إضافية (اختياري)
                          </label>
                          <textarea
                            value={evaluation.comment}
                            onChange={(e) => setEvaluation({ ...evaluation, comment: e.target.value })}
                            className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl p-3 text-slate-900 dark:text-white font-bold focus:ring-2 focus:ring-emerald-500 outline-none transition min-h-[90px] text-xs"
                            placeholder="أخبرنا عن تجربتك أو أي مقترحات للتحسين..."
                          />
                        </div>

                        <button
                          onClick={handleSubmitEvaluation}
                          disabled={isUpdating || evaluation.rating === 0}
                          className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black py-3 rounded-2xl transition shadow-lg shadow-emerald-200 dark:shadow-emerald-900/20 disabled:opacity-50 flex items-center justify-center gap-2 text-xs"
                        >
                          <Send size={14} />
                          إرسال تقييم الخدمة
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* Card 2: Festival Satisfaction Evaluation */}
                <div className="bg-white dark:bg-slate-800 p-8 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-700 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center gap-3 mb-6">
                      <div className="w-10 h-10 bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 rounded-xl flex items-center justify-center">
                        <Award size={20} />
                      </div>
                      <h3 className="text-lg font-black text-slate-900 dark:text-white">تقييم فعاليات المهرجان</h3>
                    </div>

                    {!isFestivalEnded ? (
                      <div className="text-center py-10 px-4 bg-slate-50/50 dark:bg-slate-900/30 rounded-3xl border border-dashed border-slate-200 dark:border-slate-800">
                        <div className="w-14 h-14 bg-slate-100 dark:bg-slate-800 text-slate-400 rounded-2xl flex items-center justify-center mx-auto mb-4">
                          <Clock size={24} />
                        </div>
                        <h4 className="font-black text-slate-800 dark:text-slate-200 text-sm mb-2">التقييم غير متاح حالياً</h4>
                        <p className="text-slate-500 dark:text-slate-400 font-bold text-xs leading-relaxed max-w-xs mx-auto">
                          سيكون تقييم المهرجان متاحاً لكم بعد انتهاء فعاليات المهرجان وإقامة حفل الزفاف الجماعي بمشيئة الله.
                        </p>
                      </div>
                    ) : registration.festivalEvaluation ? (
                      <div className="text-center py-8">
                        <div className="w-16 h-16 bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400 rounded-full flex items-center justify-center mx-auto mb-4">
                          <CheckCircle size={32} />
                        </div>
                        <h4 className="text-lg font-black text-slate-900 dark:text-white mb-2">شكراً لمشاركتك الفعالة!</h4>
                        <p className="text-slate-500 dark:text-slate-400 font-bold text-sm">تم استلام تقييمك للمهرجان بنجاح وقراءة ملاحظاتك القيّمة.</p>
                        
                        <div className="mt-6 flex justify-center gap-1.5">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <Star 
                              key={`festival-star-${star}`} 
                              size={20} 
                              className={star <= registration.festivalEvaluation.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-200 dark:text-slate-700'} 
                            />
                          ))}
                        </div>
                        {registration.festivalEvaluation.comment && (
                          <div className="mt-6 p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl text-slate-600 dark:text-slate-400 italic text-xs font-semibold">
                            "{registration.festivalEvaluation.comment}"
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="space-y-6">
                        <p className="text-slate-500 dark:text-slate-400 font-bold text-xs">يسرنا الاستماع لآرائكم ومدى رضاكم عن تنظيم وفعاليات المهرجان بعد إقامته لتطوير النسخ القادمة.</p>
                        
                        <div className="flex flex-col items-center gap-3 bg-slate-50/50 dark:bg-slate-900/40 p-4 rounded-2xl border border-slate-100 dark:border-slate-800">
                          <p className="font-black text-slate-700 dark:text-slate-300 text-xs">ما هو تقييمك لنجاح وتنظيم المهرجان؟</p>
                          <div className="flex gap-2">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <button
                                key={`fest-star-btn-${star}`}
                                onClick={() => setFestivalEval({ ...festivalEval, rating: star })}
                                className="transition-transform hover:scale-110"
                              >
                                <Star 
                                  size={32} 
                                  className={`${star <= festivalEval.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-200 dark:text-slate-700'} transition-colors`} 
                                />
                              </button>
                            ))}
                          </div>
                        </div>

                        <div className="space-y-2">
                          <label className="block text-xs font-black text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                            <MessageSquare size={16} className="text-slate-400" />
                            ملاحظات ومقترحات للمهرجان القادم
                          </label>
                          <textarea
                            value={festivalEval.comment}
                            onChange={(e) => setFestivalEval({ ...festivalEval, comment: e.target.value })}
                            className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl p-3 text-slate-900 dark:text-white font-bold focus:ring-2 focus:ring-emerald-500 outline-none transition min-h-[90px] text-xs"
                            placeholder="اكتب آرائك حول قاعة الحفل، التنظيم، الضيافة، أو أي اقتراحات إضافية..."
                          />
                        </div>

                        <button
                          onClick={handleSubmitFestivalEvaluation}
                          disabled={isUpdating || festivalEval.rating === 0}
                          className="w-full bg-amber-500 hover:bg-amber-600 text-white font-black py-3 rounded-2xl transition shadow-lg shadow-amber-200 dark:shadow-amber-900/20 disabled:opacity-50 flex items-center justify-center gap-2 text-xs"
                        >
                          <Send size={14} />
                          إرسال تقييم المهرجان
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })()}

          {activeTab === 'courses' && (
            <div className="bg-white dark:bg-slate-800 p-6 sm:p-8 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-700">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-xl flex items-center justify-center">
                    <BookOpen size={20} />
                  </div>
                  <div>
                    <h3 className="text-lg font-black text-slate-900 dark:text-white">الدورة التأهيلية والشهادات</h3>
                    <p className="text-xs text-slate-400 font-bold mt-0.5">تابع مواعيد المحاضرات التدريبية وحمل شهادة حضورك المعتمدة</p>
                  </div>
                </div>

                {/* Requirements check status */}
                <div className="flex items-center gap-2 bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-100 dark:border-emerald-900/60 px-4 py-2 rounded-xl">
                  <div className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse" />
                  <span className="text-xs font-black text-emerald-700 dark:text-emerald-400">
                    حالة المتطلب: {attendance.some(a => a.isAttended || a.attended) ? '✓ مكتمل ومستوفي' : '⏳ قيد الانتظار'}
                  </span>
                </div>
              </div>

              {/* Course items */}
              {courses.length === 0 ? (
                <div className="text-center py-12 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800">
                  <Calendar size={48} className="mx-auto text-slate-300 dark:text-slate-700 mb-3" />
                  <h4 className="font-black text-slate-700 dark:text-slate-300 text-sm mb-1">لا توجد دورات مدرجة حالياً</h4>
                  <p className="text-xs text-slate-400 max-w-xs mx-auto">سيتم إدراج مواعيد المحاضرات التأهيلية من قبل إدارة الجمعية قريباً، يرجى المتابعة لاحقاً.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {courses.map((course) => {
                    const attendRecord = attendance.find(a => a.courseId === course.id);
                    const isAttended = attendRecord?.isAttended === true || attendRecord?.attended === true;

                    return (
                      <div 
                        key={course.id} 
                        className={`p-6 rounded-2xl border transition relative flex flex-col justify-between ${
                          isAttended 
                            ? 'bg-emerald-50/10 dark:bg-emerald-950/5 border-emerald-500/20 hover:border-emerald-500/40 shadow-sm' 
                            : 'bg-white dark:bg-slate-800 border-slate-100 dark:border-slate-700/60 hover:border-slate-200 dark:hover:border-slate-600'
                        }`}
                      >
                        <div>
                          <div className="flex flex-col gap-1 mb-4">
                            <div className="flex justify-between items-start gap-2">
                              <h4 className="font-extrabold text-slate-900 dark:text-white text-sm leading-snug">{course.title}</h4>
                              <span className={`px-3 py-1 rounded-full text-[10px] font-black shrink-0 ${
                                isAttended 
                                  ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300' 
                                  : 'bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-300'
                              }`}>
                                {isAttended ? '✓ حضر' : '⏰ بانتظار الحضور'}
                              </span>
                            </div>
                            <div className="flex flex-wrap gap-1.5 mt-1.5">
                              {course.heldType === 'online' ? (
                                <span className="inline-flex items-center gap-1 text-[10px] font-black text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/40 px-2 py-0.5 rounded-full">
                                  <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse" />
                                  عن بُعد (أونلاين)
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 text-[10px] font-black text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 px-2 py-0.5 rounded-full">
                                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                                  حضوريًا
                                </span>
                              )}
                            </div>
                          </div>

                          <div className="space-y-2 text-xs text-slate-600 dark:text-slate-400 font-bold mb-6">
                            <div className="flex items-center gap-2">
                              <span className="text-slate-400 shrink-0">👤 المحاضر:</span>
                              <span className="text-slate-700 dark:text-slate-200">{course.lecturer}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="text-slate-400 shrink-0">📅 التاريخ:</span>
                              <span className="text-slate-700 dark:text-slate-200">{course.date} {course.time && `| ⏰ ${course.time}`}</span>
                            </div>
                            {course.heldType === 'online' ? (
                              <div className="space-y-1.5 mt-1">
                                <div className="flex items-center gap-2">
                                  <span className="text-slate-400 shrink-0">🌐 منصة البث:</span>
                                  <span className="text-blue-600 dark:text-blue-400 font-extrabold">{course.meetingLink || 'عن بُعد / أونلاين'}</span>
                                </div>
                                {course.meetingLink && (course.meetingLink.startsWith('http://') || course.meetingLink.startsWith('https://')) && (
                                  <div className="pt-1">
                                    <a
                                      href={course.meetingLink}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-[10px] font-black rounded-lg transition transform active:scale-95 duration-150"
                                    >
                                      🔗 اضغط هنا للانضمام للبث المباشر
                                    </a>
                                  </div>
                                )}
                              </div>
                            ) : (
                              <div className="flex items-center gap-2">
                                <span className="text-slate-400 shrink-0">📍 المكان:</span>
                                <span className="text-slate-700 dark:text-slate-200">{course.location || 'قاعة تدريب فرع الجمعية بالمنيزلة'}</span>
                              </div>
                            )}
                            {course.notes && (
                              <div className="text-[10px] text-slate-400 bg-slate-50 dark:bg-slate-900 p-2 rounded-lg mt-2">
                                💡 ملاحظات: {course.notes}
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Certificate generation action */}
                        <div>
                          {isAttended ? (
                            <button
                              onClick={() => setSelectedCourseForCert(course)}
                              className="w-full flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-black py-2.5 rounded-xl text-xs transition active:scale-95 shadow-md shadow-emerald-200 dark:shadow-emerald-900/10"
                            >
                              <Award size={14} />
                              عرض وطباعة شهادة الحضور
                            </button>
                          ) : (
                            <div className="p-2.5 bg-slate-50 dark:bg-slate-900/60 border border-slate-100 dark:border-slate-800 rounded-xl text-center text-[10px] text-slate-400 font-bold">
                              سيتم تفعيل طباعة الشهادة بمجرد قيام المشرف بتحضيرك
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Certificate Modal styled for superb screen review & flawless browser printing */}
      <AnimatePresence>
        {selectedCourseForCert && (
          <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm overflow-y-auto">
            <style>{`
              @media print {
                body * {
                  visibility: hidden !important;
                }
                #print-certificate-target, #print-certificate-target * {
                  visibility: visible !important;
                }
                #print-certificate-target {
                  position: absolute !important;
                  left: 0 !important;
                  top: 0 !important;
                  width: 100% !important;
                  height: 100% !important;
                  margin: 0 !important;
                  padding: 1.5in !important;
                  background: white !important;
                  box-shadow: none !important;
                  border: none !important;
                }
                .no-print {
                  display: none !important;
                }
              }
            `}</style>
            
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 w-full max-w-4xl shadow-2xl relative border border-slate-200 dark:border-slate-700 no-print my-8"
            >
              <button 
                onClick={() => setSelectedCourseForCert(null)}
                className="absolute top-4 left-4 p-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 rounded-full text-slate-500 transition-colors"
              >
                <X size={18} />
              </button>

              <h3 className="text-lg font-black text-slate-900 dark:text-white mb-4 pr-6 flex items-center gap-2">
                <Award className="text-amber-500" size={22} />
                عرض الشهادة الرسمية المعتمدة للطباعة
              </h3>

              {/* Certificate Frame Preview */}
              <div className="overflow-x-auto pb-4">
                <div 
                  id="print-certificate-target"
                  className="bg-amber-50/10 text-slate-900 border-[16px] border-double border-amber-600 p-8 sm:p-16 max-w-4xl mx-auto rounded-lg text-center relative shadow-inner overflow-hidden flex flex-col justify-between min-h-[580px]"
                  style={{
                    backgroundImage: 'radial-gradient(circle, rgba(245,158,11,0.03) 10%, transparent 10.5%)',
                    backgroundSize: '16px 16px'
                  }}
                >
                  {/* Watermark Logo / Motif in center */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-[0.02] pointer-events-none select-none">
                    <svg width="400" height="400" viewBox="0 0 100 100" fill="currentColor">
                      <path d="M50 5 L90 28 L90 72 L50 95 L10 72 L10 28 Z" />
                    </svg>
                  </div>

                  {/* Header Logo & Text */}
                  <div className="flex flex-col items-center gap-3 mb-6 relative">
                    <div className="w-16 h-16 rounded-full bg-emerald-700 flex items-center justify-center text-amber-400 border-2 border-amber-500 shadow-md">
                      <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M12 2L4.5 9.5 12 17l7.5-7.5L12 2z" />
                        <path d="M12 17v5" />
                        <path d="M8 22h8" />
                      </svg>
                    </div>

                    <div className="space-y-1">
                      <h1 className="text-base sm:text-lg font-black text-emerald-800 tracking-tight">الجمعية الخيرية لتيسير الزواج ورعاية الأسرة بالأحساء</h1>
                      <h2 className="text-xs font-extrabold text-amber-700">فرع المنيزلة</h2>
                      <div className="text-[10px] text-slate-400 font-bold">مسجلة بوزارة الموارد البشرية والتنمية الاجتماعية برقم (٣٠١٨)</div>
                    </div>

                    {/* Separation line decorations */}
                    <div className="w-48 h-1 flex items-center justify-center gap-1.5 mx-auto mt-2">
                      <div className="w-full h-[1px] bg-gradient-to-r from-transparent to-amber-500" />
                      <span className="text-amber-500">❖</span>
                      <div className="w-full h-[1px] bg-gradient-to-l from-transparent to-amber-500" />
                    </div>
                  </div>

                  {/* Certificate Title */}
                  <div className="mb-6">
                    <h3 className="text-lg sm:text-xl font-black text-amber-700 tracking-wide inline-block border-b-2 border-emerald-700 pb-1.5 px-6">
                      شهادة حضور الدورة التأهيلية
                    </h3>
                  </div>

                  {/* Certificate Body Wording */}
                  <div className="space-y-4 max-w-2xl mx-auto">
                    <p className="text-slate-600 font-bold text-xs sm:text-sm leading-relaxed">
                      تشهد إدارة فرع الجمعية الخيرية بالمنيزلة لتيسير الزواج ورعاية الأسرة بالأحساء بأن العريس الابن:
                    </p>
                    
                    <p className="text-xl sm:text-2xl font-black text-emerald-800 border-b border-slate-200">
                      {registration.groomName}
                    </p>

                    <p className="text-slate-600 font-bold text-xs leading-relaxed">
                      قد حضر واجتاز بنجاح <span className="font-extrabold text-slate-800">"الدورة التأهيلية للمقبلين على الزواج"</span> المقامة تزامناً مع مشاركته وإتمام متطلباته، بعنوان:
                    </p>

                    <p className="text-sm font-extrabold text-emerald-850 py-1.5 px-4 bg-emerald-50 dark:bg-emerald-950/20 rounded-xl inline-block border border-emerald-100">
                      {selectedCourseForCert.title}
                    </p>

                    <p className="text-slate-600 font-bold text-xs">
                      المقيمة بتاريخ <span className="font-extrabold text-slate-800">{selectedCourseForCert.date}</span> بإشراف المدرب الفاضل الشيخ/المستشار <span className="font-extrabold text-slate-800">{selectedCourseForCert.lecturer}</span>.
                    </p>
                  </div>

                  {/* Signatures & Seal Footer */}
                  <div className="mt-8 pt-6 border-t border-slate-300/40 flex flex-col sm:flex-row justify-between items-center gap-6">
                    <div className="text-right sm:pr-8 space-y-1">
                      <p className="text-[10px] text-slate-400 font-bold">حرر في الأحساء بتاريخ:</p>
                      <p className="text-xs font-extrabold text-slate-800">{selectedCourseForCert.date}</p>
                    </div>

                    {/* Official Stamp Vector Seal mockup */}
                    <div className="w-20 h-20 rounded-full border-4 border-emerald-700/60 flex flex-col items-center justify-center p-1 relative text-center text-emerald-800 opacity-90 rotate-[-5deg] scale-105 border-dashed">
                      <div className="text-[7px] font-black tracking-wide">الجمعية الخيرية بالأحساء</div>
                      <div className="text-[9px] font-bold leading-tight my-0.5">فرع المنيزلة</div>
                      <div className="text-[7px] font-black border-t border-emerald-700/60 pt-0.5">الختم الرسمي للمهرجانات</div>
                    </div>

                    <div className="text-center sm:pl-8 space-y-1">
                      <p className="text-xs text-slate-500 font-black">مدير فرع الجمعية بالمنيزلة</p>
                      <p className="text-xs font-bold text-emerald-850">أبي تراب الأحسائي ومنسوبيها</p>
                      <span className="text-[8px] text-slate-400 font-bold">صادرة إلكترونياً وتعتبر مستنداً رسمياً معتمداً</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Actions buttons */}
              <div className="mt-6 flex flex-col sm:flex-row gap-3 justify-end items-center border-t border-slate-100 dark:border-slate-800 pt-5">
            <button
              onClick={() => setSelectedCourseForCert(null)}
              className="w-full sm:w-auto px-5 py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold rounded-xl text-xs"
            >
              إغلاق المعاينة
            </button>
            <button
              onClick={() => window.print()}
              className="w-full sm:w-auto px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black rounded-xl text-xs transition shadow-lg shadow-emerald-200 dark:shadow-emerald-900/20 flex items-center justify-center gap-1.5"
            >
              <Printer size={16} />
              طباعة الشهادة الرسمية
            </button>
          </div>
        </motion.div>
      </div>
    )}
  </AnimatePresence>

  <AnimatePresence>
    {showPaymentSuccessModal && (
      <div className="fixed inset-0 z-[140] flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] shadow-2xl w-full max-w-md border border-slate-100 dark:border-slate-800 text-center relative"
        >
          <div className="w-20 h-20 bg-emerald-100 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 rounded-full flex items-center justify-center mx-auto mb-6 border border-emerald-200 dark:border-emerald-900/30">
            <CheckCircle size={44} className="stroke-[2.5]" />
          </div>
          
          <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-3">تم إرسال الإيصال بنجاح!</h3>
          <p className="text-slate-500 dark:text-slate-400 font-bold text-sm leading-relaxed mb-8">
            تم استلام إيصال سداد الرسوم بنجاح. سنقوم بمراجعته ومطابقته وتدقيق البيانات في أسرع وقت لتأكيد تسجيلك بشكل نهائي.
          </p>

          <button
            onClick={() => setShowPaymentSuccessModal(false)}
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black py-4 rounded-2xl transition shadow-lg shadow-emerald-200 dark:shadow-none active:scale-95"
          >
            حسناً، فهمت
          </button>
        </motion.div>
      </div>
    )}
  </AnimatePresence>

  <AnimatePresence>
    {showEvalPromptModal && (
      <div className="fixed inset-0 z-[140] flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] shadow-2xl w-full max-w-md border border-slate-100 dark:border-slate-800 text-center relative"
        >
          <div className="w-20 h-20 bg-amber-100 dark:bg-amber-950/40 text-amber-500 dark:text-amber-400 rounded-full flex items-center justify-center mx-auto mb-6 border border-amber-200 dark:border-amber-900/30">
            <Star size={44} className="stroke-[2.5] fill-amber-500 text-amber-500" />
          </div>
          
          <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-3">تهانينا! تم تأكيد السداد</h3>
          <p className="text-slate-500 dark:text-slate-400 font-bold text-sm leading-relaxed mb-8">
            يسعدنا إبلاغك بأنه قد تم قبول وتأكيد سداد الرسوم لطلبك بنجاح. نرجو منك التكرم بتقييم الخدمة لمساعدتنا في تحسين خدماتنا مستقبلاً.
          </p>

          <div className="flex flex-col gap-3">
            <button
              onClick={() => {
                if (registration?.id) {
                  localStorage.setItem(`eval_prompt_${registration.id}`, 'true');
                }
                setShowEvalPromptModal(false);
                setActiveTab('evaluation');
              }}
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black py-4 rounded-2xl transition shadow-lg shadow-emerald-200 dark:shadow-none active:scale-95 flex items-center justify-center gap-2"
            >
              <Star size={18} className="fill-current text-white" />
              تقييم الخدمة الآن
            </button>
            <button
              onClick={() => {
                if (registration?.id) {
                  localStorage.setItem(`eval_prompt_${registration.id}`, 'true');
                }
                setShowEvalPromptModal(false);
              }}
              className="w-full bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 font-bold py-3.5 rounded-2xl transition active:scale-95"
            >
              لاحقاً
            </button>
          </div>
        </motion.div>
      </div>
    )}
  </AnimatePresence>

  {viewingAttachment && (
    <AttachmentViewerModal 
      attachment={viewingAttachment} 
      onClose={() => setViewingAttachment(null)} 
    />
  )}
</div>
);
}

function AttachmentViewerModal({ attachment, onClose }: { attachment: { url: string, type: string, name: string }, onClose: () => void }) {
return (
<div className="fixed inset-0 z-[150] flex items-center justify-center p-4 bg-slate-900/90 backdrop-blur-sm" onClick={onClose}>
  <motion.div 
    initial={{ scale: 0.95, opacity: 0 }} 
    animate={{ scale: 1, opacity: 1 }} 
    className="relative w-full max-w-5xl max-h-[90vh] flex flex-col bg-white dark:bg-slate-900 rounded-3xl overflow-hidden shadow-2xl"
    onClick={e => e.stopPropagation()}
  >
    <div className="flex items-center justify-between p-4 border-b border-slate-100 dark:border-slate-800">
      <h3 className="font-black text-slate-900 dark:text-white truncate pr-4">{attachment.name}</h3>
      <div className="flex items-center gap-2">
        <a 
          href={attachment.url} 
          target="_blank" 
          rel="noreferrer" 
          className="p-2 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-xl hover:bg-blue-100 dark:hover:bg-blue-900/40 transition-colors"
          title="فتح في نافذة جديدة"
        >
          <ExternalLink size={20} />
        </a>
        <a 
          href={attachment.url} 
          target="_blank" 
          rel="noreferrer" 
          download={attachment.name}
          className="p-2 bg-brand-50 dark:bg-brand-900/20 text-brand-600 dark:text-brand-400 rounded-xl hover:bg-brand-100 dark:hover:bg-brand-900/40 transition-colors"
          title="تحميل"
        >
          <Download size={20} />
        </a>
        <button onClick={onClose} className="p-2 bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 rounded-xl hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors">
          <X size={20} />
        </button>
      </div>
    </div>
    <div className="flex-1 overflow-auto bg-slate-100/50 dark:bg-slate-950 p-4 flex items-center justify-center min-h-[50vh]">
      {attachment.type.includes('pdf') ? (
        <iframe src={attachment.url} className="w-full h-[70vh] rounded-xl border-0" title={attachment.name} />
      ) : (
        <img src={attachment.url} alt={attachment.name} className="max-w-full max-h-[75vh] object-contain rounded-xl" referrerPolicy="no-referrer" />
      )}
    </div>
  </motion.div>
</div>
);
}
