/**
 * Simple localStorage caching utility
 */
export const cache = {
  set: (key: string, data: any, maxAgeMs?: number) => {
    try {
      const payload = {
        data,
        timestamp: Date.now(),
        maxAgeMs,
      };
      localStorage.setItem(`ais_cache_${key}`, JSON.stringify(payload));
    } catch (e) {
      console.warn('Cache write failed:', e);
    }
  },

  get: <T>(key: string, maxAgeMs?: number): T | null => {
    try {
      const raw = localStorage.getItem(`ais_cache_${key}`);
      if (!raw) return null;

      const payload = JSON.parse(raw);
      const effectiveMaxAge = maxAgeMs || payload.maxAgeMs;

      if (effectiveMaxAge && Date.now() - payload.timestamp > effectiveMaxAge) {
        localStorage.removeItem(`ais_cache_${key}`);
        return null;
      }

      return payload.data as T;
    } catch (e) {
      console.warn('Cache read failed:', e);
      return null;
    }
  },

  remove: (key: string) => {
    localStorage.removeItem(`ais_cache_${key}`);
  }
};
