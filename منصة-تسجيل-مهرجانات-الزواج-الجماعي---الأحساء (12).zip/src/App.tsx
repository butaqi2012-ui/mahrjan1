import React, { useState, useEffect, useRef } from 'react';
import { 
  BarChart as ReBarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  Cell,
  CartesianGrid,
  PieChart,
  Pie,
  Legend
} from 'recharts';
import { 
  Search, 
  Edit3,
  Calendar, 
  User, 
  LogOut, 
  ChevronRight, 
  CheckCircle, 
  Upload, 
  AlertCircle, 
  Printer, 
  FileText, 
  Menu, 
  X, 
  LayoutDashboard,
  Home,
  Clock,
  CreditCard,
  ChevronLeft,
  Trash2,
  Eye,
  EyeOff,
  LogIn,
  Plus,
  Users,
  Paperclip,
  Check,
  Heart,
  Info,
  BarChart as LucideBarChart,
  Lock,
  Moon,
  Sun,
  MessageSquareHeart,
  Award,
  Phone,
  MessageCircle,
  Twitter,
  Globe,
  Instagram,
  Facebook,
  Ghost,
  Video,
  Share2,
  Youtube,
  Send,
  XCircle,
  AlertTriangle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  onAuthStateChanged, 
  signOut,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  sendEmailVerification,
  User as FirebaseUser
} from 'firebase/auth';
import { 
  collection, 
  onSnapshot, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs,
  addDoc, 
  deleteDoc,
  updateDoc,
  query, 
  where, 
  orderBy,
  limit,
  serverTimestamp,
  writeBatch,
  increment
} from 'firebase/firestore';
import { auth, db } from './firebase';
import { format } from 'date-fns';
import { Dashboard } from './components/Dashboard';
import { PublicStats } from './components/PublicStats';
import GroomPortal from './components/GroomPortal';
import PrintReport from './components/PrintReport';
import { notifyAdminsAndSupervisor } from './utils/notifications';
import PaymentGateway from './components/PaymentGateway';
import { cache } from './utils/cache';
import { compressImage } from './utils/image';

// --- Types ---
interface Festival {
  id: string;
  name: string;
  date: string;
  endDate?: string;
  fees: number;
  isOpen: boolean;
  order?: number;
  supervisorId?: string;
  phone?: string;
  whatsapp?: string;
  website?: string;
  instagram?: string;
  xLink?: string;
  facebook?: string;
  snapchat?: string;
  tiktok?: string;
  youtube?: string;
  telegram?: string;
  registrationCount?: number;
  siblingDiscountType?: 'none' | 'second_free' | 'third_free' | 'custom_prices';
  twoBrothersFees?: number;
  threeBrothersFees?: number;
}

interface UserProfile {
  uid: string;
  email: string;
  role: 'admin' | 'supervisor' | 'user';
  displayName: string;
  photoURL: string;
  assignedFestivalId?: string;
}

interface Registration {
  id: string;
  festivalId: string;
  festivalName: string;
  groomName: string;
  groomId: string;
  groomPhone: string;
  groomEmail: string;
  groomGuardianName: string;
  groomGuardianPhone: string;
  groomGuardianRelation?: string;
  brideName: string;
  brideId: string;
  bridePhone: string;
  guardianName: string; // Bride's guardian
  guardianPhone: string;
  guardianRelation?: string;
  mahrAmount: string;
  qualification: string;
  employmentStatus: string;
  employmentSector: string;
  salary: string;
  housingType: string;
  ownershipType: string;
  rentAmount: string;
  healthStatus: string;
  disabilityType: string;
  status: 'pending' | 'approved' | 'rejected' | 'needs_info';
  attachments: { name: string; url: string; type: string }[];
  deficiencies?: string[];
  paymentReceipt?: { name: string; url: string; type: string; size?: number };
  paymentMethod?: 'online' | 'transfer';
  paymentStatus?: 'paid' | 'pending_verification' | 'rejected';
  paymentNote?: string | null;
  createdAt: any;
  updatedAt?: any;
  userId: string;
  rejectionReason?: string | null;
  currentStep?: number; // 0: استلام الطلب, 1: تدقيق البيانات, 2: مراجعة السداد, 3: الموافقة النهائية
  hasSibling?: boolean;
  siblingNames?: string[];
  siblingIds?: string[];
  siblingCount?: string;
  calculatedFees?: number;
}

export interface Task {
  id: string;
  registrationId: string;
  title: string;
  description?: string;
  assignedTo: string; // userId of the supervisor
  status: 'pending' | 'in-progress' | 'completed';
  dueDate: any; // timestamp
  createdAt: any;
  updatedAt?: any;
}

// --- Helper Functions for Arabic Date Phrasings ---
function formatArabicDay(dayIndex: number): string {
  const days = [
    { day: 'الأحد', night: 'الإثنين' },
    { day: 'الإثنين', night: 'الثلاثاء' },
    { day: 'الثلاثاء', night: 'الأربعاء' },
    { day: 'الأربعاء', night: 'الخميس' },
    { day: 'الخميس', night: 'الجمعة' },
    { day: 'الجمعة', night: 'السبت' },
    { day: 'السبت', night: 'الأحد' }
  ];
  const info = days[dayIndex];
  if (!info) return '';
  return `يوم ${info.day} ليلة ${info.night}`;
}

function getArabicDayWithNight(dateStr: string): string {
  if (!dateStr) return '';
  const cleanDateStr = dateStr.trim();
  const match = cleanDateStr.match(/(\d{4})[-/](\d{1,2})[-/](\d{1,2})/);
  if (match) {
    const year = parseInt(match[1]);
    const month = parseInt(match[2]) - 1; // Month is 0-indexed
    const day = parseInt(match[3]);
    const d = new Date(year, month, day);
    if (!isNaN(d.getTime())) {
      return formatArabicDay(d.getDay());
    }
  }
  const parsedDate = new Date(cleanDateStr);
  if (!isNaN(parsedDate.getTime())) {
    return formatArabicDay(parsedDate.getDay());
  }
  return '';
}

// --- Components ---

const RegistrationWizard = ({ 
  festival, 
  onClose, 
  user,
  userProfile,
  siteSettings,
  existingRegistration
}: { 
  festival: Festival; 
  onClose: () => void; 
  user: FirebaseUser | null;
  userProfile: any;
  siteSettings: any;
  existingRegistration?: Registration | null;
}) => {
  const [step, setStep] = useState(existingRegistration || !siteSettings.showTermsStep ? 1 : 0); // 0: Terms, 1: Entry, 2: Review
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const [formData, setFormData] = useState({
    groomName: existingRegistration?.groomName || '',
    groomId: existingRegistration?.groomId || '',
    groomPhone: existingRegistration?.groomPhone || '',
    groomEmail: existingRegistration?.groomEmail || '',
    brideName: existingRegistration?.brideName || '',
    brideId: existingRegistration?.brideId || '',
    bridePhone: existingRegistration?.bridePhone || '',
    guardianName: existingRegistration?.guardianName || '', // Bride's guardian
    guardianPhone: existingRegistration?.guardianPhone || '',
    guardianRelation: existingRegistration?.guardianRelation || '',
    groomGuardianName: existingRegistration?.groomGuardianName || '',
    groomGuardianPhone: existingRegistration?.groomGuardianPhone || '',
    groomGuardianRelation: existingRegistration?.groomGuardianRelation || '',
    mahrAmount: existingRegistration?.mahrAmount || '',
    qualification: existingRegistration?.qualification || '',
    employmentStatus: existingRegistration?.employmentStatus || '',
    employmentSector: existingRegistration?.employmentSector || '',
    salary: existingRegistration?.salary || '',
    housingType: existingRegistration?.housingType || '',
    ownershipType: existingRegistration?.ownershipType || '',
    rentAmount: existingRegistration?.rentAmount || '',
    healthStatus: existingRegistration?.healthStatus || '',
    disabilityType: existingRegistration?.disabilityType || '',
    hasSibling: existingRegistration?.hasSibling || false,
    siblingCount: existingRegistration?.siblingCount?.toString() || '1',
    siblingNames: existingRegistration?.siblingNames || [],
    siblingIds: existingRegistration?.siblingIds || [],
  });
  const [validation, setValidation] = useState<Record<string, { error?: string; isValid?: boolean; isChecking?: boolean }>>({});
  const [isSearchingSibling, setIsSearchingSibling] = useState(false);
  const validationCache = useRef<Record<string, { error?: string; warning?: string; isValid?: boolean }>>({});
  const validationTimeout = useRef<Record<string, any>>({});
  const [groomIdAttachment, setGroomIdAttachment] = useState<{ name: string; file?: File; preview: string; type?: string } | null>(() => {
    if (!existingRegistration?.attachments) return null;
    const att = existingRegistration.attachments.find(a => a.name.includes('هوية') || a.name.toLowerCase().includes('id') || a.name.toLowerCase().includes('identity')) || existingRegistration.attachments[0];
    return att ? { name: att.name, preview: att.url, type: att.type } : null;
  });
  const [familyCardAttachment, setFamilyCardAttachment] = useState<{ name: string; file?: File; preview: string; type?: string } | null>(() => {
    if (!existingRegistration?.attachments) return null;
    const att = existingRegistration.attachments.find(a => a.name.includes('عائلة') || a.name.toLowerCase().includes('family')) || existingRegistration.attachments[1];
    return att ? { name: att.name, preview: att.url, type: att.type } : null;
  });
  const [marriageContractAttachment, setMarriageContractAttachment] = useState<{ name: string; file?: File; preview: string; type?: string } | null>(() => {
    if (!existingRegistration?.attachments) return null;
    const att = existingRegistration.attachments.find(a => a.name.includes('نكاح') || a.name.includes('عقد') || a.name.toLowerCase().includes('marriage')) || existingRegistration.attachments[2];
    return att ? { name: att.name, preview: att.url, type: att.type } : null;
  });
  const [paymentMethod, setPaymentMethod] = useState<'online' | 'transfer'>(existingRegistration?.paymentMethod || 'online');
  
  useEffect(() => {
    if (paymentMethod === 'online' && !siteSettings.enableOnlinePayment) {
      setPaymentMethod('transfer');
    } else if (paymentMethod === 'transfer' && !siteSettings.enableTransferPayment) {
      setPaymentMethod('online');
    }
  }, [siteSettings.enableOnlinePayment, siteSettings.enableTransferPayment]);
  const [showPaymentGateway, setShowPaymentGateway] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);

  // Auto-save logic
  useEffect(() => {
    const savedData = localStorage.getItem(`registration_draft_${festival.id}`);
    if (savedData && !existingRegistration) {
      try {
        const parsed = JSON.parse(savedData);
        // Only prompt if there's actual data
        const hasData = Object.values(parsed.formData).some(val => val !== '');
        if (hasData) {
          setIsRestoring(true);
        }
      } catch (e) {
        console.error('Error checking draft:', e);
      }
    }
  }, [festival.id, existingRegistration]);

  useEffect(() => {
    if (!existingRegistration) {
      const hasData = Object.values(formData).some(val => val !== '');
      if (hasData) {
        const timeoutId = setTimeout(() => {
          localStorage.setItem(`registration_draft_${festival.id}`, JSON.stringify({ formData }));
        }, 1000);
        return () => clearTimeout(timeoutId);
      }
    }
  }, [formData, festival.id, existingRegistration]);

  useEffect(() => {
  }, []);

  const getFinalFees = () => {
    if (!formData.hasSibling) return festival.fees;
    if (festival.siblingDiscountType === 'custom_prices') {
       if (formData.siblingCount === '1') return festival.twoBrothersFees || festival.fees;
       if (formData.siblingCount === '2' || formData.siblingCount === '3') return festival.threeBrothersFees || festival.twoBrothersFees || festival.fees;
    }
    return festival.fees;
  };

  const handleRestore = () => {
    const savedData = localStorage.getItem(`registration_draft_${festival.id}`);
    if (savedData) {
      const parsed = JSON.parse(savedData);
      setFormData(parsed.formData);
    }
    setIsRestoring(false);
  };

  const handleDiscard = () => {
    localStorage.removeItem(`registration_draft_${festival.id}`);
    setIsRestoring(false);
  };
  const [paymentReceipt, setPaymentReceipt] = useState<{ name: string; file?: File; preview: string; type?: string } | null>(
    existingRegistration?.paymentReceipt ? { name: existingRegistration.paymentReceipt.name, preview: existingRegistration.paymentReceipt.url, type: existingRegistration.paymentReceipt.type } : null
  );
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [regId, setRegId] = useState(existingRegistration?.id || '');
  const [isSuccess, setIsSuccess] = useState(false);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [step]);

  const validateField = async (name: string, value: string) => {
    let error = '';
    let isValid = false;

    // Use cache if available for this specific value
    const cacheKey = `${name}_${value}`;
    if (validationCache.current[cacheKey]) {
      setValidation(prev => ({ 
        ...prev, 
        [name]: { ...validationCache.current[cacheKey], isChecking: false } 
      }));
      return;
    }

    if (name.endsWith('Id')) {
      if (value.length === 0) {
        error = '';
      } else if (value.length !== 10 || !/^\d+$/.test(value)) {
        error = 'يجب أن يكون رقم الهوية 10 أرقام';
      } else {
        // Clear previous timeout for this field
        if (validationTimeout.current[name]) clearTimeout(validationTimeout.current[name]);

        setValidation(prev => ({ ...prev, [name]: { isChecking: true } }));

        validationTimeout.current[name] = setTimeout(async () => {
          try {
            const qGroom = query(collection(db, 'registrations'), where('groomId', '==', value), limit(1));
            const qBride = query(collection(db, 'registrations'), where('brideId', '==', value), limit(1));
            const [snapGroom, snapBride] = await Promise.all([getDocs(qGroom), getDocs(qBride)]);
            
            const otherDocs = [...snapGroom.docs, ...snapBride.docs].filter(d => d.id !== existingRegistration?.id);
            
            let finalError = '';
            let finalIsValid = false;
            if (otherDocs.length > 0) {
              finalError = 'رقم الهوية مسجل مسبقاً في النظام';
            } else {
              finalIsValid = true;
            }

            const result = { error: finalError, isValid: finalIsValid };
            validationCache.current[cacheKey] = result;
            setValidation(prev => ({ ...prev, [name]: { ...result, isChecking: false } }));
          } catch (err) {
            console.error('Error checking uniqueness:', err);
            setValidation(prev => ({ ...prev, [name]: { isChecking: false } }));
          }
        }, 500);
        return;
      }
    } else if (name.endsWith('Phone')) {
      if (value.length === 0) {
        error = '';
      } else if (value.length !== 10 || !/^\d+$/.test(value)) {
        error = 'يجب أن يكون رقم الجوال 10 أرقام (مثال: 05xxxxxxxx)';
      } else if (existingRegistration && value === (existingRegistration as any)[name]) {
        isValid = true;
      } else if (name === 'groomPhone') {
        if (validationTimeout.current[name]) clearTimeout(validationTimeout.current[name]);

        setValidation(prev => ({ ...prev, [name]: { ...prev[name], isChecking: true } }));
        
        validationTimeout.current[name] = setTimeout(async () => {
          try {
            const qGroom = query(collection(db, 'registrations'), where('groomPhone', '==', value), limit(1));
            const snapGroom = await getDocs(qGroom);
            const otherDocs = snapGroom.docs.filter(d => d.id !== existingRegistration?.id);
            
            let result: any = {};
            if (otherDocs.length > 0) {
              result = { warning: 'رقم الجوال مسجل مسبقاً (تنبيه فقط)', isValid: true };
            } else {
              result = { isValid: true };
            }

            validationCache.current[cacheKey] = result;
            setValidation(prev => ({ ...prev, [name]: { ...result, isChecking: false } }));
          } catch (err) {
            console.error('Error checking phone uniqueness:', err);
            setValidation(prev => ({ ...prev, [name]: { isChecking: false } }));
          }
        }, 500);
        return;
      } else {
        isValid = true;
      }
    } else if (name === 'groomEmail') {
      if (value.length === 0) {
        error = '';
      } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
        error = 'يرجى إدخال بريد إلكتروني صحيح';
      } else {
        isValid = true;
      }
    }

    setValidation(prev => ({ 
      ...prev, 
      [name]: { error, isValid, isChecking: false } 
    }));
  };

  const handleInputChange = (name: string, value: string) => {
    setFormData(prev => ({ ...prev, [name]: value }));
    if (fieldErrors[name]) {
      setFieldErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
    if (name.endsWith('Id') || name.endsWith('Phone') || name === 'groomEmail') {
      validateField(name, value);
    }
  };

  const validateStep1 = () => {
    const newErrors: Record<string, string> = {};
    const { 
      groomName, groomId, groomPhone, groomEmail, mahrAmount,
      groomGuardianName, groomGuardianPhone, groomGuardianRelation,
      brideName, brideId, bridePhone, guardianName, guardianPhone, guardianRelation 
    } = formData;

    if (!groomName) newErrors.groomName = 'يرجى إدخال اسم العريس';
    if (!groomId) newErrors.groomId = 'يرجى إدخال رقم الهوية';
    if (!groomPhone) newErrors.groomPhone = 'يرجى إدخال رقم جوال العريس';
    if (!groomEmail) newErrors.groomEmail = 'يرجى إدخال البريد الإلكتروني';
    if (!mahrAmount) newErrors.mahrAmount = 'يرجى إدخال مبلغ المهر';
    if (!groomGuardianName) newErrors.groomGuardianName = 'يرجى إدخال اسم ممثل العريس';
    if (!groomGuardianPhone) newErrors.groomGuardianPhone = 'يرجى إدخال جوال ممثل العريس';
    if (!groomGuardianRelation) newErrors.groomGuardianRelation = 'يرجى اختيار صلة القرابة';
    if (!brideName) newErrors.brideName = 'يرجى إدخال اسم العروس';
    if (!brideId) newErrors.brideId = 'يرجى إدخال رقم هوية العروس';
    if (!bridePhone) newErrors.bridePhone = 'يرجى إدخال جوال العروس';
    if (!guardianName) newErrors.guardianName = 'يرجى إدخال اسم ممثل العروس';
    if (!guardianPhone) newErrors.guardianPhone = 'يرجى إدخال جوال ممثل العروس';
    if (!guardianRelation) newErrors.guardianRelation = 'يرجى اختيار صلة القرابة';

    // Sibling validation
    if (formData.hasSibling) {
      if (!formData.siblingNames || formData.siblingNames.length === 0 || formData.siblingNames.some(name => !name.trim()) ||
          !formData.siblingIds || formData.siblingIds.length === 0 || formData.siblingIds.some(id => !id.trim() || id.length !== 10 || !/^\d+$/.test(id))) {
        newErrors.siblingNames = 'يرجى إدخال أسماء وأرقام هوية جميع الإخوة';
      }
    }

    // Length/Format validations
    if (groomId && (groomId.length !== 10 || !/^\d+$/.test(groomId))) newErrors.groomId = 'يجب أن يكون رقم الهوية 10 أرقام';
    if (brideId && (brideId.length !== 10 || !/^\d+$/.test(brideId))) newErrors.brideId = 'يجب أن يكون رقم الهوية 10 أرقام';
    
    ['groomPhone', 'groomGuardianPhone', 'bridePhone', 'guardianPhone'].forEach(f => {
      const val = (formData as any)[f];
      if (val && (val.length !== 10 || !/^\d+$/.test(val))) {
        newErrors[f] = 'يجب أن يكون رقم الجوال 10 أرقام';
      }
    });

    if (groomEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(groomEmail)) {
      newErrors.groomEmail = 'يرجى إدخال بريد إلكتروني صحيح';
    }

    // Merge with existing validation errors (like uniqueness)
    Object.keys(validation).forEach(key => {
      if (validation[key]?.error) {
        newErrors[key] = validation[key].error as string;
      }
    });

    setFieldErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateStep2 = () => {
    const newErrors: Record<string, string> = {};
    const { qualification, employmentStatus, salary, housingType, ownershipType, healthStatus } = formData;

    if (!qualification) newErrors.qualification = 'يرجى اختيار المؤهل';
    if (!employmentStatus) newErrors.employmentStatus = 'يرجى اختيار الحالة الوظيفة';
    if (!salary) newErrors.salary = 'يرجى إدخال الراتب';
    if (!housingType) newErrors.housingType = 'يرجى اختيار نوع السكن';
    if (!ownershipType) newErrors.ownershipType = 'يرجى اختيار نوع التملك';
    if (!healthStatus) newErrors.healthStatus = 'يرجى اختيار الحالة الصحية';

    setFieldErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateEntry = () => {
    return validateStep1();
  };

  const goToReview = () => {
    if (validateEntry()) {
      setStep(2);
    }
  };

  const backToEntry = () => {
    setStep(1);
  };

  const handleReceiptChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const maxSizeBytes = (siteSettings.maxFileSizeMB || 5) * 1024 * 1024;
    if (file.size > maxSizeBytes) {
      setError(`الملف ${file.name} يتجاوز الحجم المسموح (${siteSettings.maxFileSizeMB || 5}MB)`);
      setPaymentReceipt(null);
      return;
    }
    const allowedTypes = siteSettings.allowedFileTypes || ['image/jpeg', 'image/png', 'application/pdf'];
    if (!allowedTypes.includes(file.type)) {
      setError(`نوع الملف ${file.name} غير مدعوم`);
      return;
    }

    try {
      const compressedPreview = await compressImage(file);
      setPaymentReceipt({ 
        name: file.name, 
        file, 
        preview: compressedPreview, 
        type: file.type,
        size: file.size 
      });
      setError('');
    } catch (err) {
      console.error('Compression error:', err);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPaymentReceipt({ 
          name: file.name, 
          file, 
          preview: reader.result as string, 
          type: file.type,
          size: file.size
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const removeReceipt = () => {
    setPaymentReceipt(null);
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>, setter: React.Dispatch<React.SetStateAction<{ name: string; file?: File; preview: string; type?: string; size?: number } | null>>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const maxSizeBytes = (siteSettings.maxFileSizeMB || 5) * 1024 * 1024;
    if (file.size > maxSizeBytes) {
      setError(`الملف ${file.name} يتجاوز الحجم المسموح (${siteSettings.maxFileSizeMB || 5}MB)`);
      setter(null);
      return;
    }
    const allowedTypes = siteSettings.allowedFileTypes || ['image/jpeg', 'image/png', 'application/pdf'];
    if (!allowedTypes.includes(file.type)) {
      setError(`نوع الملف ${file.name} غير مدعوم`);
      return;
    }

    try {
      const compressedPreview = await compressImage(file);
      setter({ 
        name: file.name, 
        file, 
        preview: compressedPreview, 
        type: file.type,
        size: file.size
      });
      setError('');
    } catch (err) {
      console.error('Compression error:', err);
      const reader = new FileReader();
      reader.onloadend = () => {
        setter({ 
          name: file.name, 
          file, 
          preview: reader.result as string, 
          type: file.type,
          size: file.size
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    setError('');

    try {
      if (!festival) throw new Error('لم يتم تحديد المهرجان');

      if (!existingRegistration) {
        // Final safety check for uniqueness
        const checkGroomIdG = getDocs(query(collection(db, 'registrations'), where('groomId', '==', formData.groomId), limit(1)));
        const checkGroomIdB = getDocs(query(collection(db, 'registrations'), where('brideId', '==', formData.groomId), limit(1)));
        const checkBrideIdG = getDocs(query(collection(db, 'registrations'), where('groomId', '==', formData.brideId), limit(1)));
        const checkBrideIdB = getDocs(query(collection(db, 'registrations'), where('brideId', '==', formData.brideId), limit(1)));
        const [sGG, sGB, sBG, sBB] = await Promise.all([
          checkGroomIdG, checkGroomIdB, checkBrideIdG, checkBrideIdB
        ]);
        
        if (!sGG.empty || !sGB.empty) throw new Error('رقم هوية العريس مسجل مسبقاً في النظام');
        if (!sBG.empty || !sBB.empty) throw new Error('رقم هوية العروس مسجل مسبقاً في النظام');
      }

      const attachmentData = [
        { key: 'هوية الزوج', att: groomIdAttachment },
        { key: 'كرت العائلة', att: familyCardAttachment },
        { key: 'عقد النكاح', att: marriageContractAttachment }
      ]
        .filter(item => item.att !== null)
        .map(item => {
          if (item.att!.preview && item.att!.preview.length >= 300000) {
            alert(`المرفق ${item.key} كبير جداً. لن يتم حفظه.`);
            return null;
          }
          return {
            name: item.key,
            url: item.att!.preview,
            type: item.att!.type || item.att!.file?.type || 'application/octet-stream'
          };
        })
        .filter(a => a !== null) as { name: string; url: string; type: string }[];

      const paymentReceiptData = paymentReceipt ? {
        name: paymentReceipt.name,
        // Only include url if it is reasonably small, otherwise omit to prevent document size limit errors.
        url: paymentReceipt.preview && paymentReceipt.preview.length < 300000 ? paymentReceipt.preview : '',
        type: paymentReceipt.type || paymentReceipt.file?.type || 'application/octet-stream'
      } : null;

      if (paymentReceipt && paymentReceipt.preview && paymentReceipt.preview.length >= 300000) {
        alert('صورة الحوالة كبيرة جداً. يرجى اختيار صورة بحجم أصغر، ولن يتم حفظ المرفق حالياً.');
      }


      const year = new Date().getFullYear();
      const customId = existingRegistration?.id || `${year}-${formData.groomId}`;

      let calculatedFees = festival.fees;
      if (formData.hasSibling && formData.siblingId) {
        try {
          const siblingDocRef = doc(db, 'registrations', `${year}-${formData.siblingId}`);
          const siblingSnap = await getDoc(siblingDocRef);
          if (siblingSnap.exists()) {
            const siblingData = siblingSnap.data();
            if (siblingData.festivalId === festival.id) {
              const discountType = festival.siblingDiscountType || 'none';
              if (discountType === 'second_free') {
                calculatedFees = 0;
              } else if (discountType === 'third_free') {
                if (siblingData.hasSibling && siblingData.siblingId) {
                  calculatedFees = 0;
                } else {
                  calculatedFees = festival.fees;
                }
              } else if (discountType === 'custom_prices') {
                const base = Number(festival.fees || 0);
                const customTwo = Number(festival.twoBrothersFees || 0);
                const customThree = Number(festival.threeBrothersFees || 0);
                if (siblingData.hasSibling && siblingData.siblingId) {
                  calculatedFees = Math.max(0, customThree - customTwo);
                } else {
                  calculatedFees = Math.max(0, customTwo - base);
                }
              }
            }
          }
        } catch (e) {
          console.error("Error fetching sibling during submission:", e);
        }
      }

      const isNewRegistration = !existingRegistration;
      const batch = writeBatch(db);
      const regRef = doc(db, 'registrations', customId);
      
      batch.set(regRef, {
        ...formData,
        festivalId: festival.id,
        festivalName: festival.name,
        calculatedFees: calculatedFees,
        userId: existingRegistration?.userId || user?.uid || 'guest',
        status: (userProfile?.role === 'admin' || userProfile?.role === 'supervisor') 
          ? (existingRegistration?.status || 'pending') 
          : 'pending',
        attachments: attachmentData,
        paymentMethod: paymentMethod,
        paymentReceipt: paymentReceiptData,
        paymentStatus: existingRegistration?.paymentStatus || 'pending',
        createdAt: existingRegistration?.createdAt || serverTimestamp(),
        updatedAt: serverTimestamp(),
        currentStep: existingRegistration?.currentStep || 0,
        rejectionReason: (userProfile?.role === 'admin' || userProfile?.role === 'supervisor')
          ? (existingRegistration?.rejectionReason || null)
          : null
      }, { merge: true });

      if (isNewRegistration) {
        const festivalRef = doc(db, 'festivals', festival.id);
        batch.update(festivalRef, { registrationCount: increment(1) });
        
        const statsRef = doc(db, 'public_stats', 'global');
        batch.set(statsRef, {
          total: increment(1),
          pending: increment(1)
        }, { merge: true });
      }

      await batch.commit();

      // Send notification to supervisor and admins
      const message = existingRegistration 
        ? `تم تعديل طلب مرفوض من ${formData.groomName} في مهرجان ${festival.name}`
        : `طلب تسجيل جديد من ${formData.groomName} في مهرجان ${festival.name}`;
      const type = existingRegistration ? 'registration_update' : 'registration_new';
      
      await notifyAdminsAndSupervisor(
        festival.id,
        festival.name,
        message,
        type,
        customId,
        festival.supervisorId
      );

      setRegId(customId);
      setIsSuccess(true);
      
      // Clear auto-save draft on success
      localStorage.removeItem(`registration_draft_${festival.id}`);

      // Record Audit Log for any edit
      if (existingRegistration) {
        const isAdminOrSupervisor = userProfile?.role === 'admin' || userProfile?.role === 'supervisor';
        const logUserName = userProfile?.email || `${formData.groomName} (صاحب الطلب)`;
        const logAction = isAdminOrSupervisor ? 'تعديل بيانات الطلب (إدارة)' : 'تعديل بيانات الطلب (صاحب الطلب)';

        await addDoc(collection(db, 'audit_logs'), {
          userId: user?.uid || 'guest',
          userName: logUserName,
          action: logAction,
          registrationId: customId,
          createdAt: serverTimestamp()
        });
      }
    } catch (err: any) {
      setError(err.message || 'حدث خطأ أثناء التسجيل');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isSuccess) {
    return (
      <div className="bg-white dark:bg-slate-900 w-full max-w-md mx-auto rounded-3xl sm:rounded-[3rem] shadow-2xl p-6 sm:p-12 text-center border border-slate-100 dark:border-slate-800">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
        >
          <div className="w-16 h-16 sm:w-24 sm:h-24 bg-emerald-500 text-white rounded-2xl sm:rounded-[2.5rem] flex items-center justify-center mx-auto mb-6 sm:mb-8 shadow-2xl shadow-emerald-200 dark:shadow-emerald-900/20">
            <CheckCircle size={32} className="sm:w-12 sm:h-12" />
          </div>
          <h3 className="text-xl sm:text-3xl font-black text-slate-900 dark:text-white mb-2">
            {existingRegistration ? 'تم تحديث طلبك بنجاح!' : 'تم استلام طلبك بنجاح!'}
          </h3>
          <p className="text-slate-400 font-bold mb-6 sm:mb-8 text-sm sm:text-base">
            تم تسجيل طلبك بنجاح. يمكنك متابعة حالة طلبك أو تعديله باستخدام <span className="text-emerald-600 dark:text-emerald-400 font-black">رقم الهوية</span> الخاص بك.
            <br />
            {existingRegistration 
              ? 'تمت إعادة الطلب للمراجعة، سيقوم المشرف المسؤول بالاطلاع عليه قريباً.'
              : 'تم إرسال إشعار للمشرف المسؤول لمراجعة طلبك.'}
          </p>
          <button onClick={onClose} className="w-full py-3 sm:py-4 bg-slate-900 dark:bg-emerald-600 text-white rounded-xl sm:rounded-2xl font-black hover:bg-slate-800 dark:hover:bg-emerald-700 transition shadow-xl text-sm sm:text-base">
            العودة للرئيسية
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="w-full max-w-4xl mx-auto px-2 sm:px-0">
      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="bg-white dark:bg-slate-900 w-full rounded-2xl shadow-sm overflow-hidden flex flex-col border border-stone-100 dark:border-slate-800"
      >
        {/* Header */}
        <div className="bg-emerald-600 p-4 sm:p-8 text-white relative flex-shrink-0">
          <button onClick={onClose} className="absolute top-4 sm:top-6 left-4 sm:left-6 flex items-center gap-2 px-3 sm:px-4 py-1.5 sm:py-2 hover:bg-white/10 rounded-lg sm:rounded-xl transition font-bold text-[10px] sm:text-sm">
            <X size={16} className="sm:w-5 sm:h-5" />
            <span>إلغاء</span>
          </button>
          <div className="flex items-center gap-3 sm:gap-4">
            <div className="w-10 h-10 sm:w-12 sm:h-12 bg-white/20 rounded-xl sm:rounded-2xl flex items-center justify-center">
              <Calendar size={20} className="sm:w-6 sm:h-6" />
            </div>
            <div>
              <h3 className="text-lg sm:text-2xl font-black">
                {existingRegistration ? 'تعديل طلب التسجيل' : 'استمارة التسجيل'}
              </h3>
              <p className="text-emerald-100 font-bold text-[10px] sm:text-sm">{festival.name}</p>
            </div>
          </div>
        </div>

        {/* Restore Draft Banner */}
        {isRestoring && (
          <div className="bg-amber-50 dark:bg-amber-900/20 border-b border-amber-200 dark:border-amber-800 p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Clock className="w-5 h-5 text-amber-600 dark:text-amber-400" />
              <span className="text-amber-800 dark:text-amber-200 text-sm font-bold">لديك مسودة محفوظة لهذا المهرجان. هل تريد استعادتها؟</span>
            </div>
            <div className="flex gap-2">
              <button onClick={handleRestore} className="px-3 py-1.5 bg-amber-600 text-white rounded-lg text-xs font-bold hover:bg-amber-700 transition-colors">استعادة</button>
              <button onClick={handleDiscard} className="px-3 py-1.5 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-lg text-xs font-bold hover:bg-slate-300 dark:hover:bg-slate-600 transition-colors">تجاهل</button>
            </div>
          </div>
        )}

        <div className="p-3.5 sm:p-8 overflow-y-auto flex-grow min-h-[300px] sm:min-h-[400px]">
          {/* Progress Indicator - Professional & Compact */}
          <div className="mb-10 sm:mb-12 flex items-center justify-between w-full max-w-2xl mx-auto px-2">
            {(siteSettings.showTermsStep && !existingRegistration) && (
              <>
                <div className="flex flex-col items-center gap-2 group relative">
                  <div className={`w-8 h-8 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center text-[10px] sm:text-xs font-black transition-all duration-500 ${step === 0 ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-200 dark:shadow-none scale-110' : 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400'}`}>
                    1
                  </div>
                  <span className={`hidden md:block text-[10px] font-black transition-colors ${step === 0 ? 'text-emerald-600' : 'text-slate-400'}`}>الشروط</span>
                  {step === 0 && <span className="md:hidden absolute -bottom-5 text-[9px] font-black text-emerald-600 whitespace-nowrap">الشروط</span>}
                </div>
                <div className={`flex-1 h-0.5 mx-2 rounded-full transition-colors duration-500 ${step > 0 ? 'bg-emerald-500' : 'bg-slate-100 dark:bg-slate-800'}`} />
              </>
            )}
            
            <div className="flex flex-col items-center gap-2 group relative">
              <div className={`w-8 h-8 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center text-[10px] sm:text-xs font-black transition-all duration-500 ${step === 1 ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-200 dark:shadow-none scale-110' : (step > 1 ? 'bg-emerald-500 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-500')}`}>
                {(siteSettings.showTermsStep && !existingRegistration) ? 2 : 1}
              </div>
              <span className={`hidden md:block text-[10px] font-black transition-colors ${step === 1 ? 'text-emerald-600' : (step > 1 ? 'text-emerald-500' : 'text-slate-400')}`}>البيانات</span>
              {step === 1 && <span className="md:hidden absolute -bottom-5 text-[9px] font-black text-emerald-600 whitespace-nowrap">البيانات</span>}
            </div>
            
            <div className={`flex-1 h-0.5 mx-2 rounded-full transition-colors duration-500 ${step > 1 ? 'bg-emerald-500' : 'bg-slate-100 dark:bg-slate-800'}`} />
            
            {siteSettings.showSocialStep !== false && (
              <>
                <div className="flex flex-col items-center gap-2 group relative">
                  <div className={`w-8 h-8 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center text-[10px] sm:text-xs font-black transition-all duration-500 ${step === 2 ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-200 dark:shadow-none scale-110' : (step > 2 ? 'bg-emerald-500 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-500')}`}>
                    {(siteSettings.showTermsStep && !existingRegistration) ? 3 : 2}
                  </div>
                  <span className={`hidden md:block text-[10px] font-black transition-colors ${step === 2 ? 'text-emerald-600' : (step > 2 ? 'text-emerald-500' : 'text-slate-400')}`}>اجتماعية</span>
                  {step === 2 && <span className="md:hidden absolute -bottom-5 text-[9px] font-black text-emerald-600 whitespace-nowrap">اجتماعية</span>}
                </div>
                
                <div className={`flex-1 h-0.5 mx-2 rounded-full transition-colors duration-500 ${step > 2 ? 'bg-emerald-500' : 'bg-slate-100 dark:bg-slate-800'}`} />
              </>
            )}
            
            <div className="flex flex-col items-center gap-2 group relative">
              <div className={`w-8 h-8 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center text-[10px] sm:text-xs font-black transition-all duration-500 ${step === 3 ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-200 dark:shadow-none scale-110' : (step > 3 ? 'bg-emerald-500 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-500')}`}>
                {(siteSettings.showTermsStep && !existingRegistration) 
                  ? (siteSettings.showSocialStep !== false ? 4 : 3) 
                  : (siteSettings.showSocialStep !== false ? 3 : 2)}
              </div>
              <span className={`hidden md:block text-[10px] font-black transition-colors ${step === 3 ? 'text-emerald-600' : (step > 3 ? 'text-emerald-500' : 'text-slate-400')}`}>المرفقات</span>
              {step === 3 && <span className="md:hidden absolute -bottom-5 text-[9px] font-black text-emerald-600 whitespace-nowrap">المرفقات</span>}
            </div>
            
            <div className={`flex-1 h-0.5 mx-2 rounded-full transition-colors duration-500 ${step > 3 ? 'bg-emerald-500' : 'bg-slate-100 dark:bg-slate-800'}`} />
            
            <div className="flex flex-col items-center gap-2 group relative">
              <div className={`w-8 h-8 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center text-[10px] sm:text-xs font-black transition-all duration-500 ${step === 4 ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-200 dark:shadow-none scale-110' : 'bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-500'}`}>
                {(siteSettings.showTermsStep && !existingRegistration) 
                  ? (siteSettings.showSocialStep !== false ? 5 : 4) 
                  : (siteSettings.showSocialStep !== false ? 4 : 3)}
              </div>
              <span className={`hidden md:block text-[10px] font-black transition-colors ${step === 4 ? 'text-emerald-600' : 'text-slate-400'}`}>المراجعة</span>
              {step === 4 && <span className="md:hidden absolute -bottom-5 text-[9px] font-black text-emerald-600 whitespace-nowrap">المراجعة</span>}
            </div>
          </div>

          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-100 text-red-600 rounded-2xl flex items-center gap-3 text-sm font-bold">
              <AlertCircle size={18} />
              {error}
            </div>
          )}

          <AnimatePresence mode="wait">
            <motion.div
              key={step}
              initial={{ x: 20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -20, opacity: 0 }}
              transition={{ duration: 0.2 }}
            >
              {step === 0 && (
                <div className="space-y-10 sm:space-y-12">
                  <div className="bg-slate-50 dark:bg-slate-800/30 p-5 sm:p-10 rounded-[2rem] sm:rounded-[2.5rem] border border-slate-100 dark:border-slate-800">
                    <h4 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mb-8 flex items-center gap-3">
                      <div className="w-10 h-10 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-xl flex items-center justify-center"><AlertCircle size={24} /></div>
                      الشروط والتعليمات الهامة
                    </h4>
                    
                    <div className="space-y-4 mb-10">
                    {(siteSettings.terms || []).map((term: string, index: number) => (
                      <div key={`term-step-${index}`} className="flex gap-4 items-start p-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800">
                          <span className="flex-shrink-0 w-6 h-6 bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-full flex items-center justify-center text-xs font-black">{index + 1}</span>
                          <p className="text-sm sm:text-base font-bold text-slate-700 dark:text-slate-300 leading-relaxed">{term}</p>
                        </div>
                      ))}
                      {(!siteSettings.terms || siteSettings.terms.length === 0) && (
                        <p className="text-center py-10 text-slate-400 font-bold italic">لا توجد شروط مضافة حالياً. يمكنك المتابعة.</p>
                      )}
                    </div>

                    {festival.siblingDiscountType && festival.siblingDiscountType !== 'none' && (
                      <div className="mt-6 pt-6 border-t border-slate-200/60 dark:border-slate-800">
                        <div className="bg-emerald-50/50 dark:bg-emerald-950/20 p-6 rounded-2xl border border-emerald-100 dark:border-emerald-900/40">
                          <div className="flex items-start gap-3">
                            <input
                              type="checkbox"
                              id="hasSiblingCheckbox"
                              checked={formData.hasSibling}
                              onChange={(e) => handleInputChange('hasSibling', e.target.checked)}
                              className="mt-1 h-5 w-5 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                            />
                            <div className="flex-1">
                              <label htmlFor="hasSiblingCheckbox" className="text-sm font-black text-slate-900 dark:text-white cursor-pointer select-none">
                                هل لديك أخ (أو أكثر) مسجل في هذا المهرجان؟
                              </label>
                              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                                تفعيل هذا الخيار يتيح لك الاستفادة من خصومات الإخوة أو الرسوم التشجيعية المخصصة للمجموعات الأخوية المسجلة في المهرجان.
                              </p>
                            </div>
                          </div>

                          {formData.hasSibling && (
                            <motion.div
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: 'auto' }}
                              className="space-y-4 mt-6 pt-4 border-t border-emerald-100/50 dark:border-emerald-900/20"
                            >
                              <div className="w-full max-w-md">
                                <Select
                                  label="عدد الإخوة المشاركين معك"
                                  value={formData.siblingCount || '1'}
                                  onChange={(v: string) => {
                                    const count = parseInt(v) || 0;
                                    handleInputChange('siblingCount', v);
                                    setFormData(prev => ({ 
                                      ...prev, 
                                      siblingNames: Array(count).fill(''), 
                                      siblingIds: Array(count).fill('') 
                                    }));
                                  }}
                                  options={[
                                    { label: 'أخ واحد', value: '1' },
                                    { label: 'أخوين', value: '2' },
                                    { label: 'ثلاثة إخوة', value: '3' },
                                  ]}
                                />
                              </div>
                              
                              {Array.from({ length: parseInt(formData.siblingCount || '1') || 0 }).map((_, i) => (
                                <div key={i} className="grid grid-cols-2 gap-4">
                                  <div className="w-full">
                                    <Input
                                      label={`اسم الأخ الرباعي ${i + 1}`}
                                      value={formData.siblingNames?.[i] || ''}
                                      onChange={(v: string) => {
                                        const newNames = [...(formData.siblingNames || [])];
                                        newNames[i] = v;
                                        setFormData(prev => ({ ...prev, siblingNames: newNames }));
                                      }}
                                      placeholder="الاسم..."
                                    />
                                  </div>
                                  <div className="w-full">
                                    <Input
                                      label={`رقم الهوية ${i + 1}`}
                                      value={formData.siblingIds?.[i] || ''}
                                      onChange={(v: string) => {
                                        const newIds = [...(formData.siblingIds || [])];
                                        newIds[i] = v;
                                        setFormData(prev => ({ ...prev, siblingIds: newIds }));
                                      }}
                                      placeholder="رقم الهوية..."
                                      maxLength={10}
                                    />
                                  </div>
                                </div>
                              ))}
                            </motion.div>
                          )}
                        </div>
                      </div>
                    )}

                    <div className="border-t border-slate-100 dark:border-slate-800 pt-8 mt-6">
                      <label className="flex items-center gap-4 cursor-pointer group p-4 rounded-2xl hover:bg-white dark:hover:bg-slate-900 transition-all border border-transparent hover:border-emerald-100 dark:hover:border-emerald-900/30">
                        <input 
                          type="checkbox" 
                          checked={acceptedTerms}
                          onChange={(e) => setAcceptedTerms(e.target.checked)}
                          className="w-6 h-6 rounded-lg text-emerald-600 focus:ring-emerald-500 border-slate-300 dark:border-slate-700 cursor-pointer"
                        />
                        <span className="text-sm sm:text-base font-black text-slate-800 dark:text-slate-100 transition-colors group-hover:text-emerald-600 dark:group-hover:text-emerald-400">أتعهد وأقر بالاطلاع والموافقة على كافة الشروط والتعليمات المذكورة أعلاه.</span>
                      </label>
                    </div>
                  </div>
                </div>
              )}

              {step === 1 && (
                <div className="space-y-10 sm:space-y-16">
                  {/* Festival Highlights Section */}
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 }}
                    className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-6"
                  >
                    {/* Fees Card */}
                    <div className="relative group overflow-hidden bg-gradient-to-br from-emerald-600 to-emerald-800 p-5 sm:p-8 rounded-[1.8rem] sm:rounded-[2rem] text-white shadow-xl shadow-emerald-200 dark:shadow-emerald-900/40">
                      <div className="absolute -right-6 -top-6 w-32 h-32 bg-white/10 rounded-full blur-2xl group-hover:scale-150 transition-transform duration-700" />
                      <div className="absolute -left-6 -bottom-6 w-24 h-24 bg-emerald-400/20 rounded-full blur-xl group-hover:scale-150 transition-transform duration-700" />
                      
                      <div className="relative flex items-center justify-between">
                        <div className="space-y-1">
                          <p className="text-emerald-100/80 font-black text-[10px] uppercase tracking-wider">
                            {!formData.hasSibling 
                              ? 'رسوم الاشتراك المعتمدة للفرد الواحد' 
                              : formData.siblingCount === '1' 
                                ? 'رسوم الاشتراك المعتمدة للأخوين' 
                                : 'رسوم الاشتراك المعتمدة لثلاثة إخوة'}
                          </p>
                          <div className="flex items-baseline gap-2">
                            <span className="text-4xl sm:text-5xl font-black tracking-tight">{getFinalFees()}</span>
                            <span className="text-lg font-bold opacity-80">ريال</span>
                          </div>
                        </div>
                        <div className="w-16 h-16 bg-white/10 backdrop-blur-md rounded-2xl flex items-center justify-center border border-white/20 shadow-inner">
                          <CreditCard size={32} className="text-white" />
                        </div>
                      </div>
                    </div>

                    {/* Date Card */}
                    <div className="relative group overflow-hidden bg-gradient-to-br from-indigo-600 to-violet-700 p-5 sm:p-8 rounded-[1.8rem] sm:rounded-[2rem] text-white shadow-xl shadow-indigo-200 dark:shadow-indigo-900/40">
                      <div className="absolute -right-6 -top-6 w-32 h-32 bg-white/10 rounded-full blur-2xl group-hover:scale-150 transition-transform duration-700" />
                      <div className="absolute -left-6 -bottom-6 w-24 h-24 bg-indigo-400/20 rounded-full blur-xl group-hover:scale-150 transition-transform duration-700" />
                      
                      <div className="relative flex items-center justify-between">
                        <div className="space-y-1">
                          <p className="text-indigo-100/80 font-black text-[10px] uppercase tracking-wider">موعد إقامة الحفل</p>
                          <div className="flex flex-col gap-1">
                            <span className="text-2xl sm:text-3xl font-black">{festival.date || 'سيحدد لاحقاً'}</span>
                            {festival.date && (
                              <span className="text-xs font-bold text-indigo-100 opacity-90">
                                {getArabicDayWithNight(festival.date)}
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="w-16 h-16 bg-white/10 backdrop-blur-md rounded-2xl flex items-center justify-center border border-white/20 shadow-inner group-hover:rotate-6 transition-transform">
                          <Calendar size={32} className="text-white" />
                        </div>
                      </div>
                    </div>
                  </motion.div>

                  {/* Groom Section */}
                  <section className="bg-slate-50/50 dark:bg-slate-800/30 p-3.5 sm:p-8 rounded-[1.5rem] sm:rounded-[2.5rem] border border-slate-100 dark:border-slate-800">
                    <h4 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mb-6 flex items-center gap-3">
                      <div className="w-8 h-8 sm:w-10 sm:h-10 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-lg sm:rounded-xl flex items-center justify-center"><User size={16} className="sm:w-5 sm:h-5" /></div>
                      بيانات العريس ومن يمثله
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6 mb-4 sm:mb-6">
                      <div className="md:col-span-1">
                        <Input label="الاسم الرباعي للعريس" value={formData.groomName} onChange={(v: string) => handleInputChange('groomName', v)} placeholder="أدخل الاسم الرباعي..." error={fieldErrors.groomName} />
                      </div>
                      <Input 
                        label="رقم الهوية" 
                        value={formData.groomId} 
                        onChange={(v: string) => handleInputChange('groomId', v)} 
                        maxLength={10} 
                        placeholder="10 أرقام..." 
                        error={fieldErrors.groomId || validation.groomId?.error}
                        isValid={validation.groomId?.isValid}
                        isChecking={validation.groomId?.isChecking}
                      />
                      <Input 
                        label="رقم الجوال" 
                        value={formData.groomPhone} 
                        onChange={(v: string) => handleInputChange('groomPhone', v)} 
                        maxLength={10}
                        placeholder="05xxxxxxxx" 
                        error={fieldErrors.groomPhone || validation.groomPhone?.error}
                        warning={validation.groomPhone?.warning}
                        isValid={validation.groomPhone?.isValid}
                      />
                      <Input 
                        label="البريد الإلكتروني للعريس" 
                        value={formData.groomEmail} 
                        onChange={(v: string) => handleInputChange('groomEmail', v)} 
                        placeholder="example@mail.com" 
                        error={fieldErrors.groomEmail || validation.groomEmail?.error}
                        isValid={validation.groomEmail?.isValid}
                      />
                      <Input 
                        label="مبلغ المهر" 
                        type="number"
                        value={formData.mahrAmount} 
                        onChange={(v: string) => handleInputChange('mahrAmount', v)} 
                        placeholder="أدخل المبلغ..." 
                        error={fieldErrors.mahrAmount}
                      />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6">
                      <Input label="اسم ممثل العريس" value={formData.groomGuardianName} onChange={(v: string) => handleInputChange('groomGuardianName', v)} placeholder="أدخل الاسم..." error={fieldErrors.groomGuardianName} />
                      <Select 
                        label="صلة القرابة" 
                        value={formData.groomGuardianRelation} 
                        onChange={(v: string) => handleInputChange('groomGuardianRelation', v)} 
                        options={[
                          { label: 'أب', value: 'أب' },
                          { label: 'جد', value: 'جد' },
                          { label: 'أخ', value: 'أخ' },
                          { label: 'عم', value: 'عم' },
                          { label: 'خال', value: 'خال' },
                        ]} 
                        error={fieldErrors.groomGuardianRelation}
                      />
                      <Input 
                        label="جوال ممثل العريس" 
                        value={formData.groomGuardianPhone} 
                        onChange={(v: string) => handleInputChange('groomGuardianPhone', v)} 
                        maxLength={10}
                        placeholder="05xxxxxxxx" 
                        error={fieldErrors.groomGuardianPhone || validation.groomGuardianPhone?.error}
                        isValid={validation.groomGuardianPhone?.isValid}
                      />
                    </div>


                  </section>

                  {/* Bride Section */}
                  <section className="bg-slate-50/50 dark:bg-slate-800/30 p-3.5 sm:p-8 rounded-[1.5rem] sm:rounded-[2.5rem] border border-slate-100 dark:border-slate-800">
                    <h4 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mb-6 flex items-center gap-3">
                      <div className="w-8 h-8 sm:w-10 sm:h-10 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-lg sm:rounded-xl flex items-center justify-center"><User size={16} className="sm:w-5 sm:h-5" /></div>
                      بيانات العروس ومن يمثلها
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6 mb-4 sm:mb-6">
                      <Input label="الاسم الرباعي للعروس" value={formData.brideName} onChange={(v: string) => handleInputChange('brideName', v)} placeholder="أدخل الاسم الرباعي..." error={fieldErrors.brideName} />
                      <Input 
                        label="رقم الهوية" 
                        value={formData.brideId} 
                        onChange={(v: string) => handleInputChange('brideId', v)} 
                        maxLength={10} 
                        placeholder="10 أرقام..." 
                        error={fieldErrors.brideId || validation.brideId?.error}
                        isValid={validation.brideId?.isValid}
                        isChecking={validation.brideId?.isChecking}
                      />
                      <Input 
                        label="رقم الجوال" 
                        value={formData.bridePhone} 
                        onChange={(v: string) => handleInputChange('bridePhone', v)} 
                        maxLength={10}
                        placeholder="05xxxxxxxx" 
                        error={fieldErrors.bridePhone || validation.bridePhone?.error}
                        isValid={validation.bridePhone?.isValid}
                      />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6">
                      <Input label="اسم ممثل العروس" value={formData.guardianName} onChange={(v: string) => handleInputChange('guardianName', v)} placeholder="أدخل الاسم..." error={fieldErrors.guardianName} />
                      <Select 
                        label="صلة القرابة" 
                        value={formData.guardianRelation} 
                        onChange={(v: string) => handleInputChange('guardianRelation', v)} 
                        options={[
                          { label: 'أب', value: 'أب' },
                          { label: 'جد', value: 'جد' },
                          { label: 'أخ', value: 'أخ' },
                          { label: 'عم', value: 'عم' },
                          { label: 'خال', value: 'خال' },
                        ]} 
                        error={fieldErrors.guardianRelation}
                      />
                      <Input 
                        label="جوال ممثل العروس" 
                        value={formData.guardianPhone} 
                        onChange={(v: string) => handleInputChange('guardianPhone', v)} 
                        maxLength={10}
                        placeholder="05xxxxxxxx" 
                        error={fieldErrors.guardianPhone || validation.guardianPhone?.error}
                        isValid={validation.guardianPhone?.isValid}
                      />
                    </div>
                  </section>
                </div>
              )}

              {step === 2 && siteSettings.showSocialStep !== false && (
                <div className="space-y-10 sm:space-y-12">
                  <section className="bg-slate-50/50 dark:bg-slate-800/30 p-3.5 sm:p-8 rounded-[1.5rem] sm:rounded-[2.5rem] border border-slate-100 dark:border-slate-800">
                    <h4 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mb-6 flex items-center gap-3">
                      <div className="w-8 h-8 sm:w-10 sm:h-10 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-lg sm:rounded-xl flex items-center justify-center"><Users size={16} className="sm:w-5 sm:h-5" /></div>
                      بيانات اجتماعية ومهنية
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6 mb-8">
                      <Select 
                        label="المؤهل الدراسي" 
                        value={formData.qualification} 
                        onChange={(v: string) => handleInputChange('qualification', v)} 
                        options={[
                          { label: 'ابتدائي', value: 'ابتدائي' },
                          { label: 'متوسط', value: 'متوسط' },
                          { label: 'ثانوي', value: 'ثانوي' },
                          { label: 'جامعي', value: 'جامعي' },
                        ]} 
                        error={fieldErrors.qualification}
                      />
                      <Select 
                        label="الحالة الوظيفية" 
                        value={formData.employmentStatus} 
                        onChange={(v: string) => handleInputChange('employmentStatus', v)} 
                        options={[
                          { label: 'موظف', value: 'موظف' },
                          { label: 'عاطل', value: 'عاطل' },
                        ]} 
                        error={fieldErrors.employmentStatus}
                      />
                      {formData.employmentStatus === 'موظف' && (
                        <Select 
                          label="قطاع التوظيف" 
                          value={formData.employmentSector} 
                          onChange={(v: string) => handleInputChange('employmentSector', v)} 
                          options={[
                            { label: 'خاص', value: 'خاص' },
                            { label: 'حكومي', value: 'حكومي' },
                          ]} 
                          error={fieldErrors.employmentSector}
                        />
                      )}
                      <Input label="الراتب كاملاً مع البدلات" value={formData.salary} onChange={(v: string) => handleInputChange('salary', v)} placeholder="أدخل الراتب..." error={fieldErrors.salary} />
                    </div>

                    <h4 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mb-6 flex items-center gap-3 border-t border-slate-100 dark:border-slate-800 pt-8">
                      <div className="w-8 h-8 sm:w-10 sm:h-10 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-lg sm:rounded-xl flex items-center justify-center"><Home size={16} className="sm:w-5 sm:h-5" /></div>
                      بيانات السكن
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6 mb-8">
                      <Select 
                        label="نوع السكن" 
                        value={formData.housingType} 
                        onChange={(v: string) => handleInputChange('housingType', v)} 
                        options={[
                          { label: 'شقة', value: 'شقة' },
                          { label: 'بيت', value: 'بيت' },
                        ]} 
                        error={fieldErrors.housingType}
                      />
                      <Select 
                        label="نوع التملك" 
                        value={formData.ownershipType} 
                        onChange={(v: string) => handleInputChange('ownershipType', v)} 
                        options={[
                          { label: 'إيجار', value: 'إيجار' },
                          { label: 'ملك', value: 'ملك' },
                          { label: 'مشترك عائلي', value: 'مشترك عائلي' },
                        ]} 
                        error={fieldErrors.ownershipType}
                      />
                      {formData.ownershipType === 'إيجار' && (
                        <Input label="مبلغ الإيجار السنوي" value={formData.rentAmount} onChange={(v: string) => handleInputChange('rentAmount', v)} placeholder="أدخل المبلغ..." error={fieldErrors.rentAmount} />
                      )}
                    </div>

                    <h4 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mb-6 flex items-center gap-3 border-t border-slate-100 dark:border-slate-800 pt-8">
                      <div className="w-8 h-8 sm:w-10 sm:h-10 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-lg sm:rounded-xl flex items-center justify-center"><Heart size={16} className="sm:w-5 sm:h-5" /></div>
                      الحالة الصحية
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
                      <Select 
                        label="الحالة الصحية" 
                        value={formData.healthStatus} 
                        onChange={(v: string) => handleInputChange('healthStatus', v)} 
                        options={[
                          { label: 'سليم', value: 'سليم' },
                          { label: 'مريض مرض مزمن', value: 'مريض مرض مزمن' },
                          { label: 'معاق', value: 'معاق' },
                        ]} 
                        error={fieldErrors.healthStatus}
                      />
                      {(formData.healthStatus === 'معاق' || formData.healthStatus === 'مريض مرض مزمن') && (
                        <Input label="نوع الإعاقة أو المرض" value={formData.disabilityType} onChange={(v: string) => handleInputChange('disabilityType', v)} placeholder="وضح الحالة..." error={fieldErrors.disabilityType} />
                      )}
                    </div>
                  </section>
                </div>
              )}

              {step === 3 && (
                <div className="space-y-10 sm:space-y-16">
                  {/* Attachments Section */}
                  <section className="bg-slate-50/50 dark:bg-slate-800/30 p-4 sm:p-8 rounded-[1.5rem] sm:rounded-[2.5rem] border border-slate-100 dark:border-slate-800">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                      <h4 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white flex items-center gap-3">
                        <div className="w-8 h-8 sm:w-10 sm:h-10 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-lg sm:rounded-xl flex items-center justify-center"><Paperclip size={16} className="sm:w-5 sm:h-5" /></div>
                        المرفقات المطلوبة
                      </h4>
                      {existingRegistration?.rejectionReason && (
                        <div className="bg-red-50 dark:bg-red-900/20 px-4 py-2 rounded-xl border border-red-100 dark:border-red-800 flex items-center gap-2">
                          <AlertCircle size={14} className="text-red-500" />
                          <span className="text-[10px] font-bold text-red-600 dark:text-red-400">ملاحظة الإدارة: {existingRegistration.rejectionReason}</span>
                        </div>
                      )}
                    </div>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                      {[
                        { id: 'groom-id', label: 'صورة الهوية الوطنية للزوج', attachment: groomIdAttachment, onChange: (e: React.ChangeEvent<HTMLInputElement>) => handleFileChange(e, setGroomIdAttachment), onRemove: () => setGroomIdAttachment(null) },
                        { id: 'family-card', label: 'صورة بطاقة العائلة', attachment: familyCardAttachment, onChange: (e: React.ChangeEvent<HTMLInputElement>) => handleFileChange(e, setFamilyCardAttachment), onRemove: () => setFamilyCardAttachment(null) },
                        { id: 'marriage-contract', label: 'صورة عقد النكاح', attachment: marriageContractAttachment, onChange: (e: React.ChangeEvent<HTMLInputElement>) => handleFileChange(e, setMarriageContractAttachment), onRemove: () => setMarriageContractAttachment(null) },
                      ].map((item) => (
                        <div key={item.id} className="flex flex-col gap-3">
                          <div className={`relative group aspect-square rounded-[2rem] border-2 border-dashed transition-all overflow-hidden ${item.attachment ? 'border-emerald-500 bg-emerald-50/30' : 'border-slate-200 dark:border-slate-700 hover:border-emerald-500 hover:bg-emerald-50'}`}>
                            {item.attachment ? (
                              <>
                                {item.attachment.type?.includes('pdf') ? (
                                  <div className="w-full h-full flex flex-col items-center justify-center bg-white dark:bg-slate-900">
                                    <FileText size={48} className="text-emerald-500 mb-2" />
                                    <span className="text-[10px] font-black text-slate-500 truncate w-full px-4 text-center">{item.attachment.name}</span>
                                    {!item.attachment.file && <span className="absolute top-4 right-4 bg-emerald-500 text-white text-[8px] font-black px-2 py-1 rounded-full px-2">ملف حالي</span>}
                                  </div>
                                ) : (
                                  <>
                                    <img src={item.attachment.preview} alt="preview" className="w-full h-full object-cover" />
                                    {!item.attachment.file && (
                                      <div className="absolute top-4 right-4 bg-emerald-500/90 text-white text-[8px] font-black px-2 py-1 rounded-full backdrop-blur-sm">
                                        ملف حالي
                                      </div>
                                    )}
                                  </>
                                )}
                                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                                  <a 
                                    href={item.attachment.preview} 
                                    target="_blank" 
                                    rel="noopener noreferrer"
                                    className="p-3 bg-white text-slate-900 rounded-2xl hover:bg-slate-100 transition shadow-lg"
                                    title="عرض المرفق"
                                  >
                                    <Eye size={20} />
                                  </a>
                                  <button 
                                    onClick={(e) => { e.preventDefault(); item.onRemove(); }}
                                    className="p-3 bg-red-500 text-white rounded-2xl hover:bg-red-600 transition shadow-lg"
                                    title="حذف واستبدال"
                                  >
                                    <Trash2 size={20} />
                                  </button>
                                </div>
                              </>
                            ) : (
                              <label className="w-full h-full flex flex-col items-center justify-center cursor-pointer p-4 text-center">
                                <div className="w-12 h-12 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 rounded-2xl flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                                  <Upload size={24} />
                                </div>
                                <span className="text-xs font-black text-slate-600 dark:text-slate-400">انقر لرفع ملف</span>
                                <p className="text-[10px] font-bold text-slate-400 mt-1">PNG, JPG, PDF • بحد أقصى {siteSettings.maxFileSizeMB || 5}MB</p>
                                <input type="file" onChange={item.onChange} className="hidden" accept=".jpg,.jpeg,.png,.pdf" />
                              </label>
                            )}
                          </div>
                          <div className="flex flex-col text-center">
                            <span className="text-xs font-black text-slate-800 dark:text-slate-200">{item.label}</span>
                            {!item.attachment && <span className="text-[10px] font-bold text-red-500 mt-1">* مطلوب</span>}
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="mt-8 flex justify-center">
                      <div className="inline-flex items-center gap-3 px-6 py-3 bg-slate-100/50 dark:bg-slate-800/30 rounded-2xl border border-slate-100 dark:border-slate-800">
                        <div className="w-8 h-8 bg-white dark:bg-slate-900 rounded-xl flex items-center justify-center shadow-sm text-emerald-500">
                          <Info size={16} />
                        </div>
                        <div className="flex flex-col text-right">
                          <span className="text-xs font-black text-slate-700 dark:text-slate-200">تعليمات الرفع</span>
                          <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 leading-tight">
                            الحد الأقصى لحجم كل ملف هو <span className="text-emerald-600 dark:text-emerald-400">{siteSettings.maxFileSizeMB || 5} ميجابايت</span>. يرجى التأكد من وضوح المستندات.
                          </span>
                        </div>
                      </div>
                    </div>

                    {existingRegistration && (
                      <p className="mt-6 text-[10px] font-bold text-slate-500 bg-slate-100 dark:bg-slate-800/50 p-3 rounded-xl border border-slate-200 dark:border-slate-700 text-center">
                        يمكنك الاحتفاظ بالمرفقات الحالية أو حذفها لإرفاق ملفات جديدة في حالة طلب التعديل.
                      </p>
                    )}
                  </section>

                  {/* Payment Section */}
                  {(siteSettings.enableOnlinePayment || siteSettings.enableTransferPayment) && existingRegistration && existingRegistration.status === 'approved' && (
                    <section className="bg-slate-50/50 dark:bg-slate-800/30 p-4 sm:p-8 rounded-[1.5rem] sm:rounded-[2.5rem] border border-slate-100 dark:border-slate-800">
                      <h4 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white mb-6 flex items-center gap-3">
                        <div className="w-8 h-8 sm:w-10 sm:h-10 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-lg sm:rounded-xl flex items-center justify-center"><CreditCard size={16} className="sm:w-5 sm:h-5" /></div>
                        بيانات السداد (رسوم التسجيل: {festival.fees} ريال)
                      </h4>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                        {siteSettings.enableOnlinePayment && (
                          <button
                            type="button"
                            onClick={() => setPaymentMethod('online')}
                            className={`p-4 rounded-2xl border-2 font-bold flex flex-col items-center gap-2 transition ${paymentMethod === 'online' ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400' : 'border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'}`}
                          >
                            <CreditCard size={24} />
                            <span>دفع إلكتروني</span>
                          </button>
                        )}
                        {siteSettings.enableTransferPayment && (
                          <button
                            type="button"
                            onClick={() => setPaymentMethod('transfer')}
                            className={`p-4 rounded-2xl border-2 font-bold flex flex-col items-center gap-2 transition ${paymentMethod === 'transfer' ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400' : 'border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'}`}
                          >
                            <Upload size={24} />
                            <span>تحويل بنكي</span>
                          </button>
                        )}
                      </div>

                      {paymentMethod === 'transfer' && (
                        <div className="space-y-4">
                          <div className="bg-slate-100/50 dark:bg-slate-900/50 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 text-center">
                            <p className="text-xs font-bold text-slate-500 mb-2">يرجى التحويل للحساب التالي وإرفاق الإيصال:</p>
                            <div className="space-y-1">
                              <p className="font-black text-slate-800 dark:text-white">{siteSettings.bankName}</p>
                              <p className="font-bold text-xs text-slate-600 dark:text-slate-400">رقم الحساب: <span className="font-mono">{siteSettings.accountNumber}</span></p>
                              <p className="font-bold text-xs text-slate-600 dark:text-slate-400">IBAN: <span className="font-mono">{siteSettings.iban}</span></p>
                            </div>
                          </div>

                          <div className={`border-2 border-dashed rounded-[2rem] p-6 text-center transition-all ${paymentReceipt ? 'border-emerald-500 bg-emerald-50/20' : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900/10 hover:border-emerald-500'}`}>
                            {paymentReceipt ? (
                              <div className="relative group flex flex-col items-center">
                                <div className="relative mb-3">
                                  {paymentReceipt.type?.includes('pdf') ? (
                                    <div className="w-32 h-32 flex flex-col items-center justify-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-xl">
                                      <FileText size={48} className="text-emerald-500 mb-2" />
                                      <span className="text-[10px] font-black text-slate-500 px-4 truncate w-full">{paymentReceipt.name}</span>
                                    </div>
                                  ) : (
                                    <img src={paymentReceipt.preview} alt="receipt" className="w-32 h-32 object-cover rounded-2xl shadow-xl border-4 border-white dark:border-slate-800" />
                                  )}
                                  {!paymentReceipt.file && (
                                    <span className="absolute -top-2 -right-2 bg-emerald-500 text-white text-[8px] font-black px-3 py-1 rounded-full shadow-lg">إيصال مرفع مسبقاً</span>
                                  )}
                                </div>
                                <div className="text-center space-y-2">
                                  <p className="text-[10px] font-black text-slate-700 dark:text-slate-200 truncate max-w-[200px] mb-2">{paymentReceipt.name}</p>
                                  <div className="flex items-center gap-2 justify-center">
                                    <a 
                                      href={paymentReceipt.preview} 
                                      target="_blank" 
                                      rel="noopener noreferrer"
                                      className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl text-[10px] font-black hover:bg-slate-200 transition flex items-center gap-2"
                                    >
                                      <Eye size={12} />
                                      عرض الإيصال
                                    </a>
                                    <button 
                                      onClick={() => setPaymentReceipt(null)}
                                      className="px-4 py-2 bg-red-50 text-red-600 rounded-xl text-[10px] font-black hover:bg-red-100 transition flex items-center gap-2"
                                    >
                                      <Trash2 size={12} />
                                      حذف واستبدال
                                    </button>
                                  </div>
                                </div>
                              </div>
                            ) : (
                              <label className="cursor-pointer flex flex-col items-center gap-3 text-slate-400 hover:text-emerald-500 transition-colors py-4">
                                <div className="w-16 h-16 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 rounded-[1.5rem] flex items-center justify-center mb-1">
                                  <Upload size={32} />
                                </div>
                                <div className="space-y-1">
                                  <span className="font-black text-sm block text-slate-700 dark:text-slate-300">ارفق صورة الحوالة</span>
                                  <p className="text-[10px] font-bold">يمكنك اختيار صورة أو ملف PDF</p>
                                </div>
                                <input type="file" onChange={handleReceiptChange} className="hidden" accept="image/*,.pdf" />
                              </label>
                            )}
                          </div>
                          {existingRegistration?.paymentStatus === 'rejected' && (
                            <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-100 dark:border-red-800 rounded-2xl flex items-start gap-3">
                              <AlertCircle size={18} className="text-red-500 shrink-0 mt-0.5" />
                              <div className="space-y-1">
                                <p className="text-xs font-black text-red-600 dark:text-red-400">تم رفض الإيصال السابق</p>
                                <p className="text-[10px] font-bold text-red-500 dark:text-red-300">سبب الرفض: {existingRegistration.paymentNote || 'الإيصال غير واضح أو غير مكتمل'}</p>
                              </div>
                            </div>
                          )}
                        </div>
                      )}

                      {paymentMethod === 'online' && (
                        <div className="p-4 bg-emerald-50 dark:bg-emerald-900/20 rounded-2xl border border-emerald-100 dark:border-emerald-800 text-center">
                          <p className="text-xs font-bold text-emerald-700 dark:text-emerald-400 leading-relaxed">
                            سيتم توجيهك لبوابة الدفع الإلكتروني الآمنة بعد الضغط على "إرسال الطلب".
                          </p>
                        </div>
                      )}
                    </section>
                  )}
                </div>
              )}

              {step === 4 && (
                <div className="space-y-8">
                  <div className="text-center mb-8">
                    <h4 className="text-2xl font-black text-slate-900">مراجعة البيانات</h4>
                    <p className="text-slate-400 font-bold">يرجى التأكد من صحة جميع البيانات قبل الإرسال</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <ReviewCard title="بيانات العريس والعروس" data={[
                      { label: 'اسم العريس', value: formData.groomName },
                      { label: 'هوية العريس', value: formData.groomId },
                      { label: 'جوال العريس', value: formData.groomPhone },
                      { label: 'مبلغ المهر', value: formData.mahrAmount },
                      { label: 'اسم العروس', value: formData.brideName },
                      { label: 'هوية العروس', value: formData.brideId },
                    ]} />
                    {siteSettings.showSocialStep !== false && (
                      <ReviewCard title="البيانات الاجتماعية والصحية" data={[
                        { label: 'المؤهل', value: formData.qualification },
                        { label: 'الحالة الوظيفية', value: formData.employmentStatus },
                        { label: 'قطاع التوظيف', value: formData.employmentStatus === 'موظف' ? formData.employmentSector : '---' },
                        { label: 'الراتب', value: formData.employmentStatus === 'موظف' ? formData.salary : '---' },
                        { label: 'نوع السكن', value: formData.housingType },
                        { label: 'التملك', value: formData.ownershipType },
                        { label: 'مبلغ الإيجار', value: formData.ownershipType === 'إيجار' ? formData.rentAmount : '---' },
                        { label: 'الحالة الصحية', value: formData.healthStatus },
                        { label: 'نوع الإعاقة/المرض', value: formData.healthStatus !== 'سليم' ? formData.disabilityType : '---' },
                      ]} />
                    )}
                    <ReviewCard title="بيانات ممثل العريس" data={[
                      { label: 'اسم ممثل العريس', value: formData.groomGuardianName },
                      { label: 'صلة القرابة', value: formData.groomGuardianRelation },
                      { label: 'جوال ممثل العريس', value: formData.groomGuardianPhone },
                    ]} />
                    <ReviewCard title="بيانات ممثل العروس" data={[
                      { label: 'اسم ممثل العروس', value: formData.guardianName },
                      { label: 'صلة القرابة', value: formData.guardianRelation },
                      { label: 'جوال ممثل العروس', value: formData.guardianPhone },
                    ]} />
                  </div>

                  <div className="bg-slate-50 dark:bg-slate-800/50 p-6 rounded-3xl border border-slate-100 dark:border-slate-800">
                    <h5 className="font-black text-slate-900 dark:text-white mb-6 flex items-center gap-2">
                      <CreditCard size={18} className="text-emerald-500" />
                      تفاصيل السداد
                    </h5>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div className="space-y-4">
                        <div className="flex justify-between items-center border-b border-slate-100 dark:border-slate-700 pb-2">
                          <span className="text-xs font-bold text-slate-400">طريقة الدفع</span>
                          <span className="text-sm font-black text-slate-700 dark:text-slate-200">
                            {paymentMethod === 'online' ? 'دفع إلكتروني' : 'تحويل بنكي'}
                          </span>
                        </div>
                        <div className="flex justify-between items-center border-b border-slate-100 dark:border-slate-700 pb-2">
                          <span className="text-xs font-bold text-slate-400">حالة السداد</span>
                          <span className={`px-2 py-1 rounded-lg text-[10px] font-black ${
                            existingRegistration?.paymentStatus === 'paid' ? 'bg-emerald-100 text-emerald-600' :
                            existingRegistration?.paymentStatus === 'pending_verification' ? 'bg-amber-100 text-amber-600' :
                            existingRegistration?.paymentStatus === 'rejected' ? 'bg-red-100 text-red-600' :
                            'bg-slate-100 text-slate-600'
                          }`}>
                            {existingRegistration?.paymentStatus === 'paid' ? 'تم السداد' :
                             existingRegistration?.paymentStatus === 'pending_verification' ? 'قيد التحقق' :
                             existingRegistration?.paymentStatus === 'rejected' ? 'مرفوض - يرجى إعادة الإرسال' :
                             'قيد الانتظار'}
                          </span>
                        </div>
                        {paymentMethod === 'online' && (
                          <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-slate-700">
                            <p className="text-[10px] font-bold text-slate-500 leading-relaxed text-center">
                              يتم التعامل مع السداد إلكترونياً وبشكل آلي.
                            </p>
                          </div>
                        )}
                      </div>

                      <div className="flex flex-col gap-4">
                        <div>
                          <h6 className="text-[10px] font-black text-slate-400 uppercase mb-3">المرفقات</h6>
                          <div className="flex flex-wrap gap-3">
                            {[groomIdAttachment, familyCardAttachment, marriageContractAttachment].filter(a => a !== null).map((att, i) => (
                              <div key={`${att!.name}-${i}`} className="w-14 h-14 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 shadow-sm relative group">
                                {(att!.type || att!.file?.type)?.includes('pdf') ? (
                                  <div className="w-full h-full flex items-center justify-center bg-white dark:bg-slate-900 text-slate-400"><FileText size={20} /></div>
                                ) : (
                                  <img src={att!.preview} alt="preview" className="w-full h-full object-cover" />
                                )}
                              </div>
                            ))}
                          </div>
                        </div>

                        {paymentMethod === 'transfer' && paymentReceipt && (
                          <div>
                            <h6 className="text-[10px] font-black text-slate-400 uppercase mb-3">إيصال السداد</h6>
                            <div className="flex items-center gap-3 p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-700">
                              <div className="w-12 h-12 rounded-lg overflow-hidden border border-slate-200 dark:border-slate-700 flex-shrink-0">
                                {(paymentReceipt.type || paymentReceipt.file?.type)?.includes('pdf') ? (
                                  <div className="w-full h-full flex items-center justify-center bg-white text-slate-400"><FileText size={24} /></div>
                                ) : (
                                  <img src={paymentReceipt.preview} alt="receipt" className="w-full h-full object-cover" />
                                )}
                              </div>
                              <div className="min-w-0">
                                <p className="text-[10px] font-black text-slate-700 dark:text-slate-200 truncate">{paymentReceipt.name}</p>
                                <p className="text-[8px] font-bold text-emerald-500">تم الإرفاق بنجاح</p>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>

        <div className="p-4 sm:p-8 border-t border-slate-100 dark:border-slate-800 flex-shrink-0 flex gap-4 bg-white dark:bg-slate-900">
          {step === 0 ? (
            <button 
              onClick={() => {
                if (formData.hasSibling) {
                  const count = parseInt(formData.siblingCount || '1');
                  const names = formData.siblingNames || [];
                  const ids = formData.siblingIds || [];
                  
                  if (names.length < count || names.some(n => !n?.trim()) || 
                      ids.length < count || ids.some(id => !id?.trim() || id.length !== 10)) {
                    setError('يرجى إكمال بيانات الإخوة (الاسم الرباعي ورقم الهوية 10 أرقام) للمتابعة');
                    return;
                  }
                }
                setError('');
                setStep(1);
              }}
              disabled={!acceptedTerms}
              className={`w-full py-4 rounded-2xl font-black text-sm flex items-center justify-center gap-2 transition shadow-xl ${acceptedTerms ? 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-emerald-200 dark:shadow-emerald-900/20' : 'bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed'}`}
            >
              الموافقة والمتابعة: تعبئة البيانات
              <ChevronLeft size={20} />
            </button>
          ) : step < 4 ? (
            <>
              {(step > 1 || (siteSettings.showTermsStep && !existingRegistration)) && (
                <button 
                  onClick={() => {
                    if (step === 3 && siteSettings.showSocialStep === false) {
                      setStep(1);
                    } else {
                      setStep(prev => prev - 1);
                    }
                  }}
                  className="flex-1 py-4 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-2xl font-black flex items-center justify-center gap-2 hover:bg-slate-200 dark:hover:bg-slate-700 transition"
                >
                  <ChevronRight size={20} />
                   السابق
                </button>
              )}
              <button 
                onClick={() => {
                  if (step === 1 && !validateStep1()) return;
                  if (step === 2 && siteSettings.showSocialStep !== false && !validateStep2()) return;
                  if (step === 3) {
                    if (!groomIdAttachment || !familyCardAttachment || !marriageContractAttachment) {
                      setError('يرجى إرفاق المستندات الـ 3 المطلوبة');
                      return;
                    }
                    setError('');
                  }
                  
                  if (step === 1 && siteSettings.showSocialStep === false) {
                    setStep(3);
                  } else {
                    setStep(prev => prev + 1);
                  }
                }}
                className="flex-[2] py-4 bg-emerald-600 text-white rounded-2xl font-black flex items-center justify-center gap-2 hover:bg-emerald-700 transition shadow-xl shadow-emerald-200 dark:shadow-emerald-900/20"
              >
                التالي <ChevronLeft size={20} />
              </button>
            </>
          ) : (
            <>
              <button 
                onClick={() => setStep(3)}
                className="flex-1 py-4 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-2xl font-black flex items-center justify-center gap-2 hover:bg-slate-200 dark:hover:bg-slate-700 transition"
              >
                السابق
              </button>
              <button 
                onClick={() => {
                  handleSubmit();
                }}
                disabled={isSubmitting}
                className="flex-[2] py-4 bg-emerald-600 text-white rounded-2xl font-black flex items-center justify-center gap-2 hover:bg-emerald-700 transition shadow-xl shadow-emerald-100 disabled:opacity-50"
              >
                {isSubmitting ? 'جاري الإرسال...' : 'إرسال الطلب'}
                {!isSubmitting && <Check size={20} />}
              </button>
            </>
          )}
        </div>
      </motion.div>

      {/* Payment Gateway Modal */}
      <AnimatePresence>
        {showPaymentGateway && (
          <PaymentGateway 
            amount={festival.fees} 
            onSuccess={() => {
              setShowPaymentGateway(false);
              handleSubmit();
            }} 
            onCancel={() => setShowPaymentGateway(false)} 
          />
        )}
      </AnimatePresence>
    </div>
  );
};

const ReviewCard = ({ title, data }: { title: string, data: { label: string, value: string }[] }) => (
  <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
    <h5 className="font-black text-emerald-600 text-sm mb-4 border-b border-emerald-50 pb-2">{title}</h5>
    <div className="space-y-3">
      {data.map((item, i) => (
        <div key={`${title}-${item.label}-${i}`} className="flex justify-between items-center gap-4">
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-tighter">{item.label}</span>
          <span className="text-sm font-bold text-slate-700 text-left">{item.value || '---'}</span>
        </div>
      ))}
    </div>
  </div>
);

const Select = ({ label, value, onChange, options, error }: any) => (
  <div className="space-y-2">
    <label className="block text-sm font-black text-slate-700 dark:text-slate-300 px-1">{label}</label>
    <div className="relative">
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className={`w-full bg-white dark:bg-slate-900 border-2 rounded-2xl px-4 py-3.5 text-slate-900 dark:text-white font-bold focus:ring-4 focus:ring-emerald-500/10 outline-none transition-all appearance-none ${
          error ? 'border-red-500 bg-red-50/50' : 'border-slate-100 dark:border-slate-800 hover:border-emerald-500/30'
        }`}
      >
        <option value="">اختر...</option>
        {options.map((opt: any) => (
          <option key={opt.value} value={opt.value}>{opt.label}</option>
        ))}
      </select>
      <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none text-slate-400">
        <ChevronLeft size={18} className="-rotate-90" />
      </div>
    </div>
    {error && <p className="text-[9px] font-bold text-red-500 px-1">{error}</p>}
  </div>
);

const Input = ({ label, value, onChange, type = "text", maxLength, placeholder, error, warning, isValid, isChecking }: any) => (
  <div className="space-y-1.5">
    <div className="flex justify-between items-center px-1">
      <label className="text-xs sm:text-sm font-black text-slate-400 uppercase tracking-tighter">{label}</label>
      {isChecking && <div className="w-3 h-3 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin" />}
      {!isChecking && isValid && !warning && <CheckCircle size={12} className="text-emerald-500" />}
      {!isChecking && warning && <AlertCircle size={12} className="text-amber-500" />}
    </div>
    <div className="relative">
      <input 
        type={type}
        value={value}
        onChange={e => onChange(e.target.value)}
        maxLength={maxLength}
        placeholder={placeholder}
        className={`w-full px-4 py-4 bg-slate-50 border rounded-2xl outline-none focus:ring-2 transition placeholder:text-slate-300 font-bold text-slate-700 ${
          error ? 'border-red-200 focus:ring-red-500' : 
          warning ? 'border-amber-200 focus:ring-amber-500' :
          isValid ? 'border-emerald-200 focus:ring-emerald-500' : 
          'border-slate-200 focus:ring-emerald-500'
        }`}
      />
    </div>
    {error && (
      <motion.p 
        initial={{ opacity: 0, y: -5 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-[9px] font-bold text-red-500 px-1"
      >
        {error}
      </motion.p>
    )}
    {!error && warning && (
      <motion.p 
        initial={{ opacity: 0, y: -5 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-[9px] font-bold text-amber-600 px-1"
      >
        {warning}
      </motion.p>
    )}
  </div>
);

const CountUp = ({ value, duration = 2 }: { value: number, duration?: number }) => {
  const [count, setCount] = useState(0);
  const nodeRef = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    let start = 0;
    const end = value;
    if (start === end) {
      setCount(end);
      return;
    }

    const totalMiliseconds = duration * 1000;
    const incrementTime = Math.max(totalMiliseconds / end, 10); // Minimum 10ms for smooth animation

    const timer = setInterval(() => {
      start += Math.ceil(end / (totalMiliseconds / 10)); // Dynamic increment
      if (start >= end) {
        setCount(end);
        clearInterval(timer);
      } else {
        setCount(start);
      }
    }, 10);

    return () => clearInterval(timer);
  }, [value, duration]);

  return <span ref={nodeRef}>{count}</span>;
};

const AddPublicTestimonialModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const [coupleName, setCoupleName] = useState('');
  const [story, setStory] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!coupleName || !story) return;

    setIsSubmitting(true);
    try {
      await addDoc(collection(db, 'testimonials'), {
        coupleName,
        story,
        isActive: false, // Always false for public submissions
        createdAt: serverTimestamp()
      });
      setIsSuccess(true);
      setTimeout(() => {
        onClose();
      }, 3000);
    } catch (error) {
      console.error("Error adding testimonial: ", error);
      alert("حدث خطأ أثناء إرسال القصة. يرجى المحاولة مرة أخرى.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm"
    >
      <motion.div 
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        className="bg-white dark:bg-slate-900 w-full max-w-lg p-8 rounded-[2.5rem] shadow-2xl relative"
      >
        <button 
          onClick={onClose}
          className="absolute top-6 left-6 p-2 bg-slate-100 dark:bg-slate-800 text-slate-400 rounded-xl hover:bg-slate-200 dark:hover:bg-slate-700 transition"
        >
          <X size={20} />
        </button>

        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <MessageSquareHeart size={32} />
          </div>
          <h2 className="text-2xl font-black text-slate-900 dark:text-white mb-2">شاركنا قصة نجاحك</h2>
          <p className="text-slate-500 dark:text-slate-400 font-bold">نحن سعداء بأن نكون جزءاً من رحلتكم</p>
        </div>

        {isSuccess ? (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center py-8"
          >
            <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle size={40} />
            </div>
            <h3 className="text-xl font-black text-slate-900 dark:text-white mb-2">تم الإرسال بنجاح!</h3>
            <p className="text-slate-500 dark:text-slate-400 font-bold">شكراً لمشاركتكم قصتكم الملهمة. سيتم مراجعتها قريباً.</p>
          </motion.div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-black text-slate-700 dark:text-slate-300 mb-2">اسم الزوجين (أو اسم مستعار)</label>
              <input 
                type="text" 
                value={coupleName}
                onChange={e => setCoupleName(e.target.value)}
                className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 transition font-bold text-slate-700 dark:text-white"
                placeholder="مثال: أحمد وسارة"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-black text-slate-700 dark:text-slate-300 mb-2">قصتكم</label>
              <textarea 
                value={story}
                onChange={e => setStory(e.target.value)}
                className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 transition font-bold text-slate-700 dark:text-white h-32 resize-none"
                placeholder="شاركنا تجربتكم مع الجمعية وكيف ساهمت في نجاح زواجكم..."
                required
              />
            </div>

            <div className="flex gap-4 pt-4">
              <button type="button" onClick={onClose} className="flex-1 py-3 font-bold text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-xl transition">إلغاء</button>
              <button 
                type="submit" 
                disabled={isSubmitting}
                className="flex-1 py-3 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-700 transition shadow-lg shadow-emerald-100 dark:shadow-none disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  'إرسال القصة'
                )}
              </button>
            </div>
          </form>
        )}
      </motion.div>
    </motion.div>
  );
};

// --- Main App ---

export default function App() {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [festivals, setFestivals] = useState<Festival[]>([]);
  const [allRegistrations, setAllRegistrations] = useState<Registration[]>([]);
  const [isRegistrationsLoaded, setIsRegistrationsLoaded] = useState(false);
  const [quotaExceeded, setQuotaExceeded] = useState(false);
  const [publicStats, setPublicStats] = useState({ total: 0, approved: 0, pending: 0, rejected: 0, topFestivalName: '' });
  const [galleryImages, setGalleryImages] = useState<any[]>([]);
  const [testimonials, setTestimonials] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [isPrinting, setIsPrinting] = useState(false);
  const [editingRegistration, setEditingRegistration] = useState<Registration | null>(null);
  const [selectedFestival, setSelectedFestival] = useState<Festival | null>(null);
  const [view, setView] = useState<'home' | 'dashboard' | 'groom-portal'>('home');
  const [siteSettings, setSiteSettings] = useState({ 
    siteOpen: true,
    bankName: '',
    accountNumber: '',
    iban: '',
    enableOnlinePayment: true,
    enableTransferPayment: true,
    siteName: 'الجمعية الخيرية',
    secondaryTitle: '',
    contactNumber: '',
    whatsappNumber: '',
    xLink: '',
    showGallery: true,
    showTestimonials: true,
    showStatistics: true,
    showRegistrationCount: true
  });
  const [selectedFestivalForGrooms, setSelectedFestivalForGrooms] = useState<Festival | null>(null);
  const [loading, setLoading] = useState(true);
  const [authError, setAuthError] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  const ApprovedGroomsModal: React.FC<{ festival: Festival, registrations: Registration[], onClose: () => void }> = ({ festival, registrations, onClose }) => {
    const approvedGrooms = registrations.filter(r => r.festivalId === festival.id && r.status === 'approved');
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 w-full max-w-md shadow-2xl">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-black text-slate-900 dark:text-white">فرسان {festival.name}</h2>
            <button onClick={onClose} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors">
              <X size={20} className="text-slate-500" />
            </button>
          </div>
          <div className="max-h-96 overflow-y-auto space-y-2">
            {approvedGrooms.length > 0 ? (
              approvedGrooms.map((reg, index) => (
                <div key={reg.id} className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl flex items-center gap-3">
                  <span className="text-brand-500 font-bold text-sm w-8">{index + 1}</span>
                  <span className="text-slate-700 dark:text-slate-200 font-bold">{reg.groomName}</span>
                </div>
              ))
            ) : (
              <p className="text-center text-slate-500 py-4">لا يوجد فرسان مقبولين حالياً</p>
            )}
          </div>
        </div>
      </div>
    );
  };

  const notifiedIdsRef = useRef<Set<string>>(new Set());
  const notifiedPaymentsRef = useRef<Set<string>>(new Set());

  const sendBrowserNotification = (title: string, body: string) => {
    if (!("Notification" in window)) return;
    
    if (Notification.permission === "granted") {
      new Notification(title, {
        body,
        icon: '/favicon.ico',
        dir: 'rtl'
      });
    }
  };

  const requestNotificationPermission = () => {
    if ("Notification" in window && Notification.permission === "default") {
      Notification.requestPermission();
    }
  };

  const isAdminOrSupervisor = userProfile?.role === 'admin' || userProfile?.role === 'supervisor';

  useEffect(() => {
    if (isAdminOrSupervisor) {
      requestNotificationPermission();
    }
  }, [isAdminOrSupervisor]);

  useEffect(() => {
    const handleQuotaExceeded = () => {
      setQuotaExceeded(true);
    };
    window.addEventListener('firestore-quota-exceeded', handleQuotaExceeded);
    return () => window.removeEventListener('firestore-quota-exceeded', handleQuotaExceeded);
  }, []);

  useEffect(() => {
    if (isAdminOrSupervisor && allRegistrations.length > 0) {
      // First run: populate notifiedIds to avoid notification for already existing items
      if (notifiedIdsRef.current.size === 0) {
        allRegistrations.forEach(r => {
          notifiedIdsRef.current.add(r.id);
          if (r.paymentReceipt) notifiedPaymentsRef.current.add(r.id);
        });
        return;
      }

      allRegistrations.forEach(reg => {
        // New registration check
        if (!notifiedIdsRef.current.has(reg.id)) {
          notifiedIdsRef.current.add(reg.id);
          // Only notify if status is pending and it's a "new" request (not an old one just loaded)
          if (reg.status === 'pending') {
            sendBrowserNotification('طلب عريس جديد ◌', `طلب جديد من ${reg.groomName} في مهرجان ${reg.festivalName}`);
          }
        }

        // New payment receipt check
        if (reg.paymentReceipt && !notifiedPaymentsRef.current.has(reg.id)) {
          notifiedPaymentsRef.current.add(reg.id);
          sendBrowserNotification('إيصال سداد جديد 💳', `تم استلام إيصال سداد جديد من العريس ${reg.groomName}`);
        }
      });
    }
  }, [allRegistrations, isAdminOrSupervisor]);

  useEffect(() => {
    document.title = siteSettings.siteName || 'الجمعية الخيرية';
  }, [siteSettings.siteName]);

  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showLoginForm, setShowLoginForm] = useState(false);
  const [showPublicTestimonialModal, setShowPublicTestimonialModal] = useState(false);
  const [isResettingPassword, setIsResettingPassword] = useState(false);

  const [showPassword, setShowPassword] = useState(false);
  const [showMenu, setShowMenu] = useState(false);

  useEffect(() => {
    if (authError) {
      const timer = setTimeout(() => setAuthError(null), 5000);
      return () => clearTimeout(timer);
    }
  }, [authError]);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [selectedFestival]);

  useEffect(() => {
    // Auth Listener
    const unsubAuth = onAuthStateChanged(auth, async (u) => {
      try {
        if (u) {
          setUser(u);
          
          // Fallback profile if fetch fails
          let fallbackProfile: UserProfile = {
            uid: u.uid,
            email: u.email!,
            role: u.email === "butaqi2012@gmail.com" ? "admin" : "user",
            displayName: u.displayName || '',
            photoURL: u.photoURL || '',
            assignedFestivalId: ''
          };

          try {
            const userDocRef = doc(db, 'users', u.uid);
            const userDoc = await getDoc(userDocRef);
            
            if (userDoc.exists()) {
              const data = userDoc.data();
              // Force admin for owner email
              if (u.email === "butaqi2012@gmail.com" && data.role !== 'admin') {
                const updatedProfile = { ...data, role: 'admin' as const };
                await setDoc(userDocRef, updatedProfile, { merge: true }).catch(() => {});
                setUserProfile({ uid: u.uid, ...updatedProfile } as UserProfile);
              } else {
                setUserProfile({ uid: u.uid, ...data } as UserProfile);
              }
            } else {
              // Check if email was pre-registered as supervisor
              const normalizedEmail = u.email!.toLowerCase().trim();
              
              // Try both email doc ID and email field query
              const emailDoc = await getDoc(doc(db, 'users', normalizedEmail));
              let existingData: any = null;
              let placeholderId = '';

              if (emailDoc.exists()) {
                existingData = emailDoc.data();
                placeholderId = emailDoc.id;
              } else {
                const q = query(collection(db, 'users'), where('email', '==', normalizedEmail), limit(1));
                const snap = await getDocs(q);
                if (!snap.empty) {
                  existingData = snap.docs[0].data();
                  placeholderId = snap.docs[0].id;
                }
              }
              
              let role: 'admin' | 'supervisor' | 'user' = 'user';
              let assignedFestivalId = '';

              // Hardcoded Admin for the owner
              if (u.email === "butaqi2012@gmail.com") {
                role = 'admin';
              } else if (existingData) {
                role = existingData.role || 'user';
                assignedFestivalId = existingData.assignedFestivalId || '';
              }

              const newProfile: UserProfile = {
                uid: u.uid,
                email: u.email!,
                role: role,
                displayName: u.displayName || existingData?.displayName || '',
                photoURL: u.photoURL || '',
                assignedFestivalId
              };
              
              await setDoc(doc(db, 'users', u.uid), newProfile).catch(() => {});
              
              // Delete the placeholder doc if it was different
              if (placeholderId && placeholderId !== u.uid) {
                try {
                  await deleteDoc(doc(db, 'users', placeholderId));
                } catch (delErr) {
                  console.error('Error deleting placeholder:', delErr);
                }
              }
              
              // Update festival supervisorId if assigned - non-blocking
              if (assignedFestivalId) {
                updateDoc(doc(db, 'festivals', assignedFestivalId), { supervisorId: u.uid })
                  .catch(e => console.warn('Non-critical: supervisor update failed:', e));
              }
              
              setUserProfile(newProfile);
            }
          } catch (fetchErr: any) {
            if (fetchErr.message?.includes('quota')) {
              setQuotaExceeded(true);
            }
            console.error('Error fetching user profile, using fallback:', fetchErr);
            setUserProfile(fallbackProfile);
          }
        } else {
          setUser(null);
          setUserProfile(null);
        }
      } catch (err) {
        console.error('Auth processing failure:', err);
      } finally {
        setLoading(false);
      }
    });

    // Festivals
    const fetchFestivals = async () => {
      const cached = cache.get<Festival[]>('festivals');
      if (cached) setFestivals(cached);
      
      try {
        const snapshot = await getDocs(collection(db, 'festivals'));
        const fetchedFestivals = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Festival));
        fetchedFestivals.sort((a, b) => (a.order || 0) - (b.order || 0));
        setFestivals(fetchedFestivals);
        cache.set('festivals', fetchedFestivals, 3600000); // 1 hour
      } catch (err: any) {
        if (err.message?.includes('quota')) {
          setQuotaExceeded(true);
          console.warn('Festivals: Quota exceeded, using cache');
        } else {
          console.error('Error fetching festivals:', err);
        }
      }
    };
    fetchFestivals();

    // Settings
    const fetchSettings = async () => {
      const cached = cache.get<any>('global_settings');
      if (cached) setSiteSettings(cached);

      try {
        const docSnap = await getDoc(doc(db, 'settings', 'global'));
        if (docSnap.exists()) {
          const data = docSnap.data();
          const updatedSettings = {
            siteOpen: true,
            bankName: '',
            accountNumber: '',
            iban: '',
            enableOnlinePayment: true,
            enableTransferPayment: true,
            siteName: 'الجمعية الخيرية',
            secondaryTitle: '',
            contactNumber: '',
            contactNumber2: '',
            whatsappNumber: '',
            whatsappNumber2: '',
            xLink: '',
            showGallery: true,
            showTestimonials: true,
            showStatistics: true,
            maxFileSizeMB: 5,
            allowedFileTypes: ['image/jpeg', 'image/png', 'application/pdf'],
            showTermsStep: false,
            terms: [],
            ...data
          } as any;
          setSiteSettings(updatedSettings);
          cache.set('global_settings', updatedSettings, 3600000); // 1 hour
        }
      } catch (err: any) {
        if (!err.message?.includes('quota')) {
          console.error('Error fetching settings:', err);
        }
      }
    };
    fetchSettings();

    // Gallery
    const fetchGallery = async () => {
      const cached = cache.get<any[]>('gallery');
      if (cached) setGalleryImages(cached);

      try {
        const snapshot = await getDocs(query(collection(db, 'gallery'), orderBy('createdAt', 'desc'), limit(20)));
        const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setGalleryImages(data);
        cache.set('gallery', data, 3600000); // 1 hour
      } catch (err: any) {
        if (!err.message?.includes('quota')) {
          console.error('Error fetching gallery:', err);
        }
      }
    };
    fetchGallery();

    // Testimonials
    const fetchTestimonials = async () => {
      const cached = cache.get<any[]>('testimonials');
      if (cached) setTestimonials(cached);

      try {
        const snapshot = await getDocs(query(collection(db, 'testimonials'), orderBy('createdAt', 'desc'), limit(10)));
        const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
        setTestimonials(data);
        cache.set('testimonials', data, 3600000); // 1 hour
      } catch (err: any) {
        if (!err.message?.includes('quota')) {
          console.error('Error fetching testimonials:', err);
        }
      }
    };
    fetchTestimonials();

    // Public Stats
    const fetchPublicStats = async () => {
      try {
        const docSnap = await getDoc(doc(db, 'public_stats', 'global'));
        if (docSnap.exists()) {
          setPublicStats(docSnap.data() as any);
        }
      } catch (err: any) {
        if (!err.message?.includes('quota')) {
          console.error('Error in public stats fetch:', err);
        }
      }
    };
    fetchPublicStats();

    return () => { unsubAuth(); };
  }, []);

  useEffect(() => {
    if (!user || !userProfile || (userProfile.role !== 'admin' && userProfile.role !== 'supervisor')) {
      setAllRegistrations([]); // Clear stats if logged out or not authorized
      setIsRegistrationsLoaded(false);
      return;
    }
    
    // All Registrations Fetch for Stats - Only for Admins and Supervisors
    const fetchAllRegs = async () => {
      if (!isAdminOrSupervisor) return;

      const cacheKey = `all_registrations_admin_${userProfile?.uid}`;
      const cached = cache.get<Registration[]>(cacheKey, 300000); // 5 minutes freshness
      if (cached) {
        setAllRegistrations(cached);
        setIsRegistrationsLoaded(true);
        return; // Skip fetch if cache is fresh
      }

      try {
        const snapshot = await getDocs(collection(db, 'registrations'));
        const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Registration));
        setAllRegistrations(data);
        setIsRegistrationsLoaded(true);
        cache.set(cacheKey, data, 1800000); // Cache for 30 mins (TTL)
      } catch (err: any) {
        console.error('Error fetching all registrations:', err);
        if (err.message?.includes('quota')) {
          setQuotaExceeded(true);
        }
        if (err.message.includes('permission') || err.message.includes('quota')) {
          if (!allRegistrations.length) {
            setAllRegistrations([]);
            setIsRegistrationsLoaded(false);
          }
        }
      }
    };
    fetchAllRegs();
  }, [user, userProfile, isAdminOrSupervisor]);

  // Update public stats when admin is logged in
  useEffect(() => {
    if (!userProfile || userProfile.role !== 'admin' || festivals.length === 0 || !isRegistrationsLoaded) return;

    const registrationsCountByFestival = allRegistrations.reduce((acc, reg) => {
      acc[reg.festivalId] = (acc[reg.festivalId] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const topFestivalId = Object.entries(registrationsCountByFestival).sort((a, b) => (b[1] as number) - (a[1] as number))[0]?.[0];
    const topFestival = festivals.find(f => f.id === topFestivalId);
    const topFestivalName = topFestival ? topFestival.name : 'لا يوجد';

    const stats = {
      total: allRegistrations.length,
      approved: allRegistrations.filter(r => r.status === 'approved').length,
      pending: allRegistrations.filter(r => r.status === 'pending').length,
      rejected: allRegistrations.filter(r => r.status === 'rejected').length,
      topFestivalName: topFestivalName,
    };

    const batch = writeBatch(db);
    batch.set(doc(db, 'public_stats', 'global'), stats, { merge: true });

    festivals.forEach(f => {
      const count = registrationsCountByFestival[f.id] || 0;
      if (f.registrationCount !== count) {
        batch.update(doc(db, 'festivals', f.id), { registrationCount: count });
      }
    });

    batch.commit().catch(err => console.error('Error updating public stats:', err));
  }, [allRegistrations, userProfile, festivals, isRegistrationsLoaded]);

  // login function removed

  const loginWithEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLoggingIn) return;
    setIsLoggingIn(true);
    setAuthError(null);
    try {
      const normalizedEmail = loginEmail.toLowerCase().trim();
      const normalizedPassword = loginPassword.trim();
      
      if (isResettingPassword) {
        await sendPasswordResetEmail(auth, normalizedEmail);
        setAuthError('تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك الإلكتروني.');
        setIsResettingPassword(false);
      } else {
        // 1. Admin/Supervisor existence check
        let userData: any = null;
        
        // Try direct fetch by ID (email) first
        const docRef = doc(db, 'users', normalizedEmail);
        const docSnap = await getDoc(docRef);
        
        if (docSnap.exists()) {
          userData = docSnap.data();
        } else {
          // Fallback to query
          const q = query(collection(db, 'users'), where('email', '==', normalizedEmail), limit(1));
          const snap = await getDocs(q);
          if (!snap.empty) {
            userData = snap.docs[0].data();
          }
        }
        
        if (!userData && normalizedEmail !== "butaqi2012@gmail.com") {
          setAuthError('عذراً، هذا البريد غير مسجل كمشرف في النظام.');
          setIsLoggingIn(false);
          return;
        }

        try {
          // 2. Try standard sign in
          await signInWithEmailAndPassword(auth, normalizedEmail, normalizedPassword);
        } catch (signInError: any) {
          console.log("Sign-in attempt failure details:", signInError.code);
          
          // 3. Handle activation or sync issue
          const isProbablyAuthMismatch = signInError.code === 'auth/user-not-found' || 
                                        signInError.code === 'auth/wrong-password' || 
                                        signInError.code === 'auth/invalid-credential';

          if (isProbablyAuthMismatch && userData?.password && userData.password.trim() === normalizedPassword) {
            // Firestore password matches, but Auth sign-in failed. 
            // Attempt auto-sync with Auth server.
            try {
              const syncRes = await fetch('/api/sync-user', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                  email: normalizedEmail, 
                  password: normalizedPassword,
                  displayName: userData.displayName || ''
                })
              });
              
              if (syncRes.ok) {
                const syncData = await syncRes.json();
                if (syncData.success) {
                  // Retry sign-in after successful sync
                  await signInWithEmailAndPassword(auth, normalizedEmail, normalizedPassword);
                } else {
                  console.warn("Auto-sync reported failure:", syncData);
                  setAuthError(syncData.message || 'فشل المزامنة التلقائية. يرجى استخدام "نسيت كلمة المرور".');
                  setIsLoggingIn(false);
                  return;
                }
              } else {
                const syncErr = await syncRes.json();
                console.error("Auto-sync failed:", syncErr);
                setAuthError('فشل الدخول: بياناتك غير متطابقة مع خادم المصادقة. يرجى التواصل مع الإدارة.');
                setIsLoggingIn(false);
                return;
              }
            } catch (autoSyncErr: any) {
              console.error("Auto-sync error:", autoSyncErr);
              setAuthError('حدث خطأ أثناء محاولة مزامنة بيانات الدخول. يرجى المحاولة لاحقاً.');
              setIsLoggingIn(false);
              return;
            }
          } else {
            // Truly wrong credentials or other error
            setAuthError('البريد الإلكتروني أو كلمة المرور غير صحيحة.');
            setIsLoggingIn(false);
            return;
          }
        }
      }
      
      if (!isResettingPassword) {
        setShowLoginForm(false);
        setLoginEmail('');
        setLoginPassword('');
        setView('dashboard');
      }
    } catch (error: any) {
      console.error("Login attempt failed:", error.code || 'error', error.message);
      if (error.code === 'auth/user-not-found' || error.code === 'auth/wrong-password' || error.code === 'auth/invalid-credential') {
        setAuthError('البريد الإلكتروني أو كلمة المرور غير صحيحة.');
      } else if (error.code === 'auth/email-already-in-use') {
        setAuthError('هذا البريد الإلكتروني مسجل مسبقاً بطريقة أخرى.');
      } else if (error.code === 'auth/weak-password') {
        setAuthError('كلمة المرور يجب أن تكون 6 أحرف على الأقل.');
      } else if (error.code === 'auth/too-many-requests') {
        setAuthError('تم حظر المحاولات مؤقتاً بسبب كثرة الطلبات. حاول لاحقاً.');
      } else {
        setAuthError(`خطأ في الدخول: ${error.message || error.code}`);
      }
    } finally {
      setIsLoggingIn(false);
    }
  };

  const logout = () => {
    signOut(auth);
    setView('home');
  };

  const filteredFestivals = festivals
    .filter(f => !f.isArchived)
    .filter(f => f.name.toLowerCase().includes(searchQuery.toLowerCase()))
    .sort((a, b) => {
      if (a.isOpen && !b.isOpen) return -1;
      if (!a.isOpen && b.isOpen) return 1;
      return (a.order || 0) - (b.order || 0);
    });


  const unreviewedCount = allRegistrations.filter(r => {
    if (userProfile?.role === 'admin') return r.status === 'pending';
    if (userProfile?.role === 'supervisor') return r.status === 'pending' && r.festivalId === userProfile.assignedFestivalId;
    return false;
  }).length;

  if (loading) return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center">
      <div className="w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
    </div>
  );


  // Statistics Calculations
  const totalFestivals = festivals.length;
  const totalMarried = allRegistrations.filter(r => r.status === 'approved').length;
  const totalRegistrations = allRegistrations.length;

  const registrationsCountByFestival = allRegistrations.reduce((acc, reg) => {
    acc[reg.festivalId] = (acc[reg.festivalId] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const successRate = totalRegistrations > 0 ? Math.round((totalMarried / totalRegistrations) * 100) : 0;
  
  return (
    <div className="min-h-screen bg-slate-50 font-sans selection:bg-emerald-100 selection:text-emerald-900" dir="rtl">
      <AnimatePresence>
        {authError && (
          <motion.div 
            initial={{ opacity: 0, y: -20, x: '-50%' }}
            animate={{ opacity: 1, y: 0, x: '-50%' }}
            exit={{ opacity: 0, y: -20, x: '-50%' }}
            className="fixed top-24 left-1/2 z-[200] bg-red-50 border border-red-100 text-red-600 px-6 py-3 rounded-2xl shadow-xl font-bold flex items-center gap-3 whitespace-nowrap"
          >
            <AlertCircle size={20} />
            {authError}
          </motion.div>
        )}
        {quotaExceeded && (
          <motion.div 
            initial={{ opacity: 0, y: -20, x: '-50%' }}
            animate={{ opacity: 1, y: 0, x: '-50%' }}
            exit={{ opacity: 0, y: -20, x: '-50%' }}
            className="fixed top-4 left-1/2 z-[200] bg-amber-50 border border-amber-100 text-amber-700 px-6 py-3 rounded-2xl shadow-xl font-bold flex flex-col items-center gap-1 min-w-[300px]"
          >
            <div className="flex items-center gap-3">
              <AlertTriangle size={20} className="text-amber-500" />
              <span>تنبيه: تم تجاوز حصة البيانات المجانية</span>
            </div>
            <p className="text-[10px] opacity-80 font-bold">قد تواجه بطء في تحميل البيانات، يرجى المحاولة لاحقاً</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header */}

      {/* Header */}
      <header className="sticky top-0 z-40 bg-brand-50/90 dark:bg-slate-950/90 backdrop-blur-xl border-b border-brand-200 dark:border-slate-800 shadow-sm transition-all duration-500">
        <div className="max-w-screen-2xl mx-auto px-4 sm:px-6 py-8 sm:py-6 flex flex-col gap-4 sm:gap-4">
          {/* Row 1: Logo and Title */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-8">
            <motion.div 
              initial={{ scale: 0.8, opacity: 0, y: -10 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              whileHover={{ scale: 1.05, rotate: 5 }}
              transition={{ type: "spring", stiffness: 200, damping: 15 }}
              className="relative group cursor-pointer"
            >
              <div className="absolute -inset-8 bg-brand-500/20 rounded-full blur-3xl group-hover:bg-brand-500/40 transition duration-500 animate-pulse" />
              <img 
                src="https://www.reaayah.sa/rafed/uploads/system/cover_66ccddc5caa47.jpeg" 
                alt="Logo" 
                className="h-32 w-32 sm:h-48 sm:w-48 rounded-full object-cover border-4 border-white dark:border-slate-800 shadow-2xl relative z-10 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
            </motion.div>
            <div className="block">
              <h1 className="text-lg sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight leading-tight text-center">{siteSettings.siteName || 'الجمعية الخيرية'}</h1>
              {siteSettings.secondaryTitle && (
                <p className="text-slate-500 dark:text-slate-400 font-bold text-xs sm:text-sm text-center mt-1">
                  {siteSettings.secondaryTitle}
                </p>
              )}
            </div>
          </div>

          {/* Row 2: Actions */}
          <div className="flex items-center justify-center flex-wrap gap-2 sm:gap-4 mt-2 sm:mt-0 relative z-50">

            {user ? (
              <div className="flex items-center gap-3 shrink-0">
                <div className="text-left hidden sm:block">
                  <p className="text-xs font-black text-slate-900 dark:text-white leading-none">{userProfile?.displayName || user.email}</p>
                  <p className="text-[10px] font-bold text-brand-500">{userProfile?.role === 'admin' ? 'مدير النظام' : userProfile?.role === 'supervisor' ? 'مشرف' : 'مستخدم'}</p>
                </div>
                <div className="relative flex items-center gap-2">
                  {isAdminOrSupervisor && (
                    <button 
                      onClick={() => { setShowMenu(false); setView('dashboard'); }}
                      className="hidden md:flex items-center gap-2 px-4 py-2.5 bg-brand-50 dark:bg-brand-900/20 text-brand-600 dark:text-brand-400 rounded-xl font-black text-sm hover:bg-brand-100 dark:hover:bg-brand-900/40 transition-all shadow-sm border border-brand-100/50 dark:border-brand-800/50"
                    >
                      <LayoutDashboard size={18} />
                      <span>لوحة التحكم</span>
                    </button>
                  )}
                  <div className="relative">
                    <div 
                      className="w-8 h-8 sm:w-12 sm:h-12 rounded-xl sm:rounded-2xl border-2 border-white dark:border-slate-800 shadow-lg cursor-pointer bg-brand-100 dark:bg-brand-900/30 flex items-center justify-center text-brand-600 dark:text-brand-400 transition-all hover:scale-105 active:scale-95 overflow-hidden"
                      onClick={() => setShowMenu(!showMenu)}
                    >
                    {user.photoURL ? (
                      <img 
                        src={user.photoURL} 
                        alt="User" 
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <User size={16} className="sm:w-5 sm:h-5" />
                    )}
                  </div>
                  <div className={`absolute top-full left-0 sm:left-1/2 sm:-translate-x-1/2 mt-3 w-56 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-brand-100 dark:border-slate-800 transition-all p-2 z-50 ${showMenu ? 'opacity-100 visible' : 'opacity-0 invisible'}`}>
                    <div className="px-4 py-3 border-b border-brand-50 dark:border-slate-800 bg-brand-50/30 dark:bg-slate-800/30 rounded-t-xl mb-1">
                      <p className="text-[10px] font-bold text-brand-500 uppercase tracking-wider">حسابي</p>
                      <p className="text-xs font-black text-slate-900 dark:text-white truncate">{user.email}</p>
                    </div>
                    {isAdminOrSupervisor && (
                      <button 
                        onClick={() => { setShowMenu(false); setView(view === 'home' ? 'dashboard' : 'home'); }}
                        className="w-full flex items-center gap-3 px-4 py-3 text-sm font-bold text-slate-700 dark:text-slate-300 hover:bg-brand-50 dark:hover:bg-slate-800 rounded-xl transition-colors"
                      >
                        {view === 'home' ? <LayoutDashboard size={16} className="text-brand-500" /> : <Home size={16} className="text-brand-500" />}
                        {view === 'home' ? 'لوحة التحكم' : 'الرئيسية'}
                        {view === 'home' && unreviewedCount > 0 && (
                          <span className="mr-auto bg-red-500 text-white text-[10px] font-black px-1.5 py-0.5 rounded-full min-w-[1.25rem] text-center">
                            {unreviewedCount}
                          </span>
                        )}
                      </button>
                    )}
                    <div className="h-px bg-brand-50 dark:bg-slate-800 my-1 mx-2" />
                    <button 
                      onClick={() => { setShowMenu(false); logout(); }}
                      className="w-full flex items-center gap-3 px-4 py-3 text-sm font-bold text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-xl transition-colors"
                    >
                      <LogOut size={16} /> تسجيل الخروج
                    </button>
                  </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-2 shrink-0">
                <button 
                  onClick={() => setView('groom-portal')}
                  className="flex items-center gap-1.5 px-2.5 sm:px-4 py-1.5 sm:py-2.5 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-100 dark:hover:bg-emerald-900/40 rounded-xl font-bold text-[10px] sm:text-sm transition-all shadow-sm shrink-0 whitespace-nowrap"
                >
                  <User size={14} className="sm:w-5 sm:h-5" />
                  <span>بوابة العرسان</span>
                </button>
                {isAdminOrSupervisor ? (
                  <button 
                    onClick={() => setView('dashboard')}
                    className="flex items-center gap-1.5 px-2.5 sm:px-4 py-1.5 sm:py-2.5 bg-brand-600 hover:bg-brand-700 text-white rounded-xl font-bold text-[10px] sm:text-sm transition-all shadow-lg shadow-brand-600/20 hover:shadow-brand-600/40 active:scale-95 shrink-0 whitespace-nowrap"
                  >
                    <LayoutDashboard size={14} className="sm:w-5 sm:h-5" />
                    <span>لوحة التحكم</span>
                  </button>
                ) : (
                  <button 
                    onClick={() => setShowLoginForm(true)}
                    disabled={isLoggingIn}
                    className="flex items-center gap-1.5 px-2.5 sm:px-4 py-1.5 sm:py-2.5 bg-brand-600 hover:bg-brand-700 text-white rounded-xl font-bold text-[10px] sm:text-sm transition-all shadow-lg shadow-brand-600/20 hover:shadow-brand-600/40 active:scale-95 disabled:opacity-50 shrink-0 whitespace-nowrap"
                  >
                    <Lock size={14} className="sm:w-5 sm:h-5" />
                    <span>دخول الإدارة</span>
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-screen-2xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
        {quotaExceeded && (
        <div className="bg-amber-50 border-b border-amber-200 p-2 text-center text-amber-800 text-sm font-medium sticky top-0 z-[100] flex items-center justify-center gap-2">
          <span className="flex h-2 w-2 rounded-full bg-amber-500 animate-pulse"></span>
          تم استهلاك حصة البيانات المجانية لهذا اليوم. التطبيق يعمل حالياً في وضع "العرض فقط" باستخدام البيانات المخزنة مؤقتاً.
        </div>
      )}
      
      {view === 'home' ? (
          <>
            {selectedFestival ? (
              <RegistrationWizard 
                festival={selectedFestival} 
                onClose={() => setSelectedFestival(null)} 
                user={user} 
                userProfile={userProfile}
                siteSettings={siteSettings}
              />
            ) : editingRegistration ? (
              <RegistrationWizard 
                festival={festivals.find(f => f.id === editingRegistration.festivalId)!}
                existingRegistration={editingRegistration}
                onClose={() => setEditingRegistration(null)}
                user={user}
                userProfile={userProfile}
                siteSettings={siteSettings}
              />
            ) : (
              <>
                {!siteSettings.siteOpen && userProfile?.role !== 'admin' ? (
                  <div className="text-center py-24">
                    <div className="w-24 h-24 bg-amber-100 text-amber-600 rounded-[2.5rem] flex items-center justify-center mx-auto mb-8">
                      <Clock size={48} />
                    </div>
                    <h2 className="text-4xl font-black text-slate-900 mb-4">الموقع مغلق حالياً</h2>
                    <p className="text-slate-400 font-bold max-w-md mx-auto">نعتذر، التسجيل مغلق حالياً للصيانة أو لانتهاء فترة المهرجانات. يرجى العودة لاحقاً.</p>
                  </div>
                ) : (
                  <>


                    {/* Statistics Section */}
                    {siteSettings.showStatistics && (
                      <div className="mb-20 sm:mb-32 relative">
                        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-full bg-brand-500/5 blur-[120px] rounded-full -z-10" />
                        
                        <div className="mb-12 sm:mb-20 text-center">
                          <motion.div
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                          >
                            <span className="inline-block px-4 py-1.5 bg-brand-100 dark:bg-brand-900/30 text-brand-600 dark:text-brand-400 rounded-full text-[10px] font-black uppercase tracking-widest mb-4">إنجازاتنا</span>
                            <h2 className="text-4xl sm:text-6xl font-black text-slate-900 dark:text-white mb-6 tracking-tight">إحصائيات المهرجانات</h2>
                            <p className="text-slate-500 dark:text-slate-400 font-bold text-sm sm:text-lg max-w-4xl mx-auto leading-relaxed lg:whitespace-nowrap">نفتخر بتقديم خدماتنا لتيسير الزواج ورعاية الأسرة في الأحساء، وهذه ثمار جهودنا المشتركة</p>
                          </motion.div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 sm:gap-6 auto-rows-[130px] sm:auto-rows-[150px]">
                          {/* Total Requests - Big Card */}
                          <motion.div 
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ delay: 0.1 }}
                            className="md:col-span-2 md:row-span-2 rounded-[2rem] p-5 sm:p-8 relative overflow-hidden group bg-gradient-to-br from-blue-600 to-blue-800 text-white shadow-2xl shadow-blue-900/20 hover:-translate-y-1 transition-all duration-500 flex flex-col justify-between"
                          >
                            <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -mr-20 -mt-20 group-hover:bg-white/20 transition-all duration-500" />
                            <div className="relative z-10">
                              <div className="w-12 h-12 sm:w-14 sm:h-14 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center mb-4 sm:mb-6 shadow-inner group-hover:scale-110 group-hover:rotate-6 transition-all duration-500">
                                <Users size={28} className="text-white" />
                              </div>
                              <div className="flex items-center gap-3 sm:gap-4">
                                <h3 className="text-5xl sm:text-7xl font-black tracking-tight">{publicStats.total}</h3>
                                <p className="text-blue-100 font-bold text-xs sm:text-base uppercase tracking-wider leading-tight">إجمالي<br/>الطلبات</p>
                              </div>
                            </div>
                            <div className="relative z-10 mt-3 sm:mt-4 flex items-center gap-2 text-blue-200 text-[10px] sm:text-xs font-bold">
                              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                              يتم تحديث الأرقام لحظياً
                            </div>
                          </motion.div>

                          {/* Top Festival - Wide Card */}
                          <motion.div 
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ delay: 0.2 }}
                            className="md:col-span-2 md:row-span-1 glass-card rounded-[2rem] p-5 sm:p-6 flex flex-col justify-center relative overflow-hidden group hover:-translate-y-1 transition-all duration-500"
                          >
                            <div className="flex items-center gap-3 sm:gap-5 relative z-10">
                              <div className="w-12 h-12 sm:w-14 sm:h-14 bg-gradient-to-br from-amber-100 to-orange-100 dark:from-amber-900/40 dark:to-orange-900/40 text-amber-600 dark:text-amber-400 border border-amber-200/50 dark:border-amber-700/50 rounded-2xl flex items-center justify-center shrink-0 group-hover:scale-110 group-hover:-rotate-6 transition-all duration-500 shadow-inner">
                                <Award size={28} />
                              </div>
                              <div>
                                <p className="text-slate-400 dark:text-slate-500 font-bold text-[10px] sm:text-xs mb-1 uppercase tracking-wider">المهرجان الأعلى عدداً</p>
                                <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight line-clamp-1">
                                  {festivals.length > 0 && festivals.some(f => (f.registrationCount || 0) > 0) ? [...festivals].sort((a, b) => (b.registrationCount || 0) - (a.registrationCount || 0))[0].name : 'لا يوجد'}
                                </h3>
                              </div>
                            </div>
                            <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-violet-500/5 rounded-full blur-2xl group-hover:bg-violet-500/10 transition-all duration-500" />
                          </motion.div>

                          {/* Total Festivals - Small Card */}
                          <motion.div 
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ delay: 0.3 }}
                            className="md:col-span-1 md:row-span-1 glass-card rounded-[2rem] p-4 sm:p-5 flex flex-col justify-center items-center text-center relative overflow-hidden group hover:-translate-y-1 transition-all duration-500"
                          >
                            <div className="w-10 h-10 bg-gradient-to-br from-yellow-100 to-amber-100 dark:from-yellow-900/40 dark:to-amber-900/40 text-amber-600 dark:text-amber-400 border border-yellow-200/50 dark:border-yellow-700/50 rounded-xl flex items-center justify-center mb-3 group-hover:scale-110 group-hover:rotate-6 transition-all duration-500 shadow-inner">
                              <Calendar size={20} />
                            </div>
                            <h3 className="text-3xl sm:text-4xl font-black text-slate-900 dark:text-white mb-1 tracking-tight">{totalFestivals}</h3>
                            <p className="text-slate-400 dark:text-slate-500 font-bold text-[9px] sm:text-[10px] uppercase tracking-wider">إجمالي المهرجانات</p>
                          </motion.div>

                          {/* Open Festivals - Small Card */}
                          <motion.div 
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ delay: 0.4 }}
                            className="md:col-span-1 md:row-span-1 glass-card rounded-[2rem] p-4 sm:p-5 flex flex-col justify-center items-center text-center relative overflow-hidden group hover:-translate-y-1 transition-all duration-500"
                          >
                            <div className="w-10 h-10 bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-xl flex items-center justify-center mb-3 group-hover:scale-110 group-hover:-rotate-6 transition-all duration-500 shadow-inner">
                              <Clock size={20} />
                            </div>
                            <h3 className="text-3xl sm:text-4xl font-black text-slate-900 dark:text-white mb-1 tracking-tight">{festivals.filter(f => f.isOpen).length}</h3>
                            <p className="text-slate-400 dark:text-slate-500 font-bold text-[9px] sm:text-[10px] uppercase tracking-wider">مهرجانات مفتوحة</p>
                          </motion.div>
                        </div>
                      </div>
                    )}

                    <div id="festivals-section" className="mb-12 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
                      <div>
                        <span className="inline-block px-3 py-1 bg-brand-100 dark:bg-brand-900/30 text-brand-600 dark:text-brand-400 rounded-full text-[10px] font-black uppercase tracking-widest mb-3">المهرجانات</span>
                        <h2 className="text-2xl sm:text-4xl font-black text-slate-900 dark:text-white mb-2 tracking-tight">اختر المهرجان التابع لمدينتك أو بلدتك</h2>
                      </div>
                      <div className="flex items-center gap-2 text-xs font-bold text-slate-400">
                        <span className="w-2 h-2 rounded-full bg-brand-500 animate-pulse" />
                        يتم تحديث المهرجانات بشكل دوري
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 sm:gap-8">
                      {filteredFestivals.length > 0 ? (
                        filteredFestivals.map((f, i) => (
                          <motion.div 
                            key={`${f.id}-${i}`}
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ delay: i * 0.1 }}
                            className="group relative bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 sm:p-8 rounded-[2rem] hover:shadow-2xl hover:shadow-brand-500/10 hover:-translate-y-2 transition-all duration-500 overflow-hidden flex flex-col h-full"
                          >
                            {/* Decorative background element */}
                            <div className="absolute top-0 right-0 w-40 h-40 bg-gradient-to-br from-brand-500/10 to-emerald-500/5 rounded-bl-[4rem] -z-10 transition-transform duration-700 group-hover:scale-150" />
                            <div className="absolute bottom-0 left-0 w-32 h-32 bg-gradient-to-tr from-brand-500/5 to-transparent rounded-tr-[4rem] -z-10 transition-transform duration-700 group-hover:scale-150" />
                            
                            <div className="flex justify-between items-start mb-6 relative z-10">
                              <div className={`w-16 h-16 rounded-2xl flex items-center justify-center transition-all duration-500 group-hover:scale-110 group-hover:-rotate-3 shadow-sm ${f.isOpen ? 'bg-gradient-to-br from-brand-400 to-brand-600 text-white shadow-brand-500/30' : 'bg-slate-100 dark:bg-slate-800 text-slate-400'}`}>
                                <Calendar size={28} strokeWidth={2} />
                              </div>
                              <div className={`px-4 py-1.5 rounded-full text-[10px] sm:text-xs font-bold tracking-wider shadow-sm border ${f.isOpen ? 'bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800' : 'bg-red-50 dark:bg-red-900/30 text-red-600 dark:text-red-400 border-red-200 dark:border-red-800'}`}>
                                {f.isOpen ? 'مفتوح للتسجيل' : 'مغلق'}
                              </div>
                            </div>
                            
                            <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mb-6 tracking-tight group-hover:text-brand-600 dark:group-hover:text-brand-400 transition-colors line-clamp-2 leading-snug">{f.name}</h3>
                            
                            <div className="space-y-3 mb-6 flex-grow">
                              <div className="flex items-center gap-4 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800/50 transition-colors group-hover:bg-brand-50/50 dark:group-hover:bg-brand-900/10 group-hover:border-brand-100 dark:group-hover:border-brand-900/30">
                                <div className="w-10 h-10 rounded-xl bg-white dark:bg-slate-800 flex items-center justify-center shadow-sm text-brand-500 shrink-0">
                                  <Clock size={18} />
                                </div>
                                <div>
                                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-0.5">موعد الحفل</p>
                                  {f.date && getArabicDayWithNight(f.date) && (
                                    <p className="text-xs font-black text-emerald-600 dark:text-emerald-400 mb-0.5">
                                      {getArabicDayWithNight(f.date)}
                                    </p>
                                  )}
                                  <p className="text-sm font-black text-slate-700 dark:text-slate-300">{f.date || 'ادارة المهرجان لم تحدد الموعد'}</p>
                                </div>
                              </div>

                              {f.endDate && (
                                <div className={`flex items-center gap-4 p-4 rounded-2xl border transition-colors ${
                                  new Date(f.endDate) < new Date() 
                                    ? 'bg-red-50/50 dark:bg-red-900/10 border-red-100 dark:border-red-900/30' 
                                    : 'bg-slate-50 dark:bg-slate-800/50 border-slate-100 dark:border-slate-800/50 group-hover:bg-brand-50/50 dark:group-hover:bg-brand-900/10 group-hover:border-brand-100 dark:group-hover:border-brand-900/30'
                                }`}>
                                  <div className={`w-10 h-10 rounded-xl bg-white dark:bg-slate-800 flex items-center justify-center shadow-sm shrink-0 ${new Date(f.endDate) < new Date() ? 'text-red-500' : 'text-brand-500'}`}>
                                    <Calendar size={18} />
                                  </div>
                                  <div className="flex-grow flex items-center justify-between">
                                    <div>
                                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-0.5">انتهاء التسجيل</p>
                                      <p className={`text-sm font-black ${new Date(f.endDate) < new Date() ? 'text-red-600 dark:text-red-400' : 'text-slate-700 dark:text-slate-300'}`}>{f.endDate}</p>
                                    </div>
                                    {new Date(f.endDate) < new Date() && (
                                      <span className="text-[10px] bg-red-100 dark:bg-red-900/50 text-red-600 dark:text-red-400 px-2 py-1 rounded-lg font-bold">منتهي</span>
                                    )}
                                  </div>
                                </div>
                              )}
                            </div>

                            {siteSettings.showRegistrationCount && f.isOpen && (
                              <div 
                                onClick={() => {
                                  const count = allRegistrations.filter(r => r.festivalId === f.id && r.status === 'approved').length;
                                  if (count > 0) setSelectedFestivalForGrooms(f);
                                }}
                                className={`mb-6 px-4 py-3 bg-white dark:bg-slate-900 rounded-2xl flex items-center justify-between border border-slate-100 dark:border-slate-800 shadow-sm ${allRegistrations.filter(r => r.festivalId === f.id && r.status === 'approved').length > 0 ? 'cursor-pointer hover:border-emerald-200 dark:hover:border-emerald-700 transition-colors' : ''}`}
                              >
                                <div className="flex items-center gap-2">
                                  <div className="p-1.5 bg-emerald-50 dark:bg-emerald-900/30 rounded-lg text-emerald-600 dark:text-emerald-400">
                                    <Award size={14} />
                                  </div>
                                  <span className="text-slate-600 dark:text-slate-300 font-bold text-xs">عدد و اسماء الفرسان</span>
                                </div>
                                <span className="text-slate-900 dark:text-white font-black text-lg">
                                  {allRegistrations.filter(r => r.festivalId === f.id && r.status === 'approved').length.toLocaleString('en-US')}
                                </span>
                              </div>
                            )}

                            {/* Social Links */}
                            <div className="flex flex-wrap items-center justify-center gap-2 mb-6 pt-6 border-t border-slate-100 dark:border-slate-800/80">
                              {f.phone && (
                                <a href={`tel:${f.phone}`} className="p-2.5 bg-slate-50 dark:bg-slate-800 text-slate-400 hover:text-brand-600 dark:hover:text-brand-400 rounded-xl transition-all hover:scale-110 hover:bg-brand-50 dark:hover:bg-brand-900/30" title="اتصال">
                                  <Phone size={16} />
                                </a>
                              )}
                              {f.phone2 && (
                                <a href={`tel:${f.phone2}`} className="p-2.5 bg-slate-50 dark:bg-slate-800 text-slate-400 hover:text-brand-600 dark:hover:text-brand-400 rounded-xl transition-all hover:scale-110 hover:bg-brand-50 dark:hover:bg-brand-900/30" title="اتصال">
                                  <Phone size={16} />
                                </a>
                              )}
                              {f.whatsapp && (
                                <a href={`https://wa.me/${f.whatsapp}`} target="_blank" rel="noreferrer" className="p-2.5 bg-slate-50 dark:bg-slate-800 text-slate-400 hover:text-emerald-500 rounded-xl transition-all hover:scale-110 hover:bg-emerald-50 dark:hover:bg-emerald-900/30" title="واتساب">
                                  <MessageCircle size={16} />
                                </a>
                              )}
                              {f.whatsapp2 && (
                                <a href={`https://wa.me/${f.whatsapp2}`} target="_blank" rel="noreferrer" className="p-2.5 bg-slate-50 dark:bg-slate-800 text-slate-400 hover:text-emerald-500 rounded-xl transition-all hover:scale-110 hover:bg-emerald-50 dark:hover:bg-emerald-900/30" title="واتساب">
                                  <MessageCircle size={16} />
                                </a>
                              )}
                              {f.website && (
                                <a href={f.website} target="_blank" rel="noreferrer" className="p-2.5 bg-slate-50 dark:bg-slate-800 text-slate-400 hover:text-blue-500 rounded-xl transition-all hover:scale-110 hover:bg-blue-50 dark:hover:bg-blue-900/30" title="الموقع الإلكتروني">
                                  <Globe size={16} />
                                </a>
                              )}
                              {f.instagram && (
                                <a href={`https://instagram.com/${f.instagram}`} target="_blank" rel="noreferrer" className="p-2.5 bg-slate-50 dark:bg-slate-800 text-slate-400 hover:text-pink-500 rounded-xl transition-all hover:scale-110 hover:bg-pink-50 dark:hover:bg-pink-900/30" title="انستقرام">
                                  <Instagram size={16} />
                                </a>
                              )}
                              {f.xLink && (
                                <a href={`https://x.com/${f.xLink}`} target="_blank" rel="noreferrer" className="p-2.5 bg-slate-50 dark:bg-slate-800 text-slate-400 hover:text-slate-900 dark:hover:text-white rounded-xl transition-all hover:scale-110 hover:bg-slate-200 dark:hover:bg-slate-700" title="منصة X">
                                  <Twitter size={16} />
                                </a>
                              )}
                              {f.facebook && (
                                <a href={f.facebook} target="_blank" rel="noreferrer" className="p-2.5 bg-slate-50 dark:bg-slate-800 text-slate-400 hover:text-blue-600 rounded-xl transition-all hover:scale-110 hover:bg-blue-50 dark:hover:bg-blue-900/30" title="فيسبوك">
                                  <Facebook size={16} />
                                </a>
                              )}
                              {f.snapchat && (
                                <a href={`https://snapchat.com/add/${f.snapchat}`} target="_blank" rel="noreferrer" className="p-2.5 bg-slate-50 dark:bg-slate-800 text-slate-400 hover:text-yellow-500 rounded-xl transition-all hover:scale-110 hover:bg-yellow-50 dark:hover:bg-yellow-900/30" title="سناب شات">
                                  <Ghost size={16} />
                                </a>
                              )}
                              {f.tiktok && (
                                <a href={`https://tiktok.com/@${f.tiktok}`} target="_blank" rel="noreferrer" className="p-2.5 bg-slate-50 dark:bg-slate-800 text-slate-400 hover:text-black dark:hover:text-white rounded-xl transition-all hover:scale-110 hover:bg-slate-200 dark:hover:bg-slate-700" title="تيك توك">
                                  <Video size={16} />
                                </a>
                              )}
                              {f.youtube && (
                                <a href={f.youtube} target="_blank" rel="noreferrer" className="p-2.5 bg-slate-50 dark:bg-slate-800 text-slate-400 hover:text-red-600 rounded-xl transition-all hover:scale-110 hover:bg-red-50 dark:hover:bg-red-900/30" title="يوتيوب">
                                  <Youtube size={16} />
                                </a>
                              )}
                              {f.telegram && (
                                <a href={f.telegram.startsWith('http') ? f.telegram : `https://t.me/${f.telegram}`} target="_blank" rel="noreferrer" className="p-2.5 bg-slate-50 dark:bg-slate-800 text-slate-400 hover:text-blue-400 rounded-xl transition-all hover:scale-110 hover:bg-blue-50 dark:hover:bg-blue-900/30" title="تيلجرام">
                                  <Send size={16} />
                                </a>
                              )}
                            </div>
                            
                            <button 
                              disabled={!f.isOpen || (f.endDate ? new Date(f.endDate) < new Date() : false)}
                              onClick={() => {
                                setSelectedFestival(f);
                                window.scrollTo({ top: 0, behavior: 'smooth' });
                              }}
                              className={`w-full py-4 rounded-2xl font-black text-sm transition-all duration-300 flex items-center justify-center gap-2 group/btn mt-auto ${
                                f.isOpen && (f.endDate ? new Date(f.endDate) >= new Date() : true)
                                ? 'bg-brand-600 dark:bg-brand-500 text-white hover:bg-brand-700 dark:hover:bg-brand-600 shadow-lg shadow-brand-500/20 hover:shadow-brand-500/40 active:scale-95' 
                                : 'bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
                              }`}
                            >
                              {f.isOpen ? (
                                (f.endDate && new Date(f.endDate) < new Date()) ? 'التسجيل منتهي' : <>سجل الآن <ChevronLeft size={18} className="transition-transform group-hover/btn:-translate-x-1" /></>
                              ) : 'التسجيل مغلق'}
                            </button>
                          </motion.div>
                        ))
                      ) : (
                        <div className="col-span-full text-center py-20 bg-white dark:bg-slate-900 rounded-[3rem] border border-dashed border-brand-200 dark:border-slate-800">
                          <div className="w-20 h-20 bg-brand-50 dark:bg-brand-900/30 text-brand-400 rounded-full flex items-center justify-center mx-auto mb-6">
                            <Search size={40} />
                          </div>
                          <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-2">لا توجد مهرجانات متاحة حالياً</h3>
                          {userProfile?.role === 'admin' && (
                            <p className="text-sm text-brand-600 font-bold mt-2">يرجى إضافة مهرجانات من لوحة التحكم</p>
                          )}
                        </div>
                      )}
                      {selectedFestivalForGrooms && (
                        <ApprovedGroomsModal 
                          festival={selectedFestivalForGrooms} 
                          registrations={allRegistrations} 
                          onClose={() => setSelectedFestivalForGrooms(null)} 
                        />
                      )}
                    </div>


                  </>
                )}

                {/* Gallery Section */}
                {siteSettings.showGallery && galleryImages.length > 0 && (
                  <div className="mt-32 mb-20 sm:mb-32">
                    <div className="mb-12 sm:mb-20 text-center">
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                      >
                        <span className="inline-block px-4 py-1.5 bg-brand-100 dark:bg-brand-900/30 text-brand-600 dark:text-brand-400 rounded-full text-[10px] font-black uppercase tracking-widest mb-4">ذكرياتنا</span>
                        <h2 className="text-4xl sm:text-6xl font-black text-slate-900 dark:text-white mb-6 tracking-tight">معرض الصور</h2>
                        <p className="text-slate-500 dark:text-slate-400 font-bold text-base sm:text-xl max-w-2xl mx-auto leading-relaxed">لقطات من مهرجانات الزواج الجماعي السابقة التي أدخلت البهجة على قلوب العائلات</p>
                      </motion.div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-8 max-w-6xl mx-auto">
                        {galleryImages.slice(0, 4).map((img, i) => (
                          <motion.div
                            key={img.id || `img-${i}`}
                            initial={{ opacity: 0, scale: 0.9, rotate: i % 2 === 0 ? -2 : 2 }}
                          whileInView={{ opacity: 1, scale: 1, rotate: 0 }}
                          viewport={{ once: true }}
                          transition={{ delay: i * 0.1, duration: 0.5 }}
                          className="aspect-square rounded-[2.5rem] overflow-hidden border-8 border-white dark:border-slate-800 shadow-2xl hover:scale-105 hover:rotate-2 transition-all duration-500 cursor-pointer group"
                        >
                          <img 
                            src={img.url} 
                            alt={img.name || `Gallery ${i}`} 
                            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
                            referrerPolicy="no-referrer" 
                          />
                          <div className="absolute inset-0 bg-brand-600/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                        </motion.div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Testimonials Section */}
                {siteSettings.showTestimonials && (
                  <div className="mt-32 mb-20 sm:mb-32 relative">
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-5xl h-full bg-brand-500/5 blur-[150px] rounded-full -z-10" />
                    
                    <div className="mb-12 sm:mb-20 text-center">
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                      >
                        <span className="inline-block px-4 py-1.5 bg-brand-100 dark:bg-brand-900/30 text-brand-600 dark:text-brand-400 rounded-full text-[10px] font-black uppercase tracking-widest mb-4">قالوا عنا</span>
                        <h2 className="text-4xl sm:text-6xl font-black text-slate-900 dark:text-white mb-6 tracking-tight">قصص النجاح</h2>
                        <p className="text-slate-500 dark:text-slate-400 font-bold text-base sm:text-xl max-w-2xl mx-auto leading-relaxed mb-10">تجارب الأزواج الذين استفادوا من خدمات الجمعية وشاركونا فرحتهم</p>
                        
                        <button 
                          onClick={() => setShowPublicTestimonialModal(true)}
                          className="bg-brand-600 hover:bg-brand-700 text-white px-8 py-4 rounded-2xl font-black transition-all shadow-xl shadow-brand-600/20 hover:shadow-brand-600/40 active:scale-95 flex items-center gap-3 mx-auto"
                        >
                          <Plus size={20} /> شاركنا قصة نجاحك
                        </button>
                      </motion.div>
                    </div>

                    {testimonials.filter(t => t.isActive).length > 0 ? (
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 max-w-6xl mx-auto mt-12">
                        {testimonials.filter(t => t.isActive).map((testimonial, i) => (
                          <motion.div
                            key={testimonial.id || `testi-${i}`}
                            initial={{ opacity: 0, y: 20 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true }}
                            transition={{ delay: i * 0.1 }}
                            className="bg-white dark:bg-slate-900 p-8 rounded-[2rem] border border-slate-100 dark:border-slate-800 shadow-sm hover:shadow-xl transition-all relative"
                          >
                            <div className="absolute top-6 left-6 text-emerald-100 dark:text-emerald-900/30">
                              <MessageSquareHeart size={48} />
                            </div>
                            <div className="mb-6">
                              <h3 className="text-xl font-black text-slate-900 dark:text-white mb-1">{testimonial.coupleName}</h3>
                              <p className="text-xs font-bold text-slate-400">
                                {testimonial.createdAt?.toDate ? format(testimonial.createdAt.toDate(), 'yyyy/MM/dd') : ''}
                              </p>
                            </div>
                            <p className="text-slate-600 dark:text-slate-300 font-bold leading-relaxed relative z-10">
                              "{testimonial.story}"
                            </p>
                          </motion.div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-12">
                        <p className="text-slate-500 dark:text-slate-400 font-bold">كن أول من يشارك قصة نجاحه!</p>
                      </div>
                    )}
                  </div>
                )}
              </>
            )}
          </>
        ) : view === 'dashboard' && userProfile ? (
          <Dashboard 
            userProfile={userProfile} 
            festivals={festivals} 
            quotaExceeded={quotaExceeded}
            onEditRegistration={(reg) => {
              setEditingRegistration(reg);
              setView('home');
            }}
          />
        ) : view === 'groom-portal' ? (
          <GroomPortal 
            onClose={() => setView('home')} 
            siteSettings={siteSettings}
            festivals={festivals}
            quotaExceeded={quotaExceeded}
            onEditRequest={(reg) => {
              setEditingRegistration(reg);
              setView('home');
            }}
          />
        ) : (
          <div className="text-center py-24">
            <h2 className="text-2xl font-black text-slate-900 dark:text-white">يرجى تسجيل الدخول للوصول إلى لوحة التحكم</h2>
          </div>
        )}
      </main>

      {/* Login Modal */}
      <AnimatePresence>
        {showPublicTestimonialModal && (
          <AddPublicTestimonialModal key="add-public-testimonial" onClose={() => setShowPublicTestimonialModal(false)} />
        )}

        {showLoginForm && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white w-full max-w-md p-8 rounded-[2.5rem] shadow-2xl overflow-hidden relative"
            >
              <button 
                onClick={() => setShowLoginForm(false)}
                className="absolute top-6 left-6 p-2 bg-slate-100 text-slate-400 rounded-xl hover:bg-slate-200 transition"
              >
                <X size={20} />
              </button>

              <div className="text-center mb-8">
                <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Lock size={32} />
                </div>
                <h3 className="text-2xl font-black text-slate-900">
                  {isResettingPassword ? 'إعادة تعيين كلمة المرور' : 'تسجيل دخول المشرفين'}
                </h3>
                <p className="text-slate-400 font-bold text-sm">
                  {isResettingPassword ? 'أدخل بريدك الإلكتروني لاستلام رابط إعادة التعيين' : 'أدخل بياناتك للمتابعة إلى لوحة التحكم'}
                </p>
              </div>

              {authError && (
                <div className={`mb-6 p-4 rounded-2xl text-xs font-bold flex items-center gap-2 border ${
                  authError.includes('تم إرسال') ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-red-50 text-red-600 border-red-100'
                }`}>
                  <AlertCircle size={16} />
                  {authError}
                </div>
              )}

              <form onSubmit={loginWithEmail} className="space-y-5">
                <div>
                  <label className="block text-[11px] font-black text-slate-400 mb-2 mr-1 uppercase tracking-wider">البريد الإلكتروني</label>
                  <div className="relative group">
                    <User className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 transition-colors group-focus-within:text-emerald-500" size={20} />
                    <input 
                      type="email"
                      value={loginEmail}
                      onChange={(e) => setLoginEmail(e.target.value)}
                      autoFocus
                      required
                      className="w-full pr-12 pl-4 py-4.5 bg-slate-50 border-2 border-slate-100 rounded-3xl outline-none focus:border-emerald-500 focus:bg-white transition-all font-bold text-slate-700 shadow-sm"
                      placeholder="example@domain.com"
                    />
                  </div>
                </div>
                {!isResettingPassword && (
                  <div>
                    <label className="block text-[11px] font-black text-slate-400 mb-2 mr-1 uppercase tracking-wider">كلمة المرور</label>
                    <div className="relative group">
                      <Lock className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 transition-colors group-focus-within:text-emerald-500" size={20} />
                      <input 
                        type={showPassword ? "text" : "password"}
                        value={loginPassword}
                        onChange={(e) => setLoginPassword(e.target.value)}
                        required
                        className="w-full pr-12 pl-12 py-4.5 bg-slate-50 border-2 border-slate-100 rounded-3xl outline-none focus:border-emerald-500 focus:bg-white transition-all font-bold text-slate-700 shadow-sm"
                        placeholder="••••••••"
                      />
                      <button 
                        type="button" 
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition"
                      >
                        {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                      </button>
                    </div>
                  </div>
                )}
                {!isResettingPassword ? (
                  <div className="flex justify-start">
                    <button 
                      type="button"
                      onClick={() => setIsResettingPassword(true)}
                      className="text-xs font-bold text-emerald-600 hover:text-emerald-700 transition"
                    >
                      هل نسيت كلمة المرور؟
                    </button>
                  </div>
                ) : (
                  <div className="flex justify-start">
                    <button 
                      type="button"
                      onClick={() => setIsResettingPassword(false)}
                      className="text-xs font-bold text-emerald-600 hover:text-emerald-700 transition"
                    >
                      العودة لتسجيل الدخول
                    </button>
                  </div>
                )}
                <button 
                  type="submit"
                  disabled={isLoggingIn}
                  className="w-full py-5 bg-emerald-600 text-white rounded-[2rem] font-black text-lg hover:bg-emerald-700 transition-all shadow-xl shadow-emerald-500/20 active:scale-95 disabled:opacity-50 flex items-center justify-center gap-3 mt-2"
                >
                  {isLoggingIn ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      جاري الدخول...
                    </>
                  ) : (
                    <>
                      {isResettingPassword ? <Send size={20} /> : <LogIn size={20} />}
                      {isResettingPassword ? 'إرسال رابط التعيين' : 'تسجيل دخول آمن'}
                    </>
                  )}
                </button>
                {isResettingPassword && (
                  <button 
                    type="button"
                    onClick={() => setIsResettingPassword(false)}
                    className="w-full py-2 text-xs font-bold text-slate-400 hover:text-slate-600 transition"
                  >
                    العودة لتسجيل الدخول
                  </button>
                )}
              </form>

              {/* Removed Google Login */}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <footer className="bg-white dark:bg-slate-950 border-t border-brand-100 dark:border-slate-900 py-6 sm:py-8 mt-10">
        <div className="max-w-screen-2xl mx-auto px-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-3">
              <a href="https://www.reaayah.sa/" target="_blank" rel="noopener noreferrer" className="w-10 h-10 bg-brand-50 dark:bg-slate-900 text-brand-600 dark:text-brand-400 rounded-xl flex items-center justify-center hover:bg-brand-600 hover:text-white transition-all duration-300 shadow-sm" title="موقع الجمعية">
                <Globe size={18} />
              </a>
              {siteSettings.contactNumber && (
                <a href={`tel:${siteSettings.contactNumber}`} className="w-10 h-10 bg-brand-50 dark:bg-slate-900 text-brand-600 dark:text-brand-400 rounded-xl flex items-center justify-center hover:bg-brand-600 hover:text-white transition-all duration-300 shadow-sm">
                  <Phone size={18} />
                </a>
              )}
              {siteSettings.contactNumber2 && (
                <a href={`tel:${siteSettings.contactNumber2}`} className="w-10 h-10 bg-brand-50 dark:bg-slate-900 text-brand-600 dark:text-brand-400 rounded-xl flex items-center justify-center hover:bg-brand-600 hover:text-white transition-all duration-300 shadow-sm">
                  <Phone size={18} />
                </a>
              )}
              {siteSettings.whatsappNumber && (
                <a href={`https://wa.me/${siteSettings.whatsappNumber}`} className="w-10 h-10 bg-brand-50 dark:bg-slate-900 text-brand-600 dark:text-brand-400 rounded-xl flex items-center justify-center hover:bg-brand-600 hover:text-white transition-all duration-300 shadow-sm">
                  <MessageCircle size={18} />
                </a>
              )}
              {siteSettings.whatsappNumber2 && (
                <a href={`https://wa.me/${siteSettings.whatsappNumber2}`} className="w-10 h-10 bg-brand-50 dark:bg-slate-900 text-brand-600 dark:text-brand-400 rounded-xl flex items-center justify-center hover:bg-brand-600 hover:text-white transition-all duration-300 shadow-sm">
                  <MessageCircle size={18} />
                </a>
              )}
              {siteSettings.xLink && (
                <a href={siteSettings.xLink} className="w-10 h-10 bg-brand-50 dark:bg-slate-900 text-brand-600 dark:text-brand-400 rounded-xl flex items-center justify-center hover:bg-brand-600 hover:text-white transition-all duration-300 shadow-sm">
                  <Twitter size={18} />
                </a>
              )}
            </div>
            
            <div className="text-center md:text-right">
              <p className="text-slate-400 dark:text-slate-500 font-bold text-[10px] mb-1 uppercase tracking-widest">جميع الحقوق محفوظة</p>
              <p className="text-slate-900 dark:text-white font-black text-xs">© {new Date().getFullYear()} {siteSettings.siteName || 'الجمعية الخيرية'}</p>
            </div>

            <div className="flex flex-col items-center md:items-end gap-2">
              <p className="text-slate-400 dark:text-slate-600 font-bold text-[9px] uppercase tracking-[0.2em]">صنع بكل حب لخدمة المجتمع</p>
              <a 
                href="https://wa.me/966565767072" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-full text-[10px] font-bold hover:bg-emerald-100 dark:hover:bg-emerald-900/50 transition-colors"
              >
                برمجة السفير <MessageCircle size={12} />
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
