import React, { useState } from 'react';
import { Calendar, Plus, Share2, Trash2, Archive, ArchiveRestore, Clock, Users, Star, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface FestivalsTabProps {
  festivals: any[];
  registrations: any[];
  userProfile: any;
  updateFestivalName: (id: string, name: string) => Promise<void>;
  updateFestivalDate: (id: string, date: string) => Promise<void>;
  updateFestivalEndDate: (id: string, endDate: string) => Promise<void>;
  updateFestivalFees: (id: string, fees: number) => Promise<void>;
  updateFestivalSiblingPricing: (id: string, siblingDiscountType: string, twoBrothersFees: number, threeBrothersFees: number) => Promise<void>;
  updateFestivalArchiveStatus: (id: string, isArchived: boolean) => Promise<void>;
  setEditingSocialFestival: (festival: any) => void;
  setFestivalStatusConfirm: (confirm: { id: string, name: string, isOpen: boolean } | null) => void;
  setDeleteConfirm: (confirm: { id: string, type: 'festival' | 'supervisor' | 'testimonial' } | null) => void;
  setShowAddFestival: (show: boolean) => void;
  setShowSeedConfirm: (show: boolean) => void;
}

export function FestivalsTab({
  festivals,
  registrations,
  userProfile,
  updateFestivalName,
  updateFestivalDate,
  updateFestivalEndDate,
  updateFestivalFees,
  updateFestivalSiblingPricing,
  updateFestivalArchiveStatus,
  setEditingSocialFestival,
  setFestivalStatusConfirm,
  setDeleteConfirm,
  setShowAddFestival,
  setShowSeedConfirm
}: FestivalsTabProps) {
  const [showArchived, setShowArchived] = useState(false);
  const [editingSiblingFestival, setEditingSiblingFestival] = useState<any | null>(null);
  const [siblingDiscountType, setSiblingDiscountType] = useState<'none' | 'second_free' | 'third_free' | 'custom_prices'>('none');
  const [twoBrothersFees, setTwoBrothersFees] = useState(0);
  const [threeBrothersFees, setThreeBrothersFees] = useState(0);
  const [viewingFeedbackFestival, setViewingFeedbackFestival] = useState<any | null>(null);

  const getFestivalEvaluationStats = (festivalId: string) => {
    const festivalRegs = registrations?.filter(r => r.festivalId === festivalId && r.festivalEvaluation?.rating) || [];
    if (festivalRegs.length === 0) return null;
    
    const sum = festivalRegs.reduce((acc, r) => acc + (r.festivalEvaluation.rating || 0), 0);
    const avg = sum / festivalRegs.length;
    return {
      average: Number(avg.toFixed(1)),
      count: festivalRegs.length,
      regs: festivalRegs
    };
  };

  const filteredFestivals = festivals.filter(f => showArchived ? f.isArchived : !f.isArchived);

  const sortedFestivals = [...filteredFestivals].sort((a, b) => {
    if (a.isOpen && !b.isOpen) return -1;
    if (!a.isOpen && b.isOpen) return 1;
    return 0;
  });

  return (
    <div className="p-4 sm:p-8">
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4 mb-6 sm:mb-8">
        <div className="flex flex-col gap-1">
          <h3 className="text-2xl sm:text-3xl font-black text-slate-900">
            {showArchived ? 'أرشيف المهرجانات' : 'إدارة المهرجانات'}
          </h3>
          <p className="text-xs text-slate-400 font-bold">
            {showArchived ? 'هنا تجد المهرجانات المؤرشفة التي انتهت' : 'إدارة المهرجانات النشطة وعمليات التسجيل'}
          </p>
        </div>
        <div className="flex flex-wrap gap-2 sm:gap-3">
          <button 
            onClick={() => setShowArchived(!showArchived)} 
            className={`px-4 sm:px-6 py-2 rounded-lg sm:rounded-xl font-bold text-sm sm:text-base flex items-center gap-2 transition ${
              showArchived 
                ? 'bg-amber-100 text-amber-700 hover:bg-amber-200' 
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            {showArchived ? <ArchiveRestore size={18} /> : <Archive size={18} />}
            {showArchived ? 'العودة للمهرجانات النشطة' : 'عرض الأرشيف'}
          </button>
          {userProfile.role === 'admin' && !showArchived && (
            <>
              <button onClick={() => setShowSeedConfirm(true)} className="bg-slate-100 text-slate-600 px-4 sm:px-6 py-2 rounded-lg sm:rounded-xl font-bold text-sm sm:text-base flex items-center gap-2 hover:bg-slate-200 transition">
                استعادة الافتراضي
              </button>
              <button onClick={() => setShowAddFestival(true)} className="bg-emerald-600 text-white px-4 sm:px-6 py-2 rounded-lg sm:rounded-xl font-bold text-sm sm:text-base flex items-center gap-2 hover:bg-emerald-700 transition">
                <Plus size={16} className="sm:w-[18px] sm:h-[18px]" /> إضافة مهرجان
              </button>
            </>
          )}
        </div>
      </div>
      <div className="overflow-x-auto">
        {/* Mobile Cards View */}
        <div className="block sm:hidden space-y-4">
          {sortedFestivals.map((f, index) => (
            <div 
              key={f.id} 
              className={`relative p-5 rounded-2xl border transition-all duration-500 space-y-4 ${
                f.isOpen 
                  ? 'bg-linear-to-br from-emerald-50/40 via-emerald-50/10 to-white border-emerald-200 shadow-2xl shadow-emerald-500/10 scale-[1.03] ring-2 ring-emerald-500/20 ring-offset-2' 
                  : f.isArchived 
                    ? 'bg-slate-50 opacity-75 grayscale-[0.3]'
                    : 'bg-rose-50/30 border-rose-200 shadow-sm opacity-90'
              }`}
            >
              <div className={`absolute -top-3 -right-3 w-8 h-8 text-sm font-black rounded-xl flex items-center justify-center shadow-xl z-20 transition-all duration-500 ${
                f.isOpen 
                  ? 'bg-emerald-600 text-white shadow-emerald-500/40 scale-110 rotate-3 ring-2 ring-white' 
                  : f.isArchived
                    ? 'bg-slate-500 text-white'
                    : 'bg-rose-600 text-white'
              }`}>
                {index + 1}
              </div>
              
              {f.isOpen ? (
                <div className="absolute top-4 left-4 flex flex-col items-end gap-2">
                  <div className="flex items-center gap-1.5 px-3 py-1 bg-emerald-600 text-white text-[11px] font-black rounded-full animate-pulse shadow-lg shadow-emerald-500/30">
                    <span className="w-1.5 h-1.5 bg-white rounded-full animate-ping"></span>
                    متاح للتسجيل
                  </div>
                  <div className="flex items-center gap-1.5 px-3 py-1 bg-amber-500 text-white text-[10px] font-black rounded-full shadow-lg shadow-amber-500/30">
                    <Clock size={10} />
                    {registrations.filter(r => r.festivalId === f.id && r.status === 'pending').length} طلب معلق
                  </div>
                </div>
              ) : f.isArchived ? (
                <div className="absolute top-4 left-4">
                  <div className="flex items-center gap-1.5 px-3 py-1 bg-slate-200 text-slate-500 text-[11px] font-black rounded-full border border-slate-300">
                    مؤرشف
                  </div>
                </div>
              ) : (
                <div className="absolute top-4 left-4">
                  <div className="flex items-center gap-1.5 px-3 py-1 bg-rose-600/10 text-rose-600 text-[11px] font-black rounded-full border border-rose-200">
                    التسجيل مغلق
                  </div>
                </div>
              )}

              <div className="flex flex-col gap-1 pt-4">
                <span className="text-xs text-slate-400 font-black uppercase tracking-widest">اسم المهرجان</span>
                <div className="flex items-center justify-between gap-4">
                  <input 
                    type="text" 
                    defaultValue={f.name} 
                    onBlur={(e) => updateFestivalName(f.id, e.target.value)}
                    className="bg-transparent border-none focus:ring-0 text-lg font-black text-slate-900 p-0 flex-1"
                  />
                  {!f.isArchived && (
                    <button 
                      onClick={() => setFestivalStatusConfirm({ id: f.id, name: f.name, isOpen: !f.isOpen })}
                      className={`shrink-0 px-3 py-1 rounded-lg text-xs font-black transition-all ${
                        f.isOpen 
                          ? 'bg-emerald-100 text-emerald-700 hover:bg-emerald-200 ring-1 ring-emerald-200' 
                          : 'bg-rose-100 text-rose-700 hover:bg-rose-200 ring-1 ring-rose-200'
                      }`}
                    >
                      {f.isOpen ? 'مفتوح' : 'مغلق'}
                    </button>
                  )}
                </div>
                {/* Rating stats */}
                {(() => {
                  const stats = getFestivalEvaluationStats(f.id);
                  if (stats) {
                    return (
                      <button
                        onClick={() => setViewingFeedbackFestival(f)}
                        className="flex items-center gap-1.5 mt-1 bg-amber-50 text-right px-2.5 py-1 rounded-xl w-fit border border-amber-100/50 hover:bg-amber-100 transition active:scale-95"
                      >
                        <Star className="text-amber-500 fill-amber-500" size={12} />
                        <span className="text-xs font-black text-amber-700">{stats.average} / 5</span>
                        <span className="text-[10px] text-amber-500/80 font-bold">({stats.count} تقييم - عرض التفاصيل)</span>
                      </button>
                    );
                  }
                  return null;
                })()}
              </div>

              <div className="grid grid-cols-2 gap-4 pb-2">
                <div className="bg-white/50 backdrop-blur-sm p-3 rounded-2xl border border-slate-100/50 shadow-sm">
                  <div className="flex items-center gap-2 mb-2 text-slate-400">
                    <Calendar size={12} />
                    <span className="text-[9px] font-black uppercase">موعد الحفل</span>
                  </div>
                  <input 
                    type="date" 
                    defaultValue={f.date} 
                    onBlur={(e) => updateFestivalDate(f.id, e.target.value)}
                    className="bg-transparent border-none focus:ring-0 text-[11px] font-black text-slate-700 p-0 w-full"
                  />
                </div>
                <div className="bg-white/50 backdrop-blur-sm p-3 rounded-2xl border border-slate-100/50 shadow-sm">
                  <div className="flex items-center gap-2 mb-2 text-slate-400">
                    <Calendar size={12} className="rotate-12" />
                    <span className="text-[9px] font-black uppercase">انتهاء التسجيل</span>
                  </div>
                  <input 
                    type="date" 
                    defaultValue={f.endDate || ''} 
                    onBlur={(e) => updateFestivalEndDate(f.id, e.target.value)}
                    className="bg-transparent border-none focus:ring-0 text-[11px] font-black text-slate-700 p-0 w-full"
                  />
                </div>
                <div className={`p-3 rounded-2xl border col-span-2 shadow-sm transition-colors ${
                  f.isOpen ? 'bg-emerald-600/5 border-emerald-100' : 'bg-white/50 border-slate-100'
                }`}>
                  <span className="block text-[9px] text-slate-400 font-black uppercase mb-1">رسوم الاشتراك</span>
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <input 
                        type="number" 
                        defaultValue={f.fees} 
                        onBlur={(e) => updateFestivalFees(f.id, Number(e.target.value))}
                        className="bg-transparent border-none focus:ring-0 text-sm font-black text-slate-900 p-0 w-24"
                      />
                      <span className="text-xs font-bold text-slate-400 italic font-bold">SAR</span>
                    </div>
                    <button
                      onClick={() => {
                        setEditingSiblingFestival(f);
                        setSiblingDiscountType(f.siblingDiscountType || 'none');
                        setTwoBrothersFees(f.twoBrothersFees || 15000);
                        setThreeBrothersFees(f.threeBrothersFees || 22000);
                      }}
                      className="flex items-center gap-1 px-2 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-800/40 rounded-xl text-[10px] font-black transition"
                    >
                      <Users size={12} />
                      {f.siblingDiscountType && f.siblingDiscountType !== 'none' ? 'خصم إخوة مفعّل' : 'خصم الإخوة'}
                    </button>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-4 border-t border-slate-100/50">
                <button 
                  onClick={() => setEditingSocialFestival(f)}
                  className={`flex-1 flex items-center justify-center gap-2 h-11 rounded-xl font-black text-xs transition-all ${
                    f.isOpen 
                      ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/20 hover:bg-emerald-700 hover:-translate-y-0.5' 
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  <Share2 size={16} />
                  إدارة الروابط
                </button>
                {userProfile.role === 'admin' && (
                  <button 
                    onClick={() => updateFestivalArchiveStatus(f.id, !f.isArchived)}
                    className={`shrink-0 w-11 h-11 flex items-center justify-center rounded-xl transition-all border ${
                      f.isArchived 
                        ? 'bg-amber-50 text-amber-600 border-amber-100 hover:bg-amber-100' 
                        : 'bg-slate-50 text-slate-400 border-slate-100 hover:text-amber-600 hover:bg-amber-50'
                    }`}
                    title={f.isArchived ? 'إلغاء الأرشفة' : 'أرشفة المهرجان'}
                  >
                    {f.isArchived ? <ArchiveRestore size={18} /> : <Archive size={18} />}
                  </button>
                )}
                {(userProfile.role === 'admin' || userProfile.role === 'supervisor') && (
                  <button 
                    onClick={() => setDeleteConfirm({ id: f.id, type: 'festival' })} 
                    className="shrink-0 w-11 h-11 flex items-center justify-center bg-rose-50 text-rose-600 rounded-xl hover:bg-rose-100 hover:text-rose-700 transition-all border border-rose-100"
                  >
                    <Trash2 size={18} />
                  </button>
                )}
              </div>
            </div>
          ))}
          {sortedFestivals.length === 0 && (
            <div className="py-12 text-center bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200">
               <Archive size={40} className="mx-auto text-slate-300 mb-3" />
               <p className="text-slate-500 font-bold">{showArchived ? 'لا توجد مهرجانات مؤرشفة' : 'لا توجد مهرجانات نشطة'}</p>
            </div>
          )}
        </div>

        {/* Desktop Table View */}
        <table className="hidden sm:table w-full text-right min-w-[700px]">
          <thead>
            <tr className="border-b border-slate-100">
              <th className="pb-4 font-black text-slate-400 text-[10px] sm:text-sm w-12 text-center">#</th>
              <th className="pb-4 font-black text-slate-400 text-[10px] sm:text-sm">المهرجان</th>
              <th className="pb-4 font-black text-slate-400 text-[10px] sm:text-sm">موعد الحفل</th>
              <th className="pb-4 font-black text-slate-400 text-[10px] sm:text-sm">انتهاء التسجيل</th>
              <th className="pb-4 font-black text-slate-400 text-[10px] sm:text-sm">رسوم الاشتراك</th>
              <th className="pb-4 font-black text-slate-400 text-[10px] sm:text-sm">الطلبات المعلقة</th>
              <th className="pb-4 font-black text-slate-400 text-[10px] sm:text-sm">التواصل</th>
              <th className="pb-4 font-black text-slate-400 text-[10px] sm:text-sm">الحالة</th>
              <th className="pb-4 font-black text-slate-400 text-[10px) sm:text-sm">الإجراءات</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {sortedFestivals.map((f, index) => (
              <tr 
                key={f.id} 
                className={`group transition-all duration-500 border-r-4 ${
                  f.isOpen 
                    ? 'bg-linear-to-r from-emerald-50/60 via-emerald-50/20 to-transparent hover:from-emerald-100/60 border-r-emerald-500 shadow-sm' 
                    : f.isArchived
                      ? 'bg-slate-50/50 hover:bg-slate-100/50 border-r-slate-300 opacity-80'
                      : 'bg-rose-50/40 hover:bg-rose-100/40 border-r-rose-500 opacity-90'
                }`}
              >
                <td className="py-5 text-center">
                  <span className={`text-xs font-black w-10 h-10 rounded-xl flex items-center justify-center mx-auto transition-all duration-500 ${
                    f.isOpen 
                      ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-500/40 scale-110' 
                      : f.isArchived
                        ? 'bg-slate-200 text-slate-500'
                        : 'bg-rose-100 text-rose-700'
                  }`}>
                    {index + 1}
                  </span>
                </td>
                <td className="py-5 font-bold text-slate-900">
                  <div className="flex flex-col">
                    <input 
                      type="text" 
                      defaultValue={f.name} 
                      onBlur={(e) => updateFestivalName(f.id, e.target.value)}
                      className="bg-transparent border-none focus:ring-0 text-sm font-black text-slate-900 w-full p-0"
                    />
                    {/* Rating stats */}
                    {(() => {
                      const stats = getFestivalEvaluationStats(f.id);
                      if (stats) {
                        return (
                          <button
                            onClick={() => setViewingFeedbackFestival(f)}
                            className="flex items-center gap-1 mt-1 bg-amber-50 px-2 py-0.5 rounded-lg w-fit border border-amber-100/40 hover:bg-amber-100 transition text-[10px] font-black text-amber-700 active:scale-95"
                          >
                            <Star className="text-amber-500 fill-amber-500" size={10} />
                            <span>{stats.average} ({stats.count} تقييم)</span>
                          </button>
                        );
                      }
                      return null;
                    })()}
                    {f.isOpen && (
                      <span className="text-[9px] font-black text-emerald-600 uppercase tracking-tighter animate-pulse mt-0.5">جاري استقبال الطلبات</span>
                    )}
                    {f.isArchived && (
                      <span className="text-[9px] font-black text-slate-400 uppercase tracking-tighter mt-0.5">مهرجان مؤرشف</span>
                    )}
                  </div>
                </td>
                <td className="py-5">
                  <input 
                    type="date" 
                    defaultValue={f.date} 
                    onBlur={(e) => updateFestivalDate(f.id, e.target.value)}
                    className="bg-transparent border-none focus:ring-0 text-sm font-bold text-slate-600"
                  />
                </td>
                <td className="py-5">
                  <input 
                    type="date" 
                    defaultValue={f.endDate || ''} 
                    onBlur={(e) => updateFestivalEndDate(f.id, e.target.value)}
                    className="bg-transparent border-none focus:ring-0 text-sm font-bold text-slate-600"
                  />
                </td>
                <td className="py-5 text-slate-900 font-black">
                  <div className="flex flex-col gap-1.5">
                    <div className="flex items-center gap-1">
                      <input 
                        type="number" 
                        defaultValue={f.fees} 
                        onBlur={(e) => updateFestivalFees(f.id, Number(e.target.value))}
                        className="w-16 bg-transparent border-none focus:ring-0 text-sm font-black"
                      />
                      <span className="text-[10px] text-slate-400">SAR</span>
                    </div>
                    <button
                      onClick={() => {
                        setEditingSiblingFestival(f);
                        setSiblingDiscountType(f.siblingDiscountType || 'none');
                        setTwoBrothersFees(f.twoBrothersFees || 15000);
                        setThreeBrothersFees(f.threeBrothersFees || 22000);
                      }}
                      className={`flex items-center gap-1 px-2 py-1 rounded-lg text-[9px] font-black border transition w-fit ${
                        f.siblingDiscountType && f.siblingDiscountType !== 'none'
                          ? 'bg-emerald-50 border-emerald-100 text-emerald-700 hover:bg-emerald-100 dark:bg-emerald-950/20 dark:border-emerald-900/40 dark:text-emerald-400'
                          : 'bg-slate-50 border-slate-200 text-slate-500 hover:bg-slate-100 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-400'
                      }`}
                    >
                      <Users size={10} />
                      {f.siblingDiscountType && f.siblingDiscountType !== 'none' ? 'خصم إخوة مفعّل' : 'خصم الإخوة'}
                    </button>
                  </div>
                </td>
                <td className="py-5">
                  <div className="flex items-center gap-2">
                    <div className={`px-3 py-1 rounded-full text-xs font-black flex items-center gap-1.5 ${
                      registrations.filter(r => r.festivalId === f.id && r.status === 'pending').length > 0
                        ? 'bg-amber-100 text-amber-700'
                        : 'bg-slate-100 text-slate-400'
                    }`}>
                      <Clock size={12} />
                      {registrations.filter(r => r.festivalId === f.id && r.status === 'pending').length} طلب
                    </div>
                  </div>
                </td>
                <td className="py-5">
                  <button 
                    onClick={() => setEditingSocialFestival(f)}
                    className={`p-2.5 rounded-xl transition-all duration-300 flex items-center gap-2 ${
                      f.isOpen 
                        ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/20 hover:bg-emerald-700 hover:-translate-y-0.5' 
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    <Share2 size={14} />
                    <span className="text-[10px] font-black uppercase">الروابط</span>
                  </button>
                </td>
                <td className="py-5">
                  {!f.isArchived ? (
                    <button 
                      onClick={() => setFestivalStatusConfirm({ id: f.id, name: f.name, isOpen: !f.isOpen })}
                      className={`px-4 py-1.5 rounded-lg text-[10px] font-black transition-all ${
                        f.isOpen 
                          ? 'bg-emerald-100 text-emerald-700 ring-1 ring-emerald-200' 
                          : 'bg-rose-100 text-rose-700 ring-1 ring-rose-200'
                      }`}
                    >
                      {f.isOpen ? 'مفتوح' : 'مغلق'}
                    </button>
                  ) : (
                    <span className="px-4 py-1.5 rounded-lg text-[10px] font-black bg-slate-100 text-slate-400 ring-1 ring-slate-200">
                      مؤرشف
                    </span>
                  )}
                </td>
                <td className="py-5">
                  <div className="flex items-center gap-1">
                    {userProfile.role === 'admin' && (
                      <button 
                        onClick={() => updateFestivalArchiveStatus(f.id, !f.isArchived)}
                        className={`w-10 h-10 flex items-center justify-center rounded-xl transition-all ${
                          f.isArchived 
                            ? 'bg-amber-50 text-amber-600 hover:bg-amber-100' 
                            : 'text-slate-300 hover:bg-amber-50 hover:text-amber-600'
                        }`}
                        title={f.isArchived ? 'إلغاء الأرشفة' : 'أرشفة المهرجان'}
                      >
                        {f.isArchived ? <ArchiveRestore size={18} /> : <Archive size={18} />}
                      </button>
                    )}
                    {(userProfile.role === 'admin' || userProfile.role === 'supervisor') && (
                      <button onClick={() => setDeleteConfirm({ id: f.id, type: 'festival' })} className="w-10 h-10 flex items-center justify-center rounded-xl text-slate-300 hover:bg-rose-50 hover:text-rose-600 transition-all">
                        <Trash2 size={18} />
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
            {sortedFestivals.length === 0 && (
              <tr>
                <td colSpan={8} className="py-20 text-center">
                  <Archive size={40} className="mx-auto text-slate-200 mb-3" />
                  <p className="text-slate-400 font-bold">{showArchived ? 'لا توجد مهرجانات مؤرشفة بعد' : 'لا توجد مهرجانات نشطة حالياً'}</p>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Sibling Pricing Settings Modal */}
      <AnimatePresence>
        {editingSiblingFestival && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }} 
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white w-full max-w-md p-8 rounded-[2.5rem] shadow-2xl overflow-y-auto max-h-[90vh]"
            >
              <h3 className="text-xl font-black text-slate-900 mb-2 flex items-center gap-2">
                <Users className="text-emerald-600" size={24} />
                إعدادات رسوم الإخوة
              </h3>
              <p className="text-xs text-slate-400 font-bold mb-6">مهرجان: {editingSiblingFestival.name}</p>
              
              <div className="space-y-6 text-right" dir="rtl">
                <div>
                  <label className="block text-xs font-black text-slate-400 mb-2 font-black text-emerald-600">نظام رسوم/خصم الإخوة</label>
                  <select 
                    value={siblingDiscountType} 
                    onChange={e => setSiblingDiscountType(e.target.value as any)} 
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 font-bold text-slate-700"
                  >
                    <option value="none">لا يوجد خصم (الرسوم كاملة لكل أخ)</option>
                    <option value="second_free">الأخ الثاني مجاناً</option>
                    <option value="third_free">الأخ الثالث مجاناً</option>
                    <option value="custom_prices">رسوم مخصصة للمجموعات الأخوية</option>
                  </select>
                </div>

                {siblingDiscountType === 'custom_prices' && (
                  <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-black text-slate-400 mb-2">رسوم الأخوين معاً</label>
                      <input 
                        type="number" 
                        value={twoBrothersFees} 
                        onChange={e => setTwoBrothersFees(Number(e.target.value))} 
                        className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 font-bold text-slate-700" 
                        required 
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-black text-slate-400 mb-2">رسوم الثلاثة إخوة معاً</label>
                      <input 
                        type="number" 
                        value={threeBrothersFees} 
                        onChange={e => setThreeBrothersFees(Number(e.target.value))} 
                        className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 font-bold text-slate-700" 
                        required 
                      />
                    </div>
                  </motion.div>
                )}

                <div className="flex gap-4 pt-4 border-t border-slate-100">
                  <button 
                    type="button" 
                    onClick={() => setEditingSiblingFestival(null)} 
                    className="flex-1 py-3 font-bold text-slate-500 hover:bg-slate-50 rounded-xl transition"
                  >
                    إلغاء
                  </button>
                  <button 
                    onClick={async () => {
                      await updateFestivalSiblingPricing(editingSiblingFestival.id, siblingDiscountType, twoBrothersFees, threeBrothersFees);
                      setEditingSiblingFestival(null);
                    }}
                    className="flex-1 py-3 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-700 transition shadow-lg shadow-emerald-100"
                  >
                    حفظ التغييرات
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Participant Feedback Modal */}
      <AnimatePresence>
        {viewingFeedbackFestival && (() => {
          const stats = getFestivalEvaluationStats(viewingFeedbackFestival.id);
          return (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
              <motion.div 
                initial={{ scale: 0.9, opacity: 0 }} 
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="bg-white w-full max-w-lg p-8 rounded-[2.5rem] shadow-2xl overflow-y-auto max-h-[90vh]"
              >
                <div className="flex justify-between items-start mb-6 border-b border-slate-100 pb-4" dir="rtl">
                  <div className="text-right">
                    <h3 className="text-xl font-black text-slate-900 flex items-center gap-2">
                      <Star className="text-amber-500 fill-amber-500 animate-pulse" size={24} />
                      تقييمات رضا المشاركين
                    </h3>
                    <p className="text-xs text-slate-400 font-bold mt-1">مهرجان: {viewingFeedbackFestival.name}</p>
                  </div>
                  <button 
                    onClick={() => setViewingFeedbackFestival(null)} 
                    className="p-2 bg-slate-50 hover:bg-slate-100 rounded-xl text-slate-400 transition"
                  >
                    <X size={18} />
                  </button>
                </div>

                <div className="space-y-6 text-right" dir="rtl">
                  {stats ? (
                    <div className="bg-amber-50/60 p-5 rounded-2xl border border-amber-100 text-center space-y-2">
                      <p className="text-sm font-bold text-amber-800">الرضا العام عن المهرجان</p>
                      <div className="flex items-center justify-center gap-2">
                        <span className="text-4xl font-black text-amber-700">{stats.average}</span>
                        <span className="text-sm text-slate-400 font-bold">/ 5</span>
                      </div>
                      <div className="flex justify-center gap-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star 
                            key={`summary-star-${star}`} 
                            size={18} 
                            className={star <= Math.round(stats.average) ? 'fill-amber-400 text-amber-400' : 'text-slate-200'} 
                          />
                        ))}
                      </div>
                      <p className="text-xs text-slate-400 font-bold">إجمالي التقييمات المستلمة: {stats.count} تقييم</p>
                    </div>
                  ) : (
                    <div className="text-center py-8 bg-slate-50 rounded-2xl border border-slate-150">
                      <Star className="text-slate-300 mx-auto mb-3" size={36} />
                      <p className="text-sm text-slate-500 font-bold">لم يقم أحد من المشاركين بتقييم المهرجان حتى الآن.</p>
                    </div>
                  )}

                  {stats && stats.regs.length > 0 && (
                    <div className="space-y-4">
                      <h4 className="font-black text-slate-800 text-sm">ملاحظات ومقترحات المشاركين:</h4>
                      <div className="space-y-4 max-h-[300px] overflow-y-auto pr-1">
                        {stats.regs.map((r) => (
                          <div key={r.id} className="p-4 bg-slate-50 rounded-2xl border border-slate-100 space-y-2">
                            <div className="flex justify-between items-center">
                              <span className="text-xs font-black text-slate-900">{r.groomName}</span>
                              <div className="flex gap-0.5">
                                {[1, 2, 3, 4, 5].map((star) => (
                                  <Star 
                                    key={`reg-star-${r.id}-${star}`} 
                                    size={12} 
                                    className={star <= r.festivalEvaluation.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-200'} 
                                  />
                                ))}
                              </div>
                            </div>
                            {r.festivalEvaluation.comment ? (
                              <p className="text-xs text-slate-600 leading-relaxed italic font-semibold">"{r.festivalEvaluation.comment}"</p>
                            ) : (
                              <p className="text-[10px] text-slate-400 italic">تم التقييم بدون ترك تعليق مكتوب.</p>
                            )}
                            <span className="block text-[9px] text-slate-400 font-mono tracking-tight text-left">
                              {r.festivalEvaluation.createdAt ? new Date(r.festivalEvaluation.createdAt).toLocaleDateString('ar-SA') : ''}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </motion.div>
            </div>
          );
        })()}
      </AnimatePresence>
    </div>
  );
}
