import React from 'react';
import { MapPin, Phone, Calendar } from 'lucide-react';

interface Registration {
  id: string;
  festivalName: string;
  groomName: string;
  groomId: string;
  groomPhone: string;
  status: string;
  createdAt: any;
}

interface FullRegistrationsReportProps {
  registrations: Registration[];
}

const FullRegistrationsReport: React.FC<FullRegistrationsReportProps> = ({ registrations }) => {
  const today = new Date().toLocaleDateString('ar-SA');

  return (
    <div className="bg-white p-12 max-w-[210mm] mx-auto text-slate-900 font-sans leading-relaxed border-[12px] border-double border-slate-100 min-h-[297mm] relative overflow-hidden" dir="rtl">
      {/* Watermark */}
      <div className="absolute inset-0 flex items-center justify-center opacity-[0.03] pointer-events-none select-none rotate-[-45deg]">
        <h1 className="text-[100px] font-black">تقرير المتقدمين</h1>
      </div>

      {/* Header */}
      <div className="flex justify-between items-start mb-12 border-b-2 border-slate-900 pb-8 print-header">
        <div className="text-right space-y-1">
          <h2 className="text-xl font-black">المملكة العربية السعودية</h2>
          <h3 className="text-lg font-bold">وزارة الموارد البشرية والتنمية الاجتماعية</h3>
          <h4 className="text-md font-bold text-emerald-700">الجمعية الخيرية لتيسير الزواج ورعاية الأسرة</h4>
          <p className="text-xs font-bold text-slate-500">ترخيص رقم: (١٢٣٤)</p>
        </div>
        <div className="flex flex-col items-center">
          <img 
            src="https://www.reaayah.sa/rafed/uploads/system/cover_66ccddc5caa47.jpeg" 
            alt="Logo" 
            className="h-20 w-auto object-contain"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="text-left space-y-1">
          <p className="text-xs font-bold">التاريخ: {today}</p>
          <p className="text-xs font-bold">عدد المتقدمين: <span className="text-emerald-700">{registrations.length}</span></p>
        </div>
      </div>

      {/* Title */}
      <div className="text-center mb-12">
        <h1 className="text-3xl font-black text-slate-900 underline underline-offset-8 decoration-emerald-500">تقرير المتقدمين لمهرجانات الزواج الجماعي</h1>
        <p className="text-slate-500 font-bold mt-4">كشف تفصيلي ببيانات المتقدمين المسجلين في النظام</p>
      </div>

      {/* Table */}
      <div className="mb-12">
        <table className="w-full border-collapse border border-slate-300 text-sm">
          <thead>
            <tr className="bg-slate-100">
              <th className="border border-slate-300 p-3 font-black text-right w-10">#</th>
              <th className="border border-slate-300 p-3 font-black text-right">اسم المتقدم</th>
              <th className="border border-slate-300 p-3 font-black text-right">رقم الهوية</th>
              <th className="border border-slate-300 p-3 font-black text-right">رقم الجوال</th>
              <th className="border border-slate-300 p-3 font-black text-right">المهرجان</th>
              <th className="border border-slate-300 p-3 font-black text-right w-32">ملاحظات</th>
            </tr>
          </thead>
          <tbody>
            {registrations.map((r, index) => (
              <tr key={r.id || index} className="hover:bg-slate-50">
                <td className="border border-slate-300 p-3 font-bold text-center">{index + 1}</td>
                <td className="border border-slate-300 p-3 font-bold">{r.groomName}</td>
                <td className="border border-slate-300 p-3 font-bold">{r.groomId}</td>
                <td className="border border-slate-300 p-3 font-bold">{r.groomPhone}</td>
                <td className="border border-slate-300 p-3 font-bold">{r.festivalName}</td>
                <td className="border border-slate-300 p-3 text-slate-300 italic text-xs">........................</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Summary Section */}
      <div className="grid grid-cols-2 gap-8 mb-12">
        <div className="bg-slate-50 p-6 rounded-3xl border border-slate-200">
          <h5 className="text-md font-black mb-2 flex items-center gap-2 text-emerald-700">
            <Calendar size={18} /> إحصائيات سريعة
          </h5>
          <div className="space-y-2 text-sm font-bold">
            <p className="text-slate-600">إجمالي الطلبات: <span className="text-slate-900">{registrations.length}</span></p>
            <p className="text-slate-600">طلبات مقبولة: <span className="text-emerald-600">{registrations.filter(r => r.status === 'approved').length}</span></p>
            <p className="text-slate-600">طلبات قيد المراجعة والدراسة: <span className="text-amber-600">{registrations.filter(r => r.status === 'pending').length}</span></p>
          </div>
        </div>
        <div className="border border-slate-200 p-6 rounded-3xl flex flex-col justify-center items-center text-center">
          <p className="text-xs font-black text-slate-400 mb-4 uppercase tracking-widest">ختم الاعتماد الرسمي</p>
          <div className="h-24 w-24 border-4 border-double border-slate-200 rounded-full flex items-center justify-center">
            <div className="text-[6px] font-black text-slate-200 rotate-12">
              الجمعية الخيرية لتيسير الزواج<br />ختم الاعتماد
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="absolute bottom-12 left-12 right-12 border-t border-slate-200 pt-6 flex justify-between items-center text-[10px] font-bold text-slate-400 print-footer">
        <div className="flex items-center gap-2">
          <MapPin size={12} /> المملكة العربية السعودية - المنطقة الشرقية
        </div>
        <div className="flex items-center gap-2">
          <Phone size={12} /> الرقم الموحد: ٩٢٠٠٠٠٠٠٠
        </div>
        <div>تم استخراج التقرير آلياً من النظام</div>
      </div>

    </div>
  );
};

export default FullRegistrationsReport;
