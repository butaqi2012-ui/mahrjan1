import React, { useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Printer, X, CheckCircle, XCircle, Clock, AlertCircle, Eye, Download, CreditCard, FileText, Paperclip, ChevronLeft, ChevronRight, Maximize2 } from 'lucide-react';
import { doc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../../firebase';
import { notifyAdminsAndSupervisor } from '../../utils/notifications';

interface RegistrationDetailsProps {
  registration: any;
  onClose: () => void;
  onPrint: () => void;
  isPrinting: boolean;
  siteSettings: any;
}

export function RegistrationDetails({ registration, onClose, onPrint, isPrinting, siteSettings }: RegistrationDetailsProps) {
  const [isUpdating, setIsUpdating] = useState(false);
  const [paymentNote, setPaymentNote] = useState('');
  const [showRejectNote, setShowRejectNote] = useState(false);
  const [isEditingPayment, setIsEditingPayment] = useState(false);
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  if (!registration) return null;

  // Prepare images for Lightbox
  const galleryImages = [
    ...(registration.attachments || []).map((att: any, idx: number) => ({
      id: att.id || `att-${idx}`,
      url: att.url,
      type: att.type,
      label: idx === 0 ? 'هوية العريس' : idx === 1 ? 'بطاقة العائلة' : 'عقد النكاح'
    })),
    ...(registration.paymentReceipt ? [{
      id: 'receipt',
      url: registration.paymentReceipt.url,
      type: registration.paymentReceipt.type,
      label: 'إيصال السداد'
    }] : [])
  ].filter(img => !img.type?.includes('pdf'));

  const handleNext = () => {
    if (lightboxIndex !== null) {
      setLightboxIndex((lightboxIndex + 1) % galleryImages.length);
    }
  };

  const handlePrev = () => {
    if (lightboxIndex !== null) {
      setLightboxIndex((lightboxIndex - 1 + galleryImages.length) % galleryImages.length);
    }
  };

  const handlePaymentAction = async (action: 'approve' | 'reject' | 'reset') => {
    if (action === 'reject' && !paymentNote.trim()) {
      alert('يرجى كتابة سبب الرفض');
      return;
    }

    setIsUpdating(true);
    try {
      const docRef = doc(db, 'registrations', registration.id);
      let updateData: any = {
        updatedAt: serverTimestamp()
      };

      if (action === 'approve') {
        updateData.paymentStatus = 'paid';
        updateData.paymentNote = null;
      } else if (action === 'reject') {
        updateData.paymentStatus = 'rejected';
        updateData.paymentNote = paymentNote;
      } else if (action === 'reset') {
        updateData.paymentStatus = 'pending_verification';
        updateData.paymentNote = null;
      }
      
      await updateDoc(docRef, updateData);

      // Send notification to groom
      if (registration.groomPhone || registration.groomEmail) {
        let statusText = '';
        if (action === 'approve') statusText = 'تم قبول سداد الرسوم بنجاح';
        else if (action === 'reject') statusText = `تم رفض إيصال السداد: ${paymentNote}`;
        else statusText = 'تمت إعادة إيصال السداد للمراجعة';
        
        await notifyAdminsAndSupervisor(
          registration.festivalId,
          registration.festivalName,
          `تحديث سداد لـ ${registration.groomName}: ${statusText}`,
          'payment_update',
          registration.id
        );

        // Send Email notification
        if (siteSettings?.enableEmailNotifications && registration.groomEmail) {
          fetch('/api/send-email', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              to: registration.groomEmail,
              subject: `تحديث حالة السداد - مهرجان ${registration.festivalName}`,
              text: `مرحباً ${registration.groomName}،\n\nيود فريق تنظيم مهرجان ${registration.festivalName} إشعاركم بآخر تحديث لحالة سداد الرسوم الخاصة بكم:\n\nالحالة: ${statusText}.\n\nشكراً لكم.`
            })
          }).catch(err => console.error('Error sending Email:', err));
        }

        // Send SMS notification
        if (siteSettings?.enableSmsNotifications && registration.groomPhone) {
          fetch('/api/send-sms', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              to: registration.groomPhone.startsWith('0') ? '+966' + registration.groomPhone.substring(1) : registration.groomPhone,
              message: `مرحباً ${registration.groomName}، تحديث سداد في مهرجان ${registration.festivalName}: ${statusText}`
            })
          }).catch(err => console.error('Error sending SMS:', err));
        }
      }

      alert(
        action === 'approve' ? 'تم قبول السداد بنجاح' : 
        action === 'reject' ? 'تم رفض السداد' : 
        'تمت إعادة الطلب للمراجعة'
      );
      setIsEditingPayment(false);
      setShowRejectNote(false);
      onClose();
    } catch (error) {
      console.error('Error updating payment status:', error);
      alert('حدث خطأ أثناء تحديث الحالة');
    } finally {
      setIsUpdating(false);
    }
  };

  return (
    <div className="bg-white w-full h-full rounded-3xl shadow-lg border border-slate-100 overflow-hidden flex flex-col">
      <div className="p-6 border-b border-slate-100 flex justify-between items-center">
        <h3 className="text-xl font-black text-slate-900">تفاصيل الطلب</h3>
        <div className="flex gap-2">
          <button 
            onClick={onPrint} 
            disabled={isPrinting}
            className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 transition font-black text-xs disabled:opacity-50"
          >
            {isPrinting ? 'جاري التجهيز...' : <><Printer size={16} /> طباعة</>}
          </button>
          <button onClick={onClose} className="p-2 bg-slate-100 text-slate-600 rounded-xl hover:bg-slate-200 transition">
            <X size={16} />
          </button>
        </div>
      </div>
      
      <div className="p-6 overflow-y-auto flex-grow">
        <div className="space-y-6" dir="rtl">
          <div className="text-center border-b pb-6 mb-6">
            <h2 className="text-3xl font-black mb-1">استمارة تسجيل زواج جماعي</h2>
            <p className="text-slate-500 font-bold text-base">{registration.festivalName}</p>
          </div>
          
          <div className="grid grid-cols-1 gap-6">
            <div className="space-y-4">
              <h4 className="font-black text-xl text-slate-900 border-b pb-2">بيانات العريس</h4>
              <Detail label="الاسم الرباعي" value={registration.groomName} />
              <Detail label="رقم الهوية" value={registration.groomId} />
              <Detail label="رقم الجوال" value={registration.groomPhone} />
              <Detail label="صلة قرابة الممثل" value={registration.groomGuardianRelation} />
              <Detail label="اسم ممثل العريس" value={registration.groomGuardianName} />
              <Detail label="جوال ممثل العريس" value={registration.groomGuardianPhone} />
              <Detail label="مبلغ المهر" value={registration.mahrAmount} />
            </div>
            
            <div className="space-y-4">
              <h4 className="font-black text-xl text-slate-900 border-b pb-2">بيانات اجتماعية وصحية</h4>
              <Detail label="المؤهل الدراسي" value={registration.qualification} />
              <Detail label="الحالة الوظيفية" value={registration.employmentStatus} />
              {registration.employmentStatus === 'موظف' && (
                <>
                  <Detail label="قطاع التوظيف" value={registration.employmentSector} />
                  <Detail label="الراتب كاملاً مع البدلات" value={registration.salary} />
                </>
              )}
              <Detail label="نوع السكن" value={registration.housingType} />
              <Detail label="نوع التملك" value={registration.ownershipType} />
              {registration.ownershipType === 'إيجار' && (
                <Detail label="مبلغ الإيجار السنوي" value={registration.rentAmount} />
              )}
              <Detail label="الحالة الصحية" value={registration.healthStatus} />
              {registration.healthStatus !== 'سليم' && (
                <Detail label="نوع الإعاقة أو المرض" value={registration.disabilityType} />
              )}
            </div>
            
            <div className="space-y-4">
              <h4 className="font-black text-xl text-slate-900 border-b pb-2">بيانات العروس</h4>
              <Detail label="الاسم الرباعي" value={registration.brideName} />
              <Detail label="رقم الهوية" value={registration.brideId} />
              <Detail label="رقم الجوال" value={registration.bridePhone} />
              <Detail label="صلة قرابة الممثل" value={registration.guardianRelation} />
              <Detail label="اسم ممثل العروس" value={registration.guardianName} />
              <Detail label="جوال ممثل العروس" value={registration.guardianPhone} />
            </div>
            
            {/* General Attachments Section */}
            <div className="space-y-4 pt-6 border-t">
              <h4 className="font-black text-lg text-slate-900 flex items-center gap-2">
                <Paperclip size={20} className="text-emerald-600" />
                المرفقات الثبوتية
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {registration.attachments?.map((att: any, index: number) => (
                  <div key={att.id || `att-${index}`} className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
                    <p className="text-xs font-black text-slate-500 mb-2 truncate">
                      {index === 0 ? 'هوية العريس' : index === 1 ? 'بطاقة العائلة' : 'عقد النكاح'}
                    </p>
                    <div className="relative group aspect-square rounded-xl overflow-hidden border-2 border-white shadow-sm bg-slate-200">
                      {att.type?.includes('pdf') ? (
                        <div className="w-full h-full flex flex-col items-center justify-center bg-white">
                          <FileText size={32} className="text-emerald-500 mb-2" />
                          <a href={att.url} target="_blank" rel="noopener noreferrer" className="text-[10px] font-black text-emerald-600 underline">فتح PDF</a>
                        </div>
                      ) : (
                        <>
                          <img src={att.url} alt="attachment" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                            <button 
                              onClick={() => {
                                const idx = galleryImages.findIndex(img => img.url === att.url);
                                if (idx !== -1) setLightboxIndex(idx);
                              }} 
                              className="p-2 bg-white text-slate-900 rounded-lg hover:scale-110 transition shadow-lg"
                            >
                              <Eye size={16} />
                            </button>
                            <a href={att.url} download className="p-2 bg-white text-slate-900 rounded-lg hover:scale-110 transition shadow-lg">
                              <Download size={16} />
                            </a>
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Payment Verification Section */}
              <div className="space-y-4 pt-6 border-t">
                <h4 className="font-black text-lg text-slate-900 flex items-center gap-2">
                  <CreditCard size={20} className="text-emerald-600" />
                  تحقق من سداد الرسوم
                </h4>

                {registration.paymentReceipt ? (
                  <div className="space-y-5">
                    <div className="bg-slate-50 p-6 rounded-3xl border border-slate-200">
                      <div className="flex justify-between items-center mb-4">
                        <div>
                          <p className="text-xs font-black text-slate-900">إيصال السداد المرفق</p>
                          <p className="text-[10px] font-bold text-slate-500">تم الرفع في: {registration.updatedAt?.toDate ? new Date(registration.updatedAt.toDate()).toLocaleString('ar-SA') : '---'}</p>
                        </div>
                        <div className="flex gap-2">
                          <a href={registration.paymentReceipt.url} download target="_blank" rel="noopener noreferrer" className="p-2 bg-white text-slate-600 rounded-xl border border-slate-100 hover:bg-slate-50 transition shadow-sm">
                            <Download size={18} />
                          </a>
                        </div>
                      </div>
                      
                      <div className="relative group rounded-2xl overflow-hidden border-4 border-white shadow-xl bg-slate-200 transition-all hover:scale-[1.01]">
                        {registration.paymentReceipt.type?.includes('pdf') ? (
                          <div className="aspect-video w-full flex flex-col items-center justify-center bg-white">
                            <FileText size={64} className="text-emerald-500 mb-4" />
                            <p className="text-sm font-black text-slate-600 mb-6">{registration.paymentReceipt.name}</p>
                            <a 
                              href={registration.paymentReceipt.url} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="px-6 py-3 bg-emerald-600 text-white rounded-2xl font-black text-sm hover:bg-emerald-700 transition"
                            >
                              عرض ملف PDF في نافذة جديدة
                            </a>
                          </div>
                        ) : (
                          <>
                            <img 
                              src={registration.paymentReceipt.url} 
                              alt="payment receipt" 
                              className="w-full object-contain max-h-[500px]"
                              referrerPolicy="no-referrer"
                            />
                            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
                              <button 
                                onClick={() => {
                                  const idx = galleryImages.findIndex(img => img.url === registration.paymentReceipt.url);
                                  if (idx !== -1) setLightboxIndex(idx);
                                }}
                                className="p-4 bg-white/20 backdrop-blur-md text-white rounded-full hover:bg-white/30 hover:scale-110 transition shadow-2xl"
                                title="عرض بملئ الشاشة"
                              >
                                <Maximize2 size={32} />
                              </button>
                            </div>
                          </>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100">
                      <div className="space-y-0.5">
                        <span className="text-sm font-black text-slate-700 block">حالة السداد الحالية:</span>
                        {registration.paymentNote && registration.paymentStatus === 'rejected' && (
                          <span className="text-[10px] font-bold text-red-500 block max-w-[200px] truncate">{registration.paymentNote}</span>
                        )}
                      </div>
                      <div className="flex items-center gap-3">
                        <div className={`flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-black ${
                          registration.paymentStatus === 'paid' ? 'bg-emerald-100 text-emerald-700' :
                          registration.paymentStatus === 'rejected' ? 'bg-red-100 text-red-700' :
                          registration.paymentStatus === 'pending_verification' ? 'bg-amber-100 text-amber-700' :
                          'bg-slate-200 text-slate-600'
                        }`}>
                          {registration.paymentStatus === 'paid' ? <CheckCircle size={14} /> :
                           registration.paymentStatus === 'rejected' ? <XCircle size={14} /> :
                           <Clock size={14} />}
                          {registration.paymentStatus === 'paid' ? 'مقبول' :
                           registration.paymentStatus === 'rejected' ? 'مرفوض' :
                           registration.paymentStatus === 'pending_verification' ? 'قيد التحقق' :
                           'بانتظار السداد'}
                        </div>
                        
                        {(registration.paymentStatus === 'paid' || registration.paymentStatus === 'rejected') && !isEditingPayment && (
                          <button 
                            onClick={() => setIsEditingPayment(true)}
                            className="p-2 text-slate-400 hover:text-emerald-600 transition"
                            title="تعديل الحالة"
                          >
                            <Printer size={14} className="rotate-90" /> {/* Using printer as a placeholder for settings-like icon if needed, or lucide has more */}
                            <span className="text-[10px] font-black underline mr-1">تعديل</span>
                          </button>
                        )}
                      </div>
                    </div>

                    {(registration.paymentStatus === 'pending_verification' || isEditingPayment) && (
                      <div className="space-y-4 pt-2">
                        {!showRejectNote ? (
                          <div className="space-y-3">
                            <div className="grid grid-cols-2 gap-4">
                              <button
                                onClick={() => handlePaymentAction('approve')}
                                disabled={isUpdating}
                                className="flex items-center justify-center gap-3 py-4 bg-emerald-600 text-white rounded-2xl font-black text-sm hover:bg-emerald-700 transition shadow-lg shadow-emerald-100 disabled:opacity-50"
                              >
                                <CheckCircle size={20} />
                                {registration.paymentStatus === 'paid' ? 'تأكيد القبول' : 'قبول السداد'}
                              </button>
                              <button
                                onClick={() => setShowRejectNote(true)}
                                disabled={isUpdating}
                                className="flex items-center justify-center gap-3 py-4 bg-red-50 text-red-600 rounded-2xl font-black text-sm hover:bg-red-100 transition disabled:opacity-50"
                              >
                                <XCircle size={20} />
                                {registration.paymentStatus === 'rejected' ? 'تعديل سبب الرفض' : 'رفض السداد'}
                              </button>
                            </div>
                            
                            {isEditingPayment && (
                              <div className="flex gap-2">
                                <button
                                  onClick={() => handlePaymentAction('reset')}
                                  disabled={isUpdating}
                                  className="flex-1 py-3 bg-slate-100 text-slate-600 rounded-xl font-black text-[10px] hover:bg-slate-200 transition"
                                >
                                  إعادة كطلب جديد (تحت المراجعة)
                                </button>
                                <button
                                  onClick={() => setIsEditingPayment(false)}
                                  className="px-4 py-3 bg-white border border-slate-200 text-slate-400 rounded-xl font-black text-[10px] hover:bg-slate-50 transition"
                                >
                                  إلغاء التعديل
                                </button>
                              </div>
                            )}
                          </div>
                        ) : (
                          <motion.div 
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="bg-red-50 p-6 rounded-3xl border-2 border-red-100 space-y-4"
                          >
                            <div className="flex items-center gap-2 text-red-700 mb-2">
                              <AlertCircle size={20} />
                              <h5 className="font-black">توضيح سبب رفض السداد</h5>
                            </div>
                            <textarea
                              value={paymentNote}
                              onChange={(e) => setPaymentNote(e.target.value)}
                              placeholder="مثلاً: الإيصال غير واضح، المبلغ ناقص، الحوالة لم تصل بحسابنا..."
                              className="w-full p-4 bg-white border border-red-200 rounded-2xl text-sm font-bold focus:ring-2 focus:ring-red-500 outline-none min-h-[100px] shadow-sm"
                            />
                            <div className="grid grid-cols-2 gap-4">
                              <button
                                onClick={() => handlePaymentAction('reject')}
                                disabled={isUpdating}
                                className="py-3 bg-red-600 text-white rounded-xl font-black text-sm hover:bg-red-700 transition shadow-lg shadow-red-100"
                              >
                                تأكيد الرفض
                              </button>
                              <button
                                onClick={() => setShowRejectNote(false)}
                                className="py-3 bg-white text-slate-600 border border-slate-200 rounded-xl font-black text-sm hover:bg-slate-50 transition"
                              >
                                تراجع
                              </button>
                            </div>
                          </motion.div>
                        )}
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="py-12 bg-slate-50 rounded-3xl border-2 border-dashed border-slate-200 text-center">
                    <Clock size={48} className="mx-auto text-slate-300 mb-4" />
                    <h5 className="text-slate-900 font-black mb-1">في انتظار السداد</h5>
                    <p className="text-slate-400 font-bold text-xs max-w-xs mx-auto">
                      {['pending', 'rejected', 'needs_info'].includes(registration.status) ? 'يجب تدقيق بيانات الطلب أولاً قبل توجيه العريس للسداد' : 'بانتظار قيام العريس برفع إيصال السداد للمراجعة'}
                    </p>
                  </div>
                )}
              </div>
          </div>
        </div>
      </div>

      {/* Lightbox Overlay */}
      <AnimatePresence>
        {lightboxIndex !== null && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[200] bg-slate-950/95 backdrop-blur-xl flex flex-col p-4 sm:p-8"
          >
            {/* Toolbar */}
            <div className="flex items-center justify-between mb-4 sm:mb-8 bg-white/5 p-4 rounded-2xl border border-white/10">
              <div className="flex flex-col">
                <span className="text-white font-black text-xl">{galleryImages[lightboxIndex].label}</span>
                <span className="text-white/40 text-[10px] font-bold">صورة {lightboxIndex + 1} من {galleryImages.length}</span>
              </div>
              <div className="flex items-center gap-3">
                <a 
                  href={galleryImages[lightboxIndex].url} 
                  download 
                  className="p-3 bg-white/10 text-white rounded-xl hover:bg-white/20 transition-all border border-white/10"
                >
                  <Download size={20} />
                </a>
                <button 
                  onClick={() => setLightboxIndex(null)}
                  className="p-3 bg-red-500/20 text-red-500 rounded-xl hover:bg-red-500 hover:text-white transition-all border border-red-500/20"
                >
                  <X size={20} />
                </button>
              </div>
            </div>

            {/* Main Stage */}
            <div className="flex-1 relative flex items-center justify-center overflow-hidden">
              <AnimatePresence mode="wait">
                <motion.img
                  key={galleryImages[lightboxIndex].url}
                  src={galleryImages[lightboxIndex].url}
                  initial={{ opacity: 0, scale: 0.9, y: 20 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 1.1, y: -20 }}
                  transition={{ type: 'spring', damping: 25, stiffness: 200 }}
                  className="max-w-full max-h-full object-contain shadow-2xl rounded-lg"
                  referrerPolicy="no-referrer"
                />
              </AnimatePresence>

              {/* Navigation Controls */}
              {galleryImages.length > 1 && (
                <>
                  <button 
                    onClick={(e) => { e.stopPropagation(); handlePrev(); }}
                    className="absolute right-4 sm:-right-4 top-1/2 -translate-y-1/2 p-4 sm:p-6 bg-white/10 text-white rounded-3xl border border-white/10 hover:bg-white hover:text-slate-900 transition-all shadow-2xl backdrop-blur-md z-10"
                  >
                    <ChevronRight size={32} />
                  </button>
                  <button 
                    onClick={(e) => { e.stopPropagation(); handleNext(); }}
                    className="absolute left-4 sm:-left-4 top-1/2 -translate-y-1/2 p-4 sm:p-6 bg-white/10 text-white rounded-3xl border border-white/10 hover:bg-white hover:text-slate-900 transition-all shadow-2xl backdrop-blur-md z-10"
                  >
                    <ChevronLeft size={32} />
                  </button>
                </>
              )}
            </div>

            {/* Thumbnails */}
            <div className="mt-8 flex justify-center gap-3 overflow-x-auto pb-4 scrollbar-hide">
              {galleryImages.map((img, idx) => (
                <button
                  key={`thumb-${img.id}`}
                  onClick={() => setLightboxIndex(idx)}
                  className={`relative w-16 h-16 rounded-xl overflow-hidden border-2 transition-all shrink-0 ${lightboxIndex === idx ? 'border-brand-500 scale-110 shadow-lg shadow-brand-500/20' : 'border-white/10 grayscale opacity-50 hover:opacity-100 hover:grayscale-0'}`}
                >
                  <img src={img.url} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function Detail({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between items-center bg-slate-50 p-3 rounded-lg">
      <span className="text-xs font-bold text-slate-500">{label}</span>
      <span className="text-xs font-black text-slate-900">{value}</span>
    </div>
  );
}
