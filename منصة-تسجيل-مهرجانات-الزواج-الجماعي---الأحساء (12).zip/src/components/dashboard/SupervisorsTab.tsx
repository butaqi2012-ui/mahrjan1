import React from 'react';
import { Plus, User, Edit, Trash2, Lock, Shield, UserCog, Briefcase, Mail, Phone, Calendar } from 'lucide-react';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../../firebase';

interface SupervisorsTabProps {
  supervisors: any[];
  festivals: any[];
  setShowAddSupervisor: (show: boolean) => void;
  setEditingSupervisor: (supervisor: any) => void;
  setDeleteConfirm: (confirm: { id: string, type: 'festival' | 'supervisor' | 'testimonial' } | null) => void;
}

export function SupervisorsTab({
  supervisors,
  festivals,
  setShowAddSupervisor,
  setEditingSupervisor,
  setDeleteConfirm
}: SupervisorsTabProps) {
  // Sort supervisors so admin comes first
  const sortedSupervisors = [...supervisors].sort((a, b) => {
    if (a.role === 'admin' && b.role !== 'admin') return -1;
    if (a.role !== 'admin' && b.role === 'admin') return 1;
    return 0;
  });

  return (
    <div className="p-4 sm:p-8">
      <div className="bg-white dark:bg-slate-800 p-6 sm:p-8 rounded-3xl shadow-sm border border-slate-100 dark:border-slate-700 mb-8 flex flex-col sm:flex-row sm:justify-between sm:items-center gap-6">
        <div>
          <h3 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white mb-2">إدارة المشرفين</h3>
          <p className="text-slate-500 dark:text-slate-400 font-bold text-sm">أضف، عدل، وعين الصلاحيات والمهرجانات لمشرفي النظام</p>
        </div>
        <button onClick={() => setShowAddSupervisor(true)} className="bg-emerald-600 text-white px-6 py-3.5 rounded-2xl font-black text-sm sm:text-base flex items-center justify-center gap-2 hover:bg-emerald-700 hover:scale-[1.02] active:scale-[0.98] transition-all shadow-xl shadow-emerald-200 dark:shadow-none">
          <Plus size={18} /> 
          إضافة مشرف جديد
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
        {sortedSupervisors.map((s, index) => {
          const isAdmin = s.role === 'admin';
          return (
            <div 
              key={s.id} 
              className={`relative overflow-hidden rounded-3xl p-5 sm:p-6 transition-all duration-300 ${
                isAdmin 
                  ? 'bg-gradient-to-br from-indigo-900 to-indigo-800 text-white shadow-xl shadow-indigo-900/20 border-0' 
                  : 'bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 shadow-sm hover:shadow-md'
              }`}
            >
              {/* Card Number */}
              <div className={`absolute top-0 right-0 w-8 h-8 flex items-center justify-center rounded-bl-2xl font-black text-xs ${
                isAdmin ? 'bg-white/10 text-white' : 'bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400'
              }`}>
                {index + 1}
              </div>

              {isAdmin && (
                <div className="absolute -top-6 -right-6 opacity-5 pointer-events-none">
                  <Shield size={100} />
                </div>
              )}
              
              <div className="flex justify-between items-start mb-4 relative z-10 mt-2">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-inner ${
                  isAdmin ? 'bg-white/10 text-indigo-300' : 'bg-emerald-50 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400'
                }`}>
                  {isAdmin ? <Shield size={24} /> : <UserCog size={24} />}
                </div>
                <div className="flex gap-2">
                  <button onClick={() => setEditingSupervisor(s)} className={`p-1.5 sm:p-2 rounded-xl transition-colors ${isAdmin ? 'bg-white/5 hover:bg-white/20 text-indigo-200' : 'bg-slate-50 dark:bg-slate-700 hover:bg-emerald-50 dark:hover:bg-emerald-900/50 text-slate-400 hover:text-emerald-600 dark:hover:text-emerald-400'}`}>
                    <Edit size={16} />
                  </button>
                  {!isAdmin && (
                    <button onClick={() => setDeleteConfirm({ id: s.id, type: 'supervisor' })} className="p-1.5 sm:p-2 rounded-xl bg-slate-50 dark:bg-slate-700 hover:bg-red-50 dark:hover:bg-red-900/50 text-slate-400 hover:text-red-600 dark:hover:text-red-400 transition-colors">
                      <Trash2 size={16} />
                    </button>
                  )}
                </div>
              </div>

              <div className="mb-4 relative z-10">
                <h4 className={`font-black text-lg sm:text-xl mb-3 truncate ${isAdmin ? 'text-white' : 'text-slate-900 dark:text-white'}`}>
                  {s.displayName || s.email}
                </h4>
                
                <div className="space-y-2.5">
                  {s.displayName && (
                    <div className="flex items-center gap-3">
                      <Mail size={14} className={isAdmin ? 'text-indigo-300' : 'text-slate-400 shrink-0'} />
                      <p className={`text-xs sm:text-sm font-bold truncate ${isAdmin ? 'text-indigo-200' : 'text-slate-500 dark:text-slate-400'}`}>{s.email}</p>
                    </div>
                  )}
                  {s.phone && (
                    <div className="flex items-center gap-3">
                      <Phone size={14} className={isAdmin ? 'text-indigo-300' : 'text-slate-400 shrink-0'} />
                      <p className={`text-xs sm:text-sm font-bold truncate ${isAdmin ? 'text-indigo-200' : 'text-slate-500 dark:text-slate-400'}`}>{s.phone}</p>
                    </div>
                  )}
                  {s.password && (
                    <div className="flex items-center gap-3">
                      <Lock size={14} className={isAdmin ? 'text-indigo-300' : 'text-slate-400 shrink-0'} />
                      <p className={`text-xs sm:text-sm font-mono font-bold ${isAdmin ? 'text-indigo-200' : 'text-slate-500 dark:text-slate-400'}`}>{s.password}</p>
                    </div>
                  )}
                </div>
              </div>

              <div className={`pt-4 border-t relative z-10 space-y-3 ${isAdmin ? 'border-white/10' : 'border-slate-100 dark:border-slate-700'}`}>
                <div className="space-y-1.5">
                  <label className={`text-[10px] sm:text-xs font-black uppercase tracking-wider ${isAdmin ? 'text-indigo-300' : 'text-slate-400'}`}>الصلاحية</label>
                  <select 
                    value={s.role} 
                    onChange={async (e) => await updateDoc(doc(db, 'users', s.id), { role: e.target.value })}
                    className={`w-full rounded-xl text-xs sm:text-sm font-black focus:ring-2 focus:ring-emerald-500 transition-colors py-2 ${
                      isAdmin 
                        ? 'bg-white/10 border-transparent text-white [&>option]:text-slate-900' 
                        : 'bg-slate-50 dark:bg-slate-800 border-transparent text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <option value="supervisor">مشرف مهرجان</option>
                    <option value="admin">مدير نظام</option>
                  </select>
                </div>

                {!isAdmin && (
                  <div className="space-y-1.5">
                    <label className="text-[10px] sm:text-xs font-black uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                      <Calendar size={12} /> تعيين مهرجان
                    </label>
                    <select 
                      value={s.assignedFestivalId || ''} 
                      onChange={async (e) => await updateDoc(doc(db, 'users', s.id), { assignedFestivalId: e.target.value })}
                      className="w-full bg-slate-50 dark:bg-slate-800 border-transparent rounded-xl text-xs sm:text-sm font-black text-slate-700 dark:text-slate-300 focus:ring-2 focus:ring-emerald-500 transition-colors py-2"
                    >
                      <option value="">اختر المهرجان...</option>
                      {festivals.map((f, index) => (
                        <option key={f.id} value={f.id}>{index + 1} - {f.name}</option>
                      ))}
                    </select>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
