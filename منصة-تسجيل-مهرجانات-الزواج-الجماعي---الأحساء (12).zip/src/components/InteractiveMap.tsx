import React, { useState, useCallback } from 'react';
import { GoogleMap, useJsApiLoader, Marker, Autocomplete } from '@react-google-maps/api';
import { X, MapPin } from 'lucide-react';

const containerStyle = {
  width: '100%',
  height: '400px'
};

const center = {
  lat: 24.7136, // Riyadh
  lng: 46.6753
};

interface InteractiveMapProps {
  initialLocation?: { lat: number; lng: number };
  onLocationSelect: (location: { lat: number; lng: number; address: string }) => void;
}

export function InteractiveMap({ initialLocation, onLocationSelect }: InteractiveMapProps) {
  const { isLoaded } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '',
    libraries: ['places']
  });

  const [marker, setMarker] = useState(initialLocation || center);
  const [map, setMap] = useState<google.maps.Map | null>(null);
  const [autocomplete, setAutocomplete] = useState<google.maps.places.Autocomplete | null>(null);

  const onLoad = useCallback(function callback(map: google.maps.Map) {
    setMap(map);
  }, []);

  const onUnmount = useCallback(function callback(map: google.maps.Map) {
    setMap(null);
  }, []);

  const onMapClick = useCallback((e: google.maps.MapMouseEvent) => {
    if (e.latLng) {
      const newPos = { lat: e.latLng.lat(), lng: e.latLng.lng() };
      setMarker(newPos);
      
      // Reverse geocode
      const geocoder = new google.maps.Geocoder();
      geocoder.geocode({ location: newPos }, (results, status) => {
        if (status === 'OK' && results?.[0]) {
          onLocationSelect({ ...newPos, address: results[0].formatted_address });
        }
      });
    }
  }, [onLocationSelect]);

  const onPlaceChanged = () => {
    if (autocomplete !== null) {
      const place = autocomplete.getPlace();
      if (place.geometry && place.geometry.location) {
        const newPos = {
          lat: place.geometry.location.lat(),
          lng: place.geometry.location.lng()
        };
        setMarker(newPos);
        map?.panTo(newPos);
        onLocationSelect({ ...newPos, address: place.formatted_address || '' });
      }
    }
  };

  const onAutocompleteLoad = (autocomplete: google.maps.places.Autocomplete) => {
    setAutocomplete(autocomplete);
  };

  return isLoaded ? (
    <div className="space-y-4">
      <Autocomplete onLoad={onAutocompleteLoad} onPlaceChanged={onPlaceChanged}>
        <div className="relative">
          <MapPin className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input
            type="text"
            placeholder="ابحث عن موقع..."
            className="w-full pr-12 pl-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 transition-all font-bold text-sm"
          />
        </div>
      </Autocomplete>
      <div className="rounded-2xl overflow-hidden border border-slate-200 shadow-inner">
        <GoogleMap
          mapContainerStyle={containerStyle}
          center={marker}
          zoom={12}
          onClick={onMapClick}
          onLoad={onLoad}
          onUnmount={onUnmount}
          options={{
            streetViewControl: false,
            mapTypeControl: false,
            fullscreenControl: false,
          }}
        >
          <Marker position={marker} />
        </GoogleMap>
      </div>
      <p className="text-[10px] text-slate-400 font-bold text-center italic">يمكنك النقر على الخريطة لتحديد الموقع بدقة</p>
    </div>
  ) : <div className="h-[400px] bg-slate-100 rounded-2xl animate-pulse flex items-center justify-center text-slate-400 font-bold">جاري تحميل الخريطة...</div>;
}

interface MapViewProps {
  locations: { id: string; name: string; lat: number; lng: number; address: string }[];
  height?: string;
}

export function MapView({ locations, height = '400px' }: MapViewProps) {
  const { isLoaded } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '',
  });

  const [selected, setSelected] = useState<any>(null);

  const mapCenter = locations.length > 0 
    ? { lat: locations[0].lat, lng: locations[0].lng } 
    : center;

  return isLoaded ? (
    <div className="relative rounded-3xl overflow-hidden border border-slate-200 shadow-xl">
      <GoogleMap
        mapContainerStyle={{ width: '100%', height }}
        center={mapCenter}
        zoom={locations.length > 1 ? 6 : 10}
        options={{
          streetViewControl: false,
          mapTypeControl: false,
          fullscreenControl: true,
        }}
      >
        {locations.map(loc => (
          <Marker 
            key={loc.id} 
            position={{ lat: loc.lat, lng: loc.lng }} 
            onClick={() => setSelected(loc)}
            title={loc.name}
          />
        ))}
      </GoogleMap>
      
      {selected && (
        <div className="absolute bottom-6 left-6 right-6 bg-white/95 backdrop-blur-md p-6 rounded-[2rem] shadow-2xl border border-white/20 z-10 animate-in fade-in slide-in-from-bottom-4 duration-300">
          <div className="flex justify-between items-start">
            <div className="flex gap-4">
              <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-2xl flex items-center justify-center shrink-0">
                <MapPin size={24} />
              </div>
              <div>
                <h4 className="font-black text-slate-900 text-lg">{selected.name}</h4>
                <p className="text-xs text-slate-500 font-bold leading-relaxed">{selected.address}</p>
                <a 
                  href={`https://www.google.com/maps/dir/?api=1&destination=${selected.lat},${selected.lng}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-block mt-3 text-emerald-600 text-[10px] font-black hover:underline"
                >
                  الحصول على الاتجاهات
                </a>
              </div>
            </div>
            <button 
              onClick={() => setSelected(null)} 
              className="p-2 bg-slate-100 text-slate-400 rounded-xl hover:bg-slate-200 transition"
            >
              <X size={16} />
            </button>
          </div>
        </div>
      )}
    </div>
  ) : <div style={{ height }} className="bg-slate-100 rounded-3xl animate-pulse flex items-center justify-center text-slate-400 font-bold">جاري تحميل الخريطة...</div>;
}
