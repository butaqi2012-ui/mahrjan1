import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, updateDoc, doc } from 'firebase/firestore';
import { db } from '../firebase';
import { Task } from '../App';
import { format } from 'date-fns';

export const SupervisorTasksDashboard = ({ supervisorId }: { supervisorId: string }) => {
  const [tasks, setTasks] = useState<Task[]>([]);

  useEffect(() => {
    const q = query(collection(db, 'tasks'), where('assignedTo', '==', supervisorId));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const tasksData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Task));
      setTasks(tasksData);
    });
    return () => unsubscribe();
  }, [supervisorId]);

  const updateTaskStatus = async (taskId: string, status: 'pending' | 'in-progress' | 'completed') => {
    await updateDoc(doc(db, 'tasks', taskId), { status, updatedAt: new Date() });
  };

  const isOverdue = (dueDate: any) => {
    if (!dueDate) return false;
    const date = dueDate.toDate ? dueDate.toDate() : new Date(dueDate);
    return date < new Date() && status !== 'completed';
  };

  return (
    <div className="p-4 bg-slate-50 rounded-xl">
      <h2 className="text-xl font-bold mb-4">المهام المسندة إلي</h2>
      <div className="grid gap-4">
        {tasks.map(task => (
          <div key={task.id} className={`p-4 bg-white rounded-lg shadow ${isOverdue(task.dueDate) ? 'border-2 border-red-500' : ''}`}>
            <h3 className="font-bold">{task.title}</h3>
            <p className="text-sm text-slate-600">{task.description}</p>
            <p className="text-xs text-slate-400 mt-2">تاريخ الاستحقاق: {task.dueDate ? format(task.dueDate.toDate ? task.dueDate.toDate() : new Date(task.dueDate), 'yyyy-MM-dd') : 'غير محدد'}</p>
            <div className="mt-4 flex items-center gap-2">
              <span className="text-sm">الحالة:</span>
              <select 
                value={task.status} 
                onChange={(e) => updateTaskStatus(task.id, e.target.value as any)}
                className="border rounded p-1 text-sm"
              >
                <option value="pending">معلقة</option>
                <option value="in-progress">قيد التنفيذ</option>
                <option value="completed">مكتملة</option>
              </select>
            </div>
            {isOverdue(task.dueDate) && <p className="text-red-500 text-xs mt-2 font-bold">تنبيه: المهمة متأخرة!</p>}
          </div>
        ))}
      </div>
    </div>
  );
};
