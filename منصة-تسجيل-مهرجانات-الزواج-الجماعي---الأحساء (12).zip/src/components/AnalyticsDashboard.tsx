import React, { useState, useMemo } from 'react';
import { motion } from 'motion/react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, 
  PieChart, Pie, Cell, LineChart, Line, AreaChart, Area
} from 'recharts';
import { format, parseISO, startOfMonth, endOfMonth, eachDayOfInterval, eachMonthOfInterval, startOfYear, endOfYear, isSameMonth, isSameDay } from 'date-fns';
import { arSA } from 'date-fns/locale';
import { Users, CheckCircle, Clock, XCircle, TrendingUp, Calendar as CalendarIcon, PieChart as PieChartIcon, BarChart as BarChartIcon, Star } from 'lucide-react';

interface AnalyticsDashboardProps {
  registrations: any[];
  festivals: any[];
}

const STATUS_COLORS = ['#10b981', '#ef4444', '#f59e0b', '#3b82f6'];
const FESTIVAL_COLORS = ['#3b82f6', '#8b5cf6', '#ec4899', '#14b8a6', '#f97316', '#6366f1', '#84cc16', '#eab308'];

export function AnalyticsDashboard({ registrations, festivals }: AnalyticsDashboardProps) {
  const [timeframe, setTimeframe] = useState<'daily' | 'monthly'>('daily');

  // 1. Summary Stats
  const stats = useMemo(() => {
    return {
      total: registrations.length,
      approved: registrations.filter(r => r.status === 'approved').length,
      pending: registrations.filter(r => r.status === 'pending').length,
      rejected: registrations.filter(r => r.status === 'rejected').length,
      needsInfo: registrations.filter(r => r.status === 'needs_info').length,
    };
  }, [registrations]);

  // 2. Time Series Data (Daily/Monthly)
  const timeSeriesData = useMemo(() => {
    if (registrations.length === 0) return [];

    const processedRegs = registrations.map(r => ({
      ...r,
      date: r.createdAt?.toDate ? r.createdAt.toDate() : new Date(r.createdAt)
    })).filter(r => !isNaN(r.date.getTime()));

    if (processedRegs.length === 0) return [];

    const dates = processedRegs.map(r => r.date).sort((a, b) => a.getTime() - b.getTime());
    const startDate = dates[0];
    const endDate = new Date();

    if (timeframe === 'daily') {
      const start = new Date(endDate);
      start.setDate(start.getDate() - 30);
      const actualStart = startDate > start ? startDate : start;
      const days = eachDayOfInterval({ start: actualStart, end: endDate });
      
      return days.map(day => {
        const dayRegs = processedRegs.filter(r => isSameDay(r.date, day));
        return {
          date: format(day, 'dd MMM', { locale: arSA }),
          total: dayRegs.length,
          approved: dayRegs.filter(r => r.status === 'approved').length,
          pending: dayRegs.filter(r => r.status === 'pending').length,
          rejected: dayRegs.filter(r => r.status === 'rejected').length,
          needsInfo: dayRegs.filter(r => r.status === 'needs_info').length,
        };
      });
    } else {
      const start = startOfYear(endDate);
      const months = eachMonthOfInterval({ start, end: endDate });
      
      return months.map(month => {
        const monthRegs = processedRegs.filter(r => isSameMonth(r.date, month));
        return {
          date: format(month, 'MMMM', { locale: arSA }),
          total: monthRegs.length,
          approved: monthRegs.filter(r => r.status === 'approved').length,
          pending: monthRegs.filter(r => r.status === 'pending').length,
          rejected: monthRegs.filter(r => r.status === 'rejected').length,
          needsInfo: monthRegs.filter(r => r.status === 'needs_info').length,
        };
      });
    }
  }, [registrations, timeframe]);

  // 2.1 Growth Stats
  const growthStats = useMemo(() => {
    if (registrations.length === 0) return { total: 0, approved: 0 };
    
    const now = new Date();
    const thirtyDaysAgo = new Date(now);
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    const sixtyDaysAgo = new Date(now);
    sixtyDaysAgo.setDate(sixtyDaysAgo.getDate() - 60);

    const currentPeriod = registrations.filter(r => {
      const d = r.createdAt?.toDate ? r.createdAt.toDate() : new Date(r.createdAt);
      return d >= thirtyDaysAgo && d <= now;
    }).length;

    const previousPeriod = registrations.filter(r => {
      const d = r.createdAt?.toDate ? r.createdAt.toDate() : new Date(r.createdAt);
      return d >= sixtyDaysAgo && d < thirtyDaysAgo;
    }).length;

    const growth = previousPeriod === 0 ? (currentPeriod > 0 ? 100 : 0) : ((currentPeriod - previousPeriod) / previousPeriod) * 100;

    return {
      currentPeriod,
      previousPeriod,
      growth: Math.round(growth)
    };
  }, [registrations]);

  // 2.2 Day of Week Distribution
  const dayOfWeekData = useMemo(() => {
    const days = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
    const counts = new Array(7).fill(0);
    
    registrations.forEach(r => {
      const d = r.createdAt?.toDate ? r.createdAt.toDate() : new Date(r.createdAt);
      if (!isNaN(d.getTime())) {
        counts[d.getDay()]++;
      }
    });

    return days.map((name, i) => ({ name, count: counts[i] }));
  }, [registrations]);

  // 3. Status Distribution
  const statusData = useMemo(() => [
    { name: 'مقبول', value: stats.approved },
    { name: 'مرفوض', value: stats.rejected },
    { name: 'قيد المراجعة', value: stats.pending },
    { name: 'نقص بيانات', value: stats.needsInfo },
  ].filter(d => d.value > 0), [stats]);

  // 4. Festival Distribution (Pie & Bar)
  const festivalData = useMemo(() => {
    return festivals.map(f => {
      const festivalRegs = registrations.filter(r => r.festivalId === f.id);
      
      // Service evaluation (تقييم الخدمة)
      const evaluatedRegs = festivalRegs.filter(r => r.evaluation && r.evaluation.rating > 0);
      const totalRating = evaluatedRegs.reduce((acc, curr) => acc + curr.evaluation.rating, 0);
      const averageRating = evaluatedRegs.length > 0 ? (totalRating / evaluatedRegs.length).toFixed(1) : '0';
      const ratingPercentage = evaluatedRegs.length > 0 ? Math.round((totalRating / (evaluatedRegs.length * 5)) * 100) : 0;

      // Festival satisfaction evaluation (تقييم رضا المشاركين عن المهرجان نفسه)
      const festivalEvaluatedRegs = festivalRegs.filter(r => r.festivalEvaluation && r.festivalEvaluation.rating > 0);
      const totalFestivalRating = festivalEvaluatedRegs.reduce((acc, curr) => acc + curr.festivalEvaluation.rating, 0);
      const averageFestivalRating = festivalEvaluatedRegs.length > 0 ? (totalFestivalRating / festivalEvaluatedRegs.length).toFixed(1) : '0';
      const festivalRatingPercentage = festivalEvaluatedRegs.length > 0 ? Math.round((totalFestivalRating / (festivalEvaluatedRegs.length * 5)) * 100) : 0;

      return {
        name: f.name,
        count: festivalRegs.length,
        averageRating: parseFloat(averageRating),
        ratingPercentage,
        evaluationCount: evaluatedRegs.length,
        averageFestivalRating: parseFloat(averageFestivalRating),
        festivalRatingPercentage,
        festivalEvaluationCount: festivalEvaluatedRegs.length
      };
    }).filter(f => f.count > 0).sort((a, b) => b.count - a.count);
  }, [registrations, festivals]);

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-4 rounded-2xl shadow-xl border border-slate-100 text-sm font-bold text-slate-700">
          <p className="mb-2 text-slate-500 border-b border-slate-50 pb-1">{label}</p>
          <div className="space-y-1">
            {payload.map((p: any, index: number) => (
              <p key={`tooltip-${p.dataKey || p.name}-${index}`} style={{ color: p.color || p.fill }}>
                {p.name}: {p.value}
              </p>
            ))}
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4 relative overflow-hidden">
          <div className="w-12 h-12 rounded-full bg-blue-50 text-blue-500 flex items-center justify-center shrink-0">
            <Users size={24} />
          </div>
          <div>
            <p className="text-sm font-bold text-slate-400 mb-1">إجمالي المسجلين</p>
            <div className="flex items-baseline gap-2">
              <h4 className="text-2xl font-black text-slate-800">{stats.total}</h4>
              <span className={`text-xs font-bold flex items-center gap-0.5 ${growthStats.growth >= 0 ? 'text-emerald-500' : 'text-red-500'}`}>
                {growthStats.growth >= 0 ? '+' : ''}{growthStats.growth}%
              </span>
            </div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-500 flex items-center justify-center shrink-0">
            <CheckCircle size={24} />
          </div>
          <div>
            <p className="text-sm font-bold text-slate-400 mb-1">الطلبات المقبولة</p>
            <h4 className="text-2xl font-black text-slate-800">{stats.approved}</h4>
          </div>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-amber-50 text-amber-500 flex items-center justify-center shrink-0">
            <Clock size={24} />
          </div>
          <div>
            <p className="text-sm font-bold text-slate-400 mb-1">قيد المراجعة</p>
            <h4 className="text-2xl font-black text-slate-800">{stats.pending}</h4>
          </div>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-red-50 text-red-500 flex items-center justify-center shrink-0">
            <XCircle size={24} />
          </div>
          <div>
            <p className="text-sm font-bold text-slate-400 mb-1">الطلبات المرفوضة</p>
            <h4 className="text-2xl font-black text-slate-800">{stats.rejected}</h4>
          </div>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-blue-50 text-blue-500 flex items-center justify-center shrink-0">
            <Clock size={24} />
          </div>
          <div>
            <p className="text-sm font-bold text-slate-400 mb-1">نقص بيانات</p>
            <h4 className="text-2xl font-black text-slate-800">{stats.needsInfo}</h4>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Time Series Chart */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 lg:col-span-2">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-4">
            <div className="flex items-center gap-2">
              <TrendingUp className="text-emerald-500" size={20} />
              <h3 className="text-lg font-black text-slate-900">اتجاهات التسجيل</h3>
            </div>
            <div className="flex bg-slate-100 p-1 rounded-lg">
              <button
                onClick={() => setTimeframe('daily')}
                className={`px-4 py-1.5 rounded-md text-xs font-bold transition-all ${timeframe === 'daily' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
              >
                يومي
              </button>
              <button
                onClick={() => setTimeframe('monthly')}
                className={`px-4 py-1.5 rounded-md text-xs font-bold transition-all ${timeframe === 'monthly' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
              >
                شهري
              </button>
            </div>
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={timeSeriesData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorApproved" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b' }} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b' }} />
                <Tooltip content={<CustomTooltip />} />
                <Legend verticalAlign="top" height={36} iconType="circle" wrapperStyle={{ fontSize: '14px', fontWeight: 'bold', paddingBottom: '20px' }} />
                <Area name="إجمالي المسجلين" type="monotone" dataKey="total" stroke="#3b82f6" strokeWidth={3} fillOpacity={1} fill="url(#colorTotal)" />
                <Area name="المقبولين" type="monotone" dataKey="approved" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#colorApproved)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Status Distribution Pie Chart */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-black text-slate-900 mb-6 flex items-center gap-2">
            <PieChartIcon className="text-blue-500" size={20} />
            توزيع الحالات
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie 
                  data={statusData} 
                  dataKey="value" 
                  nameKey="name" 
                  cx="50%" 
                  cy="50%" 
                  innerRadius={60}
                  outerRadius={80} 
                  paddingAngle={5}
                >
                  {statusData.map((entry, index) => (
                    <Cell key={`status-${entry.name}-${index}`} fill={STATUS_COLORS[index % STATUS_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
                <Legend verticalAlign="bottom" height={36} iconType="circle" wrapperStyle={{ fontSize: '14px', fontWeight: 'bold' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Day of Week Distribution */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-black text-slate-900 mb-6 flex items-center gap-2">
            <BarChartIcon className="text-emerald-500" size={20} />
            التسجيل حسب أيام الأسبوع
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={dayOfWeekData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b' }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b' }} />
                <Tooltip content={<CustomTooltip />} cursor={{ fill: '#f8fafc' }} />
                <Bar name="عدد المسجلين" dataKey="count" fill="#10b981" radius={[4, 4, 0, 0]} barSize={20} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Festival Distribution Pie Chart */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-black text-slate-900 mb-6 flex items-center gap-2">
            <CalendarIcon className="text-purple-500" size={20} />
            توزيع العرسان حسب المهرجان
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie 
                  data={festivalData} 
                  dataKey="count" 
                  nameKey="name" 
                  cx="50%" 
                  cy="50%" 
                  outerRadius={80} 
                  labelLine={false}
                  label={({ cx, cy, midAngle, innerRadius, outerRadius, percent, index }) => {
                    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
                    const x = cx + radius * Math.cos(-midAngle * Math.PI / 180);
                    const y = cy + radius * Math.sin(-midAngle * Math.PI / 180);
                    return percent > 0.05 ? (
                      <text x={x} y={y} fill="white" textAnchor="middle" dominantBaseline="central" fontSize={12} fontWeight="bold">
                        {`${(percent * 100).toFixed(0)}%`}
                      </text>
                    ) : null;
                  }}
                >
                  {festivalData.map((entry, index) => (
                    <Cell key={`pie-${entry.name}-${index}`} fill={FESTIVAL_COLORS[index % FESTIVAL_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
                <Legend verticalAlign="bottom" height={36} iconType="circle" wrapperStyle={{ fontSize: '12px', fontWeight: 'bold' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Festival Popularity Bar Chart */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 lg:col-span-1">
          <h3 className="text-lg font-black text-slate-900 mb-6 flex items-center gap-2">
            <BarChartIcon className="text-amber-500" size={20} />
            الإقبال على المهرجانات
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={festivalData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                <XAxis type="number" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b' }} />
                <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b', fontWeight: 'bold' }} width={100} />
                <Tooltip content={<CustomTooltip />} cursor={{ fill: '#f8fafc' }} />
                <Bar name="عدد المسجلين" dataKey="count" radius={[0, 4, 4, 0]} barSize={16}>
                  {festivalData.map((entry, index) => (
                    <Cell key={`bar-${entry.name}-${index}`} fill={FESTIVAL_COLORS[index % FESTIVAL_COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* NEW: Festival Rating Section */}
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 lg:col-span-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-8 gap-4">
            <div className="flex items-center gap-2">
              <Star className="text-amber-500 fill-amber-500" size={22} />
              <h3 className="text-xl font-black text-slate-900">مؤشرات الرضا والتقييمات لكل مهرجان</h3>
            </div>
            <p className="text-xs font-bold text-slate-400">مقارنة رضا العرسان عن الخدمة مقابل تنظيم المهرجان</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {festivalData.map((f, i) => (
              <div key={`rating-card-${f.name}-${i}`} className="bg-slate-50/50 p-6 rounded-[2rem] border border-slate-100/50 flex flex-col justify-between group hover:bg-white hover:shadow-xl hover:shadow-slate-100 transition-all duration-500">
                <div className="mb-4">
                  <h4 className="text-sm font-black text-slate-800 mb-1 text-center">{f.name}</h4>
                  <p className="text-[10px] font-bold text-slate-400 text-center">إجمالي المسجلين: {f.count}</p>
                </div>

                <div className="grid grid-cols-2 gap-4 border-t border-slate-100 pt-4">
                  {/* Service Rating Column */}
                  <div className="flex flex-col items-center text-center border-l border-slate-100 last:border-0">
                    <span className="text-[10px] font-black text-slate-500 mb-2">تقييم الخدمة والتسجيل</span>
                    
                    <div className="relative w-16 h-16 mb-2 flex items-center justify-center">
                      <svg className="w-full h-full -rotate-90">
                        <circle
                          cx="32"
                          cy="32"
                          r="26"
                          className="stroke-slate-100 fill-none"
                          strokeWidth="5"
                        />
                        <motion.circle
                          initial={{ strokeDasharray: "0 163" }}
                          animate={{ strokeDasharray: `${(f.ratingPercentage / 100) * 163} 163` }}
                          transition={{ duration: 1.5, delay: i * 0.1, ease: "easeOut" }}
                          cx="32"
                          cy="32"
                          r="26"
                          className="stroke-emerald-500 fill-none"
                          strokeWidth="5"
                          strokeLinecap="round"
                        />
                      </svg>
                      <div className="absolute flex flex-col items-center justify-center">
                        <span className="text-xs font-black text-slate-900">{f.ratingPercentage}%</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-0.5 mb-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star 
                          key={`service-star-metric-${star}`} 
                          size={8} 
                          className={`${star <= Math.round(f.averageRating) ? 'fill-emerald-400 text-emerald-400' : 'text-slate-200'}`} 
                        />
                      ))}
                    </div>
                    <span className="text-xs font-black text-slate-800">{f.averageRating}</span>
                    <p className="text-[9px] font-bold text-slate-400 mt-0.5">{f.evaluationCount} تقييم</p>
                  </div>

                  {/* Festival Rating Column */}
                  <div className="flex flex-col items-center text-center">
                    <span className="text-[10px] font-black text-slate-500 mb-2">تقييم المهرجان والفعاليات</span>
                    
                    <div className="relative w-16 h-16 mb-2 flex items-center justify-center">
                      <svg className="w-full h-full -rotate-90">
                        <circle
                          cx="32"
                          cy="32"
                          r="26"
                          className="stroke-slate-100 fill-none"
                          strokeWidth="5"
                        />
                        <motion.circle
                          initial={{ strokeDasharray: "0 163" }}
                          animate={{ strokeDasharray: `${(f.festivalRatingPercentage / 100) * 163} 163` }}
                          transition={{ duration: 1.5, delay: i * 0.1, ease: "easeOut" }}
                          cx="32"
                          cy="32"
                          r="26"
                          className="stroke-amber-500 fill-none"
                          strokeWidth="5"
                          strokeLinecap="round"
                        />
                      </svg>
                      <div className="absolute flex flex-col items-center justify-center">
                        <span className="text-xs font-black text-slate-900">{f.festivalRatingPercentage}%</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-0.5 mb-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star 
                          key={`fest-star-metric-${star}`} 
                          size={8} 
                          className={`${star <= Math.round(f.averageFestivalRating) ? 'fill-amber-400 text-amber-400' : 'text-slate-200'}`} 
                        />
                      ))}
                    </div>
                    <span className="text-xs font-black text-slate-800">{f.averageFestivalRating}</span>
                    <p className="text-[9px] font-bold text-slate-400 mt-0.5">{f.festivalEvaluationCount} تقييم</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
