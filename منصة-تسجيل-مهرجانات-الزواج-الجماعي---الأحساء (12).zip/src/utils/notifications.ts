import { collection, addDoc, serverTimestamp, query, where, getDocs, limit, doc, getDoc } from 'firebase/firestore';
import { db, auth } from '../firebase';

export const notifyAdminsAndSupervisor = async (
  festivalId: string,
  festivalName: string,
  message: string,
  type: string,
  registrationId: string,
  supervisorId?: string
) => {
  try {
    const recipients = new Set<string>();
    
    // Add supervisor if assigned
    if (supervisorId) {
      recipients.add(supervisorId);
    }

    // Add all admins
    const adminsQuery = query(collection(db, 'users'), where('role', '==', 'admin'), limit(10));
    const adminsSnap = await getDocs(adminsQuery);
    adminsSnap.forEach(doc => {
      recipients.add(doc.id);
    });

    // Remove the current user so they don't get notified of their own actions
    if (auth.currentUser?.uid) {
      recipients.delete(auth.currentUser.uid);
    }

    // Send notifications
    const promises = Array.from(recipients).map(recipientId => 
      addDoc(collection(db, 'notifications'), {
        recipientId,
        message,
        type,
        registrationId,
        read: false,
        createdAt: serverTimestamp(),
      })
    );

    await Promise.all(promises);

    // Send automatic email notification to groom if order status changes
    if (type === 'status_update') {
      try {
        const settingsSnap = await getDoc(doc(db, 'settings', 'global'));
        const settings = settingsSnap.exists() ? settingsSnap.data() : { enableEmailNotifications: true };
        
        if (settings.enableEmailNotifications !== false) {
          const regSnap = await getDoc(doc(db, 'registrations', registrationId));
          if (regSnap.exists()) {
            const reg = regSnap.data();
            if (reg.groomEmail) {
              const subject = `تحديث حالة طلبك - ${festivalName}`;
              const emailText = `مرحباً ${reg.groomName}،\n\nنود إبلاغك بتحديث حالة طلبك في ${festivalName}.\n\nالتفاصيل:\n${message}\n\nشكراً لك، وسيتم التواصل معك بالخطوات القادمة في حال تطلب الأمر.`;
              
              await fetch('/api/send-email', {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                  to: reg.groomEmail,
                  subject,
                  text: emailText,
                }),
              });
              console.log('Successfully sent automatic status update email to groom:', reg.groomEmail);
            }
          }
        }
      } catch (emailError) {
        console.error('Error sending groom automatic email notification:', emailError);
      }
    }
  } catch (error) {
    console.error('Error sending notifications:', error);
  }
};
