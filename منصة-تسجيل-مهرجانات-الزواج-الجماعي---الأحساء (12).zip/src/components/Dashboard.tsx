import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  collection, onSnapshot, doc, updateDoc, addDoc, setDoc,
  deleteDoc, query, where, getDocs, getDoc, serverTimestamp, orderBy, arrayUnion,
  getDocFromServer, writeBatch, Timestamp
} from 'firebase/firestore';
import { ref, deleteObject, uploadBytes, getDownloadURL } from 'firebase/storage';
import imageCompression from 'browser-image-compression';
import { db, auth, storage } from '../firebase';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

const handleFirestoreError = (error: unknown, operationType: OperationType, path: string | null) => {
  const errorMessage = error instanceof Error ? error.message : String(error);
  
  const errInfo: FirestoreErrorInfo = {
    error: errorMessage,
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }

  // Handle specific "soft" errors
  if (errorMessage.includes('No document to update')) {
    console.warn('Firestore Warning (Soft): ', JSON.stringify(errInfo));
    return; // Don't throw for missing documents during updates
  }

  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}
import { 
  Settings, Users, Calendar, CreditCard, CheckCircle, 
  XCircle, Clock, Eye, Printer, Trash2, Plus, X, Lock, Unlock, FileText, User, Bell, Edit, Edit3, AlertCircle, History, ChevronLeft, ChevronRight, Image, MessageSquareHeart,
  Phone, MessageCircle, Globe, Instagram, Facebook, Ghost, Video, Share2, Twitter, Youtube, Send, UserCheck, UserX, Download, Paperclip, BarChart as LucideBarChart, Search, Gift, Award, Mail, ExternalLink
} from 'lucide-react';
import { format } from 'date-fns';
import { motion, AnimatePresence } from 'motion/react';
import ExcelJS from 'exceljs';
import { saveAs } from 'file-saver';
import PrintReport from './PrintReport';
import FullRegistrationsReport from './FullRegistrationsReport';
import { AnalyticsDashboard } from './AnalyticsDashboard';
import { FestivalsTab } from './dashboard/FestivalsTab';
import { SupervisorsTab } from './dashboard/SupervisorsTab';
import { VendorsTab } from './dashboard/VendorsTab';
import { CoursesTab } from './dashboard/CoursesTab';
import { RegistrationDetails } from './dashboard/RegistrationDetails';
import { RegistrationCard } from './RegistrationCard';
import { notifyAdminsAndSupervisor } from '../utils/notifications';
import { cache } from '../utils/cache';

interface DashboardProps {
  userProfile: {
    uid: string;
    email: string;
    role: 'admin' | 'supervisor' | 'user';
    displayName: string;
    photoURL?: string;
    assignedFestivalId?: string;
  };
  festivals: any[];
  onEditRegistration?: (reg: any) => void;
  quotaExceeded?: boolean;
}

export function Dashboard({ userProfile, festivals, onEditRegistration, quotaExceeded }: DashboardProps) {
  if (!userProfile) return null;

  const isItemAdminOnly = (tab: string) => {
    return ['supervisors', 'settings', 'logs', 'festivals'].includes(tab);
  };

  const canAccessTab = (tab: string) => {
    if (userProfile.role === 'admin') return true;
    if (userProfile.role === 'supervisor') {
      return !isItemAdminOnly(tab);
    }
    return tab === 'registrations';
  };

  const [activeTab, setActiveTab] = useState<'festivals' | 'registrations' | 'supervisors' | 'settings' | 'gallery' | 'testimonials' | 'analytics' | 'logs' | 'vendors' | 'courses'>('registrations');

  // Guard activeTab if redirected or somehow set manually
  useEffect(() => {
    if (!canAccessTab(activeTab)) {
      setActiveTab('registrations');
    }
  }, [activeTab, userProfile.role]);
  const [registrations, setRegistrations] = useState<any[]>([]);
  const [supervisors, setSupervisors] = useState<any[]>([]);
  const [vendors, setVendors] = useState<any[]>([]);
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [galleryImages, setGalleryImages] = useState<any[]>([]);
  const [testimonials, setTestimonials] = useState<any[]>([]);
  const [showLogsModal, setShowLogsModal] = useState<string | null>(null); // registrationId
  const [notifications, setNotifications] = useState<any[]>([]);
  const [toasts, setToasts] = useState<any[]>([]);

  const dismissToast = (id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };
  const [showReminderModal, setShowReminderModal] = useState(false);
  const [isArchiving, setIsArchiving] = useState(false);

  const siblingGroups = useMemo(() => {
    const groomIdToGroupId = new Map<string, number>();
    let nextGroupId = 0;

    registrations.forEach(reg => {
      if (reg.hasSibling && reg.siblingIds && reg.siblingIds.length > 0) {
        let groupId = -1;
        
        [reg.groomId, ...reg.siblingIds].forEach(id => {
          if (groomIdToGroupId.has(id)) {
            groupId = groomIdToGroupId.get(id)!;
          }
        });

        if (groupId === -1) {
          groupId = nextGroupId++;
        }

        [reg.groomId, ...reg.siblingIds].forEach(id => {
          groomIdToGroupId.set(id, groupId);
        });
      }
    });
    return groomIdToGroupId;
  }, [registrations]);

  const siblingGroupColors = [
    'bg-red-50', 'bg-blue-50', 'bg-emerald-50', 'bg-amber-50', 'bg-purple-50', 'bg-pink-50', 'bg-cyan-50'
  ];

  const handleArchive = async () => {
    if (!window.confirm('هل أنت متأكد من أرشفة طلبات الأعوام السابقة؟ سيتم نقل جميع الطلبات التي مضى عليها أكثر من عام إلى الأرشيف.')) return;
    
    setIsArchiving(true);
    try {
      const oneYearAgo = new Date();
      oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1);
      
      const q = query(collection(db, 'registrations'), where('createdAt', '<', oneYearAgo));
      const snapshot = await getDocs(q);
      
      if (snapshot.empty) {
        alert('لا توجد طلبات قديمة للأرشفة حالياً.');
        setIsArchiving(false);
        return;
      }
      
      const batch = writeBatch(db);
      snapshot.docs.forEach(docSnap => {
        const data = docSnap.data();
        const archiveRef = doc(db, 'archived_registrations', docSnap.id);
        batch.set(archiveRef, data);
        batch.delete(docSnap.ref);
      });
      
      await batch.commit();
      alert(`تم أرشفة ${snapshot.size} طلب بنجاح.`);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'registrations/archiving');
    } finally {
      setIsArchiving(false);
    }
  };
  const [showNotifications, setShowNotifications] = useState(false);
  const [siteSettings, setSiteSettings] = useState({ 
    siteOpen: true,
    bankName: '',
    accountNumber: '',
    iban: '',
    enableOnlinePayment: true,
    enableTransferPayment: true,
    enableSmsNotifications: true,
    enableEmailNotifications: true,
    siteName: 'الجمعية الخيرية',
    secondaryTitle: '',
    contactNumber: '',
    whatsappNumber: '',
    xLink: '',
    maxFileSizeMB: 5,
    allowedFileTypes: ['image/jpeg', 'image/png', 'application/pdf'],
    showOffersTab: true,
    showCoursesTab: true
  });
  const [selectedReg, setSelectedReg] = useState<any>(null);
  const [deficiencies, setDeficiencies] = useState<string[]>([]);
  const [highlightPayment, setHighlightPayment] = useState(false);
  const paymentSectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (selectedReg) {
      setDeficiencies(selectedReg.deficiencies || []);
    }
  }, [selectedReg]);
  
  useEffect(() => {
    if (selectedReg && highlightPayment) {
      setTimeout(() => {
        paymentSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }, 500);
    }
  }, [selectedReg, highlightPayment]);
  const [showAddFestival, setShowAddFestival] = useState(false);
  const [showAddSupervisor, setShowAddSupervisor] = useState(false);
  const [showAddTestimonial, setShowAddTestimonial] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isImporting, setIsImporting] = useState(false);
  const [editingSupervisor, setEditingSupervisor] = useState<any>(null);
  const [editingTestimonial, setEditingTestimonial] = useState<any>(null);
  const [showSiteToggleConfirm, setShowSiteToggleConfirm] = useState(false);
  const [festivalStatusConfirm, setFestivalStatusConfirm] = useState<{ id: string, name: string, isOpen: boolean } | null>(null);
  const [rejectionModal, setRejectionModal] = useState<{ id: string, name: string } | null>(null);
  const [needsInfoModal, setNeedsInfoModal] = useState<{ id: string, name: string } | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');
  const [needsInfoDeficiencies, setNeedsInfoDeficiencies] = useState<string[]>([]);
  const [deleteConfirm, setDeleteConfirm] = useState<{ id: string, type: 'festival' | 'supervisor' | 'testimonial' } | null>(null);
  const [deleteAttachmentConfirm, setDeleteAttachmentConfirm] = useState<{ regId: string, index: number, type: 'attachment' | 'paymentReceipt' } | null>(null);
  const [imageToDelete, setImageToDelete] = useState<{ id: string, name: string } | null>(null);
  const [showSeedConfirm, setShowSeedConfirm] = useState(false);
  const [alertMessage, setAlertMessage] = useState<string | null>(null);
  const [printingReg, setPrintingReg] = useState<any>(null);
  const [showPrintPreview, setShowPrintPreview] = useState(false);
  const [showFullReportPrint, setShowFullReportPrint] = useState(false);
  const [isPrinting, setIsPrinting] = useState(false);
  const [editingSocialFestival, setEditingSocialFestival] = useState<any>(null);
  const [newNoteText, setNewNoteText] = useState('');
  const [isAddingNote, setIsAddingNote] = useState(false);
  const [newNoteType, setNewNoteType] = useState<'note' | 'task'>('note');
  const [assignedSupervisor, setAssignedSupervisor] = useState<string>('');
  const [viewingAttachment, setViewingAttachment] = useState<{url: string, type: string, name: string} | null>(null);
  const [editingTermIndex, setEditingTermIndex] = useState<number | null>(null);
  const [editingTermValue, setEditingTermValue] = useState<string>('');

  const [selectedFestivalFilter, setSelectedFestivalFilter] = useState<string>(() => {
    if (userProfile.role === 'admin') return 'all';
    if (userProfile.role === 'supervisor' && userProfile.assignedFestivalId) {
      return userProfile.assignedFestivalId;
    }
    const openFestival = festivals.find(f => f.isOpen);
    if (openFestival) return openFestival.id;
    if (festivals.length > 0) return festivals[0].id;
    return 'all';
  });
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>('all');
  const [sortConfig, setSortConfig] = useState<{key: string, direction: 'asc' | 'desc'}>({key: 'createdAt', direction: 'desc'});
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRegistrations, setSelectedRegistrations] = useState<Set<string>>(new Set());
  const [bulkTargetFestival, setBulkTargetFestival] = useState<string>('');
  const [logsSearchTerm, setLogsSearchTerm] = useState<string>('');
  const [showBulkDeleteConfirm, setShowBulkDeleteConfirm] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [toastMessage, setToastMessage] = useState<{message: string, type: 'success' | 'error'} | null>(null);
  const itemsPerPage = 20;

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToastMessage({ message, type });
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleSettingChange = async (key: string, value: any) => {
    try {
      await updateDoc(doc(db, 'settings', 'global'), { [key]: value });
      showToast('تم حفظ التغييرات بنجاح');
    } catch (error) {
      console.error('Error updating setting:', error);
      showToast('حدث خطأ أثناء حفظ التغييرات', 'error');
    }
  };

  const filteredRegistrations = registrations.filter(r => 
    (selectedFestivalFilter === 'all' || r.festivalId === selectedFestivalFilter) &&
    (selectedStatusFilter === 'all' || 
     (selectedStatusFilter === 'pending_payment' 
       ? (r.paymentStatus === 'pending' || r.paymentStatus === 'pending_verification' || r.paymentStatus === 'rejected') 
       : r.status === selectedStatusFilter)) &&
    (r.groomName?.includes(searchTerm) || r.groomId?.includes(searchTerm) || r.groomPhone?.includes(searchTerm))
  ).sort((a, b) => {
    let valA = (a as any)[sortConfig.key];
    let valB = (b as any)[sortConfig.key];
    
    if (sortConfig.key === 'createdAt') {
      valA = valA?.toDate ? valA.toDate().getTime() : 0;
      valB = valB?.toDate ? valB.toDate().getTime() : 0;
    }

    if (valA < valB) return sortConfig.direction === 'asc' ? -1 : 1;
    if (valA > valB) return sortConfig.direction === 'asc' ? 1 : -1;
    return 0;
  });

  const totalPages = Math.ceil(filteredRegistrations.length / itemsPerPage);
  const paginatedRegistrations = filteredRegistrations.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const statsRegistrations = selectedFestivalFilter === 'all'
    ? registrations
    : registrations.filter(r => r.festivalId === selectedFestivalFilter);

  useEffect(() => {
    setCurrentPage(1);
  }, [selectedFestivalFilter, selectedStatusFilter, searchTerm]);

  const requestSort = (key: string) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const toggleSelectAll = () => {
    if (selectedRegistrations.size === filteredRegistrations.length) {
      setSelectedRegistrations(new Set());
    } else {
      setSelectedRegistrations(new Set(filteredRegistrations.map(r => r.id)));
    }
  };

  const toggleSelect = (id: string) => {
    const next = new Set(selectedRegistrations);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelectedRegistrations(next);
  };

  const performBulkAction = async (status: string) => {
    try {
      for (const id of selectedRegistrations) {
        const reg = registrations.find(r => r.id === id);
        if (!reg) continue;

        const oldStatus = reg.status;
        const oldPaymentStatus = reg.paymentStatus;

        try {
          if (status === 'mark_paid') {
            await updateDoc(doc(db, 'registrations', id), { 
              paymentStatus: 'paid',
              updatedAt: serverTimestamp()
            });
          } else {
            await updateDoc(doc(db, 'registrations', id), { 
              status, 
              rejectionReason: null,
              updatedAt: serverTimestamp()
            });
          }
        } catch (error) {
          handleFirestoreError(error, OperationType.UPDATE, `registrations/${id}`);
        }

        // Record Audit Log
        try {
          await addDoc(collection(db, 'audit_logs'), {
            userId: auth.currentUser?.uid,
            userName: userProfile.email,
            action: status === 'mark_paid' ? 'تأكيد السداد (جماعي)' : 'تغيير حالة الطلب (جماعي)',
            registrationId: id,
            oldValue: status === 'mark_paid' ? (oldPaymentStatus || 'pending') : oldStatus,
            newValue: status === 'mark_paid' ? 'paid' : status,
            createdAt: serverTimestamp()
          });
        } catch (error) {
          handleFirestoreError(error, OperationType.CREATE, 'audit_logs');
        }

        // Send notification
        if (status !== 'mark_paid') {
          const festival = festivals.find(f => f.id === reg.festivalId);
          let statusText = '';
          if (status === 'approved') statusText = 'مقبول';
          else if (status === 'needs_info') statusText = 'نحتاج إلى مزيد من البيانات';
          else statusText = 'قيد المراجعة والدراسة';

          await notifyAdminsAndSupervisor(
            reg.festivalId,
            reg.festivalName,
            `تم تغيير حالة طلب ${reg.groomName} إلى ${statusText}`,
            'status_update',
            id,
            festival?.supervisorId
          );

          // Send SMS notification
          if (siteSettings.enableSmsNotifications && reg.groomPhone) {
            fetch('/api/send-sms', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                to: reg.groomPhone.startsWith('0') ? '+966' + reg.groomPhone.substring(1) : reg.groomPhone,
                message: `مرحباً ${reg.groomName}، تم تغيير حالة طلبك في مهرجان ${reg.festivalName} إلى: ${statusText}`
              })
            }).catch(err => console.error('Error sending SMS:', err));
          }

          // Send Email notification
          if (siteSettings.enableEmailNotifications && reg.groomEmail) {
            fetch('/api/send-email', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                to: reg.groomEmail,
                subject: `تحديث حالة طلبك في مهرجان ${reg.festivalName}`,
                text: `مرحباً ${reg.groomName}،\n\nتم تغيير حالة طلبك في مهرجان ${reg.festivalName} إلى: ${statusText}.\n\nشكراً لك.`
              })
            }).catch(err => console.error('Error sending Email:', err));
          }
        }
      }
      showToast(`تم تحديث ${selectedRegistrations.size} طلب بنجاح`);
      setSelectedRegistrations(new Set());
    } catch (error) {
      console.error('Error in bulk action:', error);
      showToast('حدث خطأ أثناء تنفيذ الإجراء الجماعي', 'error');
    }
  };

  const bulkTransfer = async () => {
    if (!bulkTargetFestival) return;
    const targetFestival = festivals.find(f => f.id === bulkTargetFestival);
    if (!targetFestival) return;

    try {
      for (const id of selectedRegistrations) {
        const reg = registrations.find(r => r.id === id);
        if (reg) {
          try {
            await updateDoc(doc(db, 'registrations', id), { 
              festivalId: bulkTargetFestival,
              festivalName: targetFestival.name
            });
          } catch (error) {
            handleFirestoreError(error, OperationType.UPDATE, `registrations/${id}`);
          }
          
          try {
            await notifyAdminsAndSupervisor(
              bulkTargetFestival,
              targetFestival.name,
              `تم تحويل طلب جديد للمهرجان: ${reg.groomName}`,
              'transfer',
              id,
              targetFestival.supervisorId
            );
          } catch (error) {
            handleFirestoreError(error, OperationType.CREATE, 'notifications');
          }
        }
      }
      showToast(`تم تحويل ${selectedRegistrations.size} طلب بنجاح`);
      setSelectedRegistrations(new Set());
      setBulkTargetFestival('');
    } catch (error) {
      console.error('Error in bulk transfer:', error);
      showToast('حدث خطأ أثناء تحويل الطلبات', 'error');
    }
  };

  const deleteSelected = async () => {
    try {
      for (const id of selectedRegistrations) {
        try {
          await deleteDoc(doc(db, 'registrations', id));
        } catch (error) {
          handleFirestoreError(error, OperationType.DELETE, `registrations/${id}`);
        }
      }
      showToast(`تم حذف ${selectedRegistrations.size} طلب بنجاح`);
      setSelectedRegistrations(new Set());
      setShowBulkDeleteConfirm(false);
    } catch (error) {
      console.error('Error in bulk delete:', error);
      showToast('حدث خطأ أثناء حذف الطلبات', 'error');
    }
  };

  const sendWhatsAppReminder = (reg: any) => {
    if (!reg.groomPhone) {
      showToast('رقم الجوال غير متوفر', 'error');
      return;
    }
    
    const siteUrl = window.location.origin;
    const message = `${reg.groomName} السلام عليكم ، نذكركم بضرورة متابعة حالة طلبكم في بوابة العرسان لدى موقع الجمعية الخيرية لتيسير الزواج ورعاية الاسرة - فرع المنيزلة ${siteUrl} .. شاكرين ومقدرين لكم ذلك`;
    
    // Normalize phone number for WA (remove leading 0 if present and add 966)
    let phone = reg.groomPhone.toString().replace(/\s+/g, '');
    if (phone.startsWith('0')) {
      phone = '966' + phone.substring(1);
    } else if (!phone.startsWith('966') && phone.length === 9) {
      phone = '966' + phone;
    }
    
    const url = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  const sendEmailReminder = (reg: any) => {
    if (!reg.groomEmail) {
      showToast('البريد الإلكتروني غير متوفر', 'error');
      return;
    }
    
    const subject = encodeURIComponent('تذكير بخصوص طلبك في بوابة العرسان');
    let message = `مرحباً ${reg.groomName}،%0D%0A%0D%0Aنذكركم بضرورة `;
    if (reg.paymentStatus === 'pending' || reg.paymentStatus === 'rejected') {
      message += 'إكمال عملية السداد ورفع الإيصال في بوابة العرسان لمتابعة طلبكم.';
    } else if (reg.status === 'needs_info') {
      message += 'تحديث بيانات طلبكم لوجود ملاحظات تتطلب الإكمال.';
    } else {
      message += 'متابعة حالة طلبكم في بوابة العرسان.';
    }
    message += `%0D%0A%0D%0Aشكراً لكم.`;
    
    const url = `mailto:${reg.groomEmail}?subject=${subject}&body=${message}`;
    window.location.href = url;
  };

  const getOverdueRegistrations = () => {
    const twentyFourHoursAgo = new Date();
    twentyFourHoursAgo.setHours(twentyFourHoursAgo.getHours() - 24);

    return statsRegistrations.filter(r => {
      // Logic: Status is pending or needs_info OR payment is pending
      const isStatusPending = r.status === 'pending' || r.status === 'needs_info';
      const isPaymentPending = r.paymentStatus === 'pending' || !r.paymentStatus;
      
      const createdAt = r.createdAt?.toDate ? r.createdAt.toDate() : (r.createdAt ? new Date(r.createdAt) : new Date());
      
      return (isStatusPending || isPaymentPending) && createdAt < twentyFourHoursAgo;
    });
  };



  useEffect(() => {
    if (!userProfile || quotaExceeded) {
      if (quotaExceeded) {
        // Try to load from cache if quota exceeded
        const cacheKey = `registrations_${userProfile?.uid}`;
        const cached = cache.get<any[]>(cacheKey);
        if (cached) setRegistrations(cached);
      }
      return;
    }

    // Fetch registrations based on role
    let regQuery;
    if (userProfile.role === 'admin' || userProfile.role === 'supervisor') {
      regQuery = collection(db, 'registrations');
    } else {
      regQuery = query(collection(db, 'registrations'), where('festivalId', '==', userProfile.assignedFestivalId || ''));
    }

    // Subscribe to registrations
    const unsubscribeRegs = onSnapshot(regQuery, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...(doc.data() as any) }));
      setRegistrations(data);
      const cacheKey = `registrations_${userProfile.uid}`;
      cache.set(cacheKey, data);
    }, (err) => {
      console.error('Error in registrations snapshot:', err);
    });

    // Fetch supervisors and admins if admin
    if (userProfile.role === 'admin') {
      const cachedSupervisors = cache.get<any[]>('supervisors');
      if (cachedSupervisors) {
        setSupervisors(cachedSupervisors);
      }

      const fetchSups = async () => {
        try {
          const snapshot = await getDocs(query(collection(db, 'users'), where('role', 'in', ['admin', 'supervisor'])));
          const data = snapshot.docs.map(doc => ({ id: doc.id, ...(doc.data() as any) }));
          setSupervisors(data);
          cache.set('supervisors', data);
        } catch (err) {
          console.error('Error fetching supervisors:', err);
        }
      };
      fetchSups();
    }

    const fetchSettings = async () => {
      try {
        const docSnap = await getDoc(doc(db, 'settings', 'global'));
        if (docSnap.exists()) {
          const data = docSnap.data();
          setSiteSettings(prev => {
            const updated = { ...prev, ...data };
            cache.set('global_settings', updated);
            return updated;
          });
        }
      } catch (err) {
        console.error('Error fetching settings:', err);
      }
    };
    fetchSettings();

    // Fetch notifications for the user
    const fetchNotifs = async () => {
      try {
        const notifQuery = query(
          collection(db, 'notifications'), 
          where('recipientId', '==', auth.currentUser?.uid || ''),
          where('read', '==', false)
        );
        const snapshot = await getDocs(notifQuery);
        setNotifications(snapshot.docs.map(doc => ({ id: doc.id, ...(doc.data() as any) })));
      } catch (err) {
        console.error('Error fetching notifications:', err);
      }
    };
    fetchNotifs();

    // Fetch audit logs
    const cachedAuditLogs = cache.get<any[]>('audit_logs');
    if (cachedAuditLogs) {
      setAuditLogs(cachedAuditLogs);
    }
    
    const fetchAudit = async () => {
      try {
        const snapshot = await getDocs(query(collection(db, 'audit_logs'), orderBy('createdAt', 'desc')));
        const data = snapshot.docs.map(doc => ({ id: doc.id, ...(doc.data() as any) }));
        setAuditLogs(data);
        cache.set('audit_logs', data, 3600000); // Cache for 1 hour
      } catch (err) {
        console.error('Error fetching audit logs:', err);
      }
    };
    fetchAudit();

    // Fetch gallery images
    const cachedGallery = cache.get<any[]>('gallery');
    if (cachedGallery) {
      setGalleryImages(cachedGallery);
    }

    const fetchGallery = async () => {
      try {
        const snapshot = await getDocs(query(collection(db, 'gallery'), orderBy('createdAt', 'desc')));
        const data = snapshot.docs.map(doc => ({ id: doc.id, ...(doc.data() as any) }));
        setGalleryImages(data);
        cache.set('gallery', data);
      } catch (err) {
        console.error('Error fetching gallery:', err);
      }
    };
    fetchGallery();

    // Fetch testimonials
    const cachedTestimonials = cache.get<any[]>('testimonials');
    if (cachedTestimonials) {
      setTestimonials(cachedTestimonials);
    }

    const fetchTestimonials = async () => {
      try {
        const snapshot = await getDocs(query(collection(db, 'testimonials'), orderBy('createdAt', 'desc')));
        const data = snapshot.docs.map(doc => ({ id: doc.id, ...(doc.data() as any) }));
        setTestimonials(data);
        cache.set('testimonials', data);
      } catch (err) {
        console.error('Error fetching testimonials:', err);
      }
    };
    fetchTestimonials();

    // Fetch vendors
    const fetchVendors = async () => {
      try {
        const snapshot = await getDocs(collection(db, 'vendors'));
        let list: any[] = snapshot.docs.map(doc => ({ id: doc.id, ...(doc.data() as any) }));
        list.sort((a: any, b: any) => b.createdAt?.localeCompare(a.createdAt || '') || 0);

        if (snapshot.empty && userProfile?.role === 'admin') {
          // ... seeding logic ...
        }
        setVendors(list);
      } catch (err) {
        console.error('Error fetching vendors:', err);
      }
    };
    fetchVendors();

    return () => {
      unsubscribeRegs();
    };
  }, [userProfile]);

  const toggleSite = async () => {
    await handleSettingChange('siteOpen', !siteSettings.siteOpen);
    setShowSiteToggleConfirm(false);
  };

  const updateFestivalStatus = async (id: string, isOpen: boolean) => {
    try {
      await updateDoc(doc(db, 'festivals', id), { isOpen });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `festivals/${id}`);
    }
    setFestivalStatusConfirm(null);
  };

  const updateFestivalName = async (id: string, name: string) => {
    try {
      await updateDoc(doc(db, 'festivals', id), { name });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `festivals/${id}`);
    }
  };

  const handleConfirmPrint = () => {
    setIsPrinting(true);
    setTimeout(() => {
      window.print();
      setIsPrinting(false);
      setShowPrintPreview(false);
      setPrintingReg(null);
      setSelectedReg(null);
    }, 500);
  };

  const updateFestivalDate = async (id: string, date: string) => {
    try {
      await updateDoc(doc(db, 'festivals', id), { date });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `festivals/${id}`);
    }
  };

  const updateFestivalEndDate = async (id: string, endDate: string) => {
    try {
      await updateDoc(doc(db, 'festivals', id), { endDate });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `festivals/${id}`);
    }
  };

  const updateFestivalFees = async (id: string, fees: number) => {
    try {
      await updateDoc(doc(db, 'festivals', id), { fees: Number(fees) });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `festivals/${id}`);
    }
  };

  const updateFestivalSiblingPricing = async (
    id: string,
    siblingDiscountType: string,
    twoBrothersFees: number,
    threeBrothersFees: number
  ) => {
    try {
      await updateDoc(doc(db, 'festivals', id), {
        siblingDiscountType,
        twoBrothersFees: Number(twoBrothersFees),
        threeBrothersFees: Number(threeBrothersFees)
      });
      showToast('تم تحديث نظام خصم الإخوة بنجاح');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `festivals/${id}`);
    }
  };

  const updateFestivalArchiveStatus = async (id: string, isArchived: boolean) => {
    try {
      await updateDoc(doc(db, 'festivals', id), { isArchived });
      showToast(isArchived ? 'تم أرشفة المهرجان بنجاح' : 'تم إلغاء أرشفة المهرجان بنجاح');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `festivals/${id}`);
    }
  };

  const updateFestivalSocial = async (id: string, field: string, value: string) => {
    try {
      await updateDoc(doc(db, 'festivals', id), { [field]: value });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `festivals/${id}`);
    }
  };

  const exportToCSV = () => {
    const filteredRegs = registrations.filter(r => selectedFestivalFilter === 'all' || r.festivalId === selectedFestivalFilter);
    if (filteredRegs.length === 0) return;

    const headers = [
      'اسم العريس', 'رقم هوية العريس', 'جوال العريس', 'اسم العروس', 'رقم هوية العروس', 
      'جوال العروس', 'المهرجان', 'الحالة', 'تاريخ التسجيل'
    ];

    const rows = filteredRegs.map(r => [
      r.groomName,
      r.groomId,
      r.groomPhone,
      r.brideName,
      r.brideId,
      r.bridePhone,
      r.festivalName,
      r.status === 'approved' ? 'مقبول' : r.status === 'rejected' ? 'مرفوض' : 'قيد المراجعة والدراسة',
      r.createdAt?.toDate ? format(r.createdAt.toDate(), 'yyyy/MM/dd') : '-'
    ]);

    const csvContent = "\uFEFF" + [
      headers.join(','),
      ...rows.map(row => row.join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `registrations_${format(new Date(), 'yyyy-MM-dd')}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const exportToExcel = async () => {
    const filteredRegs = registrations.filter(r => selectedFestivalFilter === 'all' || r.festivalId === selectedFestivalFilter);
    if (filteredRegs.length === 0) return;

    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('الطلبات');

    worksheet.columns = [
      { header: 'اسم العريس', key: 'groomName', width: 25 },
      { header: 'رقم هوية العريس', key: 'groomId', width: 20 },
      { header: 'جوال العريس', key: 'groomPhone', width: 20 },
      { header: 'اسم العروس', key: 'brideName', width: 25 },
      { header: 'رقم هوية العروس', key: 'brideId', width: 20 },
      { header: 'جوال العروس', key: 'bridePhone', width: 20 },
      { header: 'المهرجان', key: 'festivalName', width: 25 },
      { header: 'الحالة', key: 'status', width: 15 },
      { header: 'تاريخ التسجيل', key: 'createdAt', width: 20 }
    ];

    filteredRegs.forEach(r => {
      worksheet.addRow({
        groomName: r.groomName,
        groomId: r.groomId,
        groomPhone: r.groomPhone,
        brideName: r.brideName,
        brideId: r.brideId,
        bridePhone: r.bridePhone,
        festivalName: r.festivalName,
        status: r.status === 'approved' ? 'مقبول' : r.status === 'rejected' ? 'مرفوض' : 'قيد المراجعة والدراسة',
        createdAt: r.createdAt?.toDate ? format(r.createdAt.toDate(), 'yyyy/MM/dd') : '-'
      });
    });

    // Style header
    worksheet.getRow(1).eachCell((cell) => {
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FF10B981' } // Emerald 500
      };
      cell.font = {
        color: { argb: 'FFFFFFFF' },
        bold: true
      };
      cell.alignment = { vertical: 'middle', horizontal: 'center' };
    });

    // Add auto-filter
    worksheet.autoFilter = 'A1:I1';

    const buffer = await workbook.xlsx.writeBuffer();
    saveAs(new Blob([buffer]), `registrations_${format(new Date(), 'yyyy-MM-dd')}.xlsx`);
  };

  const downloadExcelTemplate = async () => {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('نموذج الطلبات');

    worksheet.columns = [
      { header: 'اسم العريس', key: 'groomName', width: 25 },
      { header: 'رقم هوية العريس', key: 'groomId', width: 20 },
      { header: 'جوال العريس', key: 'groomPhone', width: 20 },
      { header: 'اسم العروس', key: 'brideName', width: 25 },
      { header: 'رقم هوية العروس', key: 'brideId', width: 20 },
      { header: 'جوال العروس', key: 'bridePhone', width: 20 },
      { header: 'المهرجان', key: 'festivalName', width: 25 }
    ];

    // Add a sample row
    worksheet.addRow({
      groomName: 'أحمد محمد',
      groomId: '1000000000',
      groomPhone: '0500000000',
      brideName: 'فاطمة علي',
      brideId: '1000000001',
      bridePhone: '0500000001',
      festivalName: festivals[0]?.name || 'مهرجان الرياض'
    });

    // Style header
    worksheet.getRow(1).eachCell((cell) => {
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFF59E0B' } // Amber 500
      };
      cell.font = {
        color: { argb: 'FFFFFFFF' },
        bold: true
      };
      cell.alignment = { vertical: 'middle', horizontal: 'center' };
    });

    const buffer = await workbook.xlsx.writeBuffer();
    saveAs(new Blob([buffer]), `template_registrations.xlsx`);
  };

  const handleImportExcel = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsImporting(true);
    try {
      const workbook = new ExcelJS.Workbook();
      await workbook.xlsx.load(await file.arrayBuffer());
      const worksheet = workbook.worksheets[0];

      const newRegistrations: any[] = [];
      const headers: string[] = [];

      worksheet.getRow(1).eachCell((cell, colNumber) => {
        headers[colNumber] = cell.value?.toString() || '';
      });

      worksheet.eachRow((row, rowNumber) => {
        if (rowNumber === 1) return; // Skip header

        const rowData: any = {};
        row.eachCell((cell, colNumber) => {
          const header = headers[colNumber];
          if (header.includes('اسم العريس')) rowData.groomName = cell.value?.toString();
          if (header.includes('هوية العريس')) rowData.groomId = cell.value?.toString();
          if (header.includes('جوال العريس')) rowData.groomPhone = cell.value?.toString();
          if (header.includes('اسم العروس')) rowData.brideName = cell.value?.toString();
          if (header.includes('هوية العروس')) rowData.brideId = cell.value?.toString();
          if (header.includes('جوال العروس')) rowData.bridePhone = cell.value?.toString();
          if (header.includes('المهرجان')) rowData.festivalName = cell.value?.toString();
        });

        if (rowData.groomName && rowData.groomId) {
          const festival = festivals.find(f => f.name === rowData.festivalName);
          newRegistrations.push({
            groomName: rowData.groomName,
            groomId: rowData.groomId,
            groomPhone: rowData.groomPhone || '',
            brideName: rowData.brideName || '',
            brideId: rowData.brideId || '',
            bridePhone: rowData.bridePhone || '',
            festivalName: rowData.festivalName || '',
            festivalId: festival?.id || '',
            status: 'pending',
            paymentStatus: 'pending',
            createdAt: serverTimestamp(),
            internalNotes: []
          });
        }
      });

      if (newRegistrations.length > 0) {
        for (const reg of newRegistrations) {
          try {
            await addDoc(collection(db, 'registrations'), reg);
          } catch (error) {
            handleFirestoreError(error, OperationType.CREATE, 'registrations');
          }
        }
        setAlertMessage(`تم استيراد ${newRegistrations.length} طلب بنجاح`);
      } else {
        setAlertMessage('لم يتم العثور على بيانات صالحة للاستيراد. تأكد من تطابق أسماء الأعمدة.');
      }
    } catch (error) {
      console.error('Error importing Excel:', error);
      setAlertMessage('حدث خطأ أثناء استيراد الملف. تأكد من صحة التنسيق.');
    } finally {
      setIsImporting(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const updateRegStep = async (id: string, step: number) => {
    const reg = registrations.find(r => r.id === id);
    const oldStep = reg?.currentStep || 0;
    try {
      await updateDoc(doc(db, 'registrations', id), { currentStep: step });
      showToast('تم تحديث مرحلة الطلب بنجاح');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `registrations/${id}`);
    }
    
    // Record Audit Log
    try {
      await addDoc(collection(db, 'audit_logs'), {
        userId: auth.currentUser?.uid,
        userName: userProfile.email,
        action: 'تغيير مرحلة الطلب',
        registrationId: id,
        oldValue: oldStep.toString(),
        newValue: step.toString(),
        createdAt: serverTimestamp()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'audit_logs');
    }
  };

  const updateRegStatus = async (id: string, status: string, name?: string) => {
    if (status === 'rejected') {
      setRejectionModal({ id, name: name || '' });
      return;
    }
    if (status === 'needs_info') {
      setNeedsInfoModal({ id, name: name || '' });
      setNeedsInfoDeficiencies([]);
      return;
    }
    
    const reg = registrations.find(r => r.id === id);
    const oldStatus = reg?.status;
    try {
      await updateDoc(doc(db, 'registrations', id), { 
        status, 
        rejectionReason: null,
        deficiencies: status === 'needs_info' ? [] : (reg?.deficiencies || [])
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `registrations/${id}`);
    }
    
    // Record Audit Log
    try {
      await addDoc(collection(db, 'audit_logs'), {
        userId: auth.currentUser?.uid,
        userName: userProfile.email,
        action: 'تغيير حالة الطلب',
        registrationId: id,
        oldValue: oldStatus,
        newValue: status,
        createdAt: serverTimestamp()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'audit_logs');
    }

    // Send notification
    if (reg) {
      const festival = festivals.find(f => f.id === reg.festivalId);
      let statusText = '';
      if (status === 'approved') statusText = 'مقبول';
      else if (status === 'needs_info') statusText = 'نحتاج إلى مزيد من البيانات';
      else statusText = 'قيد المراجعة والدراسة';

      await notifyAdminsAndSupervisor(
        reg.festivalId,
        reg.festivalName,
        `تم تغيير حالة طلب ${reg.groomName} إلى ${statusText}`,
        'status_update',
        id,
        festival?.supervisorId
      );

      // Send SMS notification
      if (siteSettings.enableSmsNotifications && reg.groomPhone) {
        fetch('/api/send-sms', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            to: reg.groomPhone.startsWith('0') ? '+966' + reg.groomPhone.substring(1) : reg.groomPhone,
            message: `مرحباً ${reg.groomName}، تم تغيير حالة طلبك في مهرجان ${reg.festivalName} إلى: ${statusText}`
          })
        }).catch(err => console.error('Error sending SMS:', err));
      }

      // Send Email notification
      if (siteSettings.enableEmailNotifications && reg.groomEmail) {
        fetch('/api/send-email', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            to: reg.groomEmail,
            subject: `تحديث حالة طلبك في مهرجان ${reg.festivalName}`,
            text: `مرحباً ${reg.groomName}،\n\nتم تغيير حالة طلبك في مهرجان ${reg.festivalName} إلى: ${statusText}.\n\nشكراً لك.`
          })
        }).catch(err => console.error('Error sending Email:', err));
      }
    }
  };

  const updatePaymentStatus = async (id: string, paymentStatus: string) => {
    const reg = registrations.find(r => r.id === id);
    const oldStatus = reg?.paymentStatus;
    try {
      const paymentNote = paymentStatus === 'rejected' ? (reg.paymentNote || 'يرجى إرفاق إيصال جديد') : null;
      await updateDoc(doc(db, 'registrations', id), { 
        paymentStatus,
        paymentNote,
        updatedAt: serverTimestamp() 
      });
      showToast('تم تحديث حالة السداد بنجاح');
      
      // Send notification
      if (reg && (paymentStatus === 'paid' || paymentStatus === 'rejected')) {
        let statusText = paymentStatus === 'paid' ? 'تم قبول سداد الرسوم بنجاح' : `تم رفض إيصال السداد: ${paymentNote}`;
        
        await notifyAdminsAndSupervisor(
          reg.festivalId,
          reg.festivalName,
          `تحديث سداد لـ ${reg.groomName}: ${statusText}`,
          'payment_update',
          id
        );

        // Send Email notification
        if (siteSettings.enableEmailNotifications && reg.groomEmail) {
          fetch('/api/send-email', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              to: reg.groomEmail,
              subject: `تحديث حالة السداد - مهرجان ${reg.festivalName}`,
              text: `مرحباً ${reg.groomName}،\n\nيود فريق تنظيم مهرجان ${reg.festivalName} إشعاركم بآخر تحديث لحالة سداد الرسوم الخاصة بكم:\n\nالحالة: ${statusText}.\n\nشكراً لكم.`
            })
          }).catch(err => console.error('Error sending Email:', err));
        }

        // Send SMS notification
        if (siteSettings.enableSmsNotifications && reg.groomPhone) {
          fetch('/api/send-sms', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              to: reg.groomPhone.startsWith('0') ? '+966' + reg.groomPhone.substring(1) : reg.groomPhone,
              message: `مرحباً ${reg.groomName}، تحديث سداد في مهرجان ${reg.festivalName}: ${statusText}`
            })
          }).catch(err => console.error('Error sending SMS:', err));
        }
      }

      // Record Audit Log
      await addDoc(collection(db, 'audit_logs'), {
        userId: auth.currentUser?.uid,
        userName: userProfile.email,
        action: 'تغيير حالة السداد',
        registrationId: id,
        oldValue: oldStatus || 'pending',
        newValue: paymentStatus,
        createdAt: serverTimestamp()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `registrations/${id}`);
    }
  };

  const submitRejection = async () => {
    if (!rejectionModal) return;
    const reg = registrations.find(r => r.id === rejectionModal.id);
    const oldStatus = reg?.status;
    
    try {
      await updateDoc(doc(db, 'registrations', rejectionModal.id), { 
        status: 'rejected', 
        rejectionReason 
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `registrations/${rejectionModal.id}`);
    }

    // Record Audit Log
    try {
      await addDoc(collection(db, 'audit_logs'), {
        userId: auth.currentUser?.uid,
        userName: userProfile.email,
        action: 'رفض الطلب',
        registrationId: rejectionModal.id,
        oldValue: oldStatus,
        newValue: 'rejected',
        createdAt: serverTimestamp()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'audit_logs');
    }

    // Send notification
    if (reg) {
      const festival = festivals.find(f => f.id === reg.festivalId);
      await notifyAdminsAndSupervisor(
        reg.festivalId,
        reg.festivalName,
        `تم رفض طلب ${reg.groomName}. السبب: ${rejectionReason}`,
        'status_update',
        rejectionModal.id,
        festival?.supervisorId
      );

      // Send SMS notification
      if (siteSettings.enableSmsNotifications && reg.groomPhone) {
        fetch('/api/send-sms', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            to: reg.groomPhone.startsWith('0') ? '+966' + reg.groomPhone.substring(1) : reg.groomPhone,
            message: `مرحباً ${reg.groomName}، نعتذر لإبلاغك بأنه تم رفض طلبك في مهرجان ${reg.festivalName}. السبب: ${rejectionReason}`
          })
        }).catch(err => console.error('Error sending SMS:', err));
      }

      // Send Email notification
      if (siteSettings.enableEmailNotifications && reg.groomEmail) {
        fetch('/api/send-email', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            to: reg.groomEmail,
            subject: `تحديث حالة طلبك في مهرجان ${reg.festivalName}`,
            text: `مرحباً ${reg.groomName}،\n\nنعتذر لإبلاغك بأنه تم رفض طلبك في مهرجان ${reg.festivalName}.\n\nالسبب: ${rejectionReason}\n\nشكراً لتفهمك.`
          })
        }).catch(err => console.error('Error sending Email:', err));
      }
    }

    setRejectionModal(null);
    setRejectionReason('');
  };

  const submitNeedsInfo = async () => {
    if (!needsInfoModal) return;
    const reg = registrations.find(r => r.id === needsInfoModal.id);
    const oldStatus = reg?.status;
    
    try {
      await updateDoc(doc(db, 'registrations', needsInfoModal.id), { 
        status: 'needs_info',
        deficiencies: needsInfoDeficiencies,
        rejectionReason: null
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `registrations/${needsInfoModal.id}`);
    }

    // Record Audit Log
    try {
      await addDoc(collection(db, 'audit_logs'), {
        userId: auth.currentUser?.uid,
        userName: userProfile.email,
        action: 'تغيير حالة الطلب إلى نقص بيانات',
        registrationId: needsInfoModal.id,
        oldValue: oldStatus,
        newValue: 'needs_info',
        createdAt: serverTimestamp()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'audit_logs');
    }
    
    setNeedsInfoModal(null);
    setNeedsInfoDeficiencies([]);
  };

  const handleAddNote = async (regId: string) => {
    if (!newNoteText.trim()) return;
    if (newNoteType === 'task' && !assignedSupervisor) {
      setAlertMessage('الرجاء اختيار مشرف لإسناد المهمة إليه');
      return;
    }
    
    setIsAddingNote(true);
    try {
      const newNote: any = {
        id: Math.random().toString(36).substring(2, 9),
        text: newNoteText.trim(),
        createdBy: userProfile.email,
        createdAt: new Date(),
        type: newNoteType
      };

      if (newNoteType === 'task') {
        newNote.assignedTo = assignedSupervisor;
        newNote.status = 'pending';
      }
      
      await updateDoc(doc(db, 'registrations', regId), {
        internalNotes: arrayUnion(newNote)
      });
      
      // Update local state to show immediately
      if (selectedReg && selectedReg.id === regId) {
        setSelectedReg({
          ...selectedReg,
          internalNotes: [...(selectedReg.internalNotes || []), newNote]
        });
      }
      
      setNewNoteText('');
      setNewNoteType('note');
      setAssignedSupervisor('');
    } catch (error) {
      console.error('Error adding note:', error);
      setAlertMessage('حدث خطأ أثناء إضافة الملاحظة');
    } finally {
      setIsAddingNote(false);
    }
  };

  const handleToggleTaskStatus = async (regId: string, taskId: string, currentStatus: string) => {
    try {
      const reg = registrations.find(r => r.id === regId);
      if (!reg || !reg.internalNotes) return;

      const updatedNotes = reg.internalNotes.map((note: any) => {
        if (note.id === taskId && note.type === 'task') {
          return { ...note, status: currentStatus === 'pending' ? 'completed' : 'pending' };
        }
        return note;
      });

      await updateDoc(doc(db, 'registrations', regId), {
        internalNotes: updatedNotes
      });

      if (selectedReg && selectedReg.id === regId) {
        setSelectedReg({
          ...selectedReg,
          internalNotes: updatedNotes
        });
      }
    } catch (error) {
      console.error('Error toggling task status:', error);
      setAlertMessage('حدث خطأ أثناء تحديث حالة المهمة');
    }
  };

  const deleteFestival = async (id: string) => {
    await deleteDoc(doc(db, 'festivals', id));
    setDeleteConfirm(null);
  };

  const deleteSupervisor = async (id: string) => {
    const userDoc = await getDoc(doc(db, 'users', id));
    if (userDoc.exists() && userDoc.data().role === 'admin') {
      setAlertMessage('لا يمكن حذف مدير النظام');
      setDeleteConfirm(null);
      return;
    }
    await deleteDoc(doc(db, 'users', id));
    setDeleteConfirm(null);
  };

  const handleDeleteAttachment = async () => {
    if (!deleteAttachmentConfirm) return;
    const { regId, index, type } = deleteAttachmentConfirm;
    const reg = registrations.find(r => r.id === regId);
    if (!reg) return;

    try {
      if (type === 'attachment') {
        const newAttachments = [...(reg.attachments || [])];
        const attachmentToDelete = newAttachments[index];
        newAttachments.splice(index, 1);
        
        // Delete from Storage
        if (attachmentToDelete && attachmentToDelete.url) {
          try {
            const fileRef = ref(storage, attachmentToDelete.url);
            await deleteObject(fileRef);
          } catch (storageError) {
            console.error('Error deleting file from storage:', storageError);
            // Continue with Firestore update even if storage deletion fails
          }
        }

        await updateDoc(doc(db, 'registrations', regId), {
          attachments: newAttachments
        });
        if (selectedReg && selectedReg.id === regId) {
          setSelectedReg({ ...selectedReg, attachments: newAttachments });
        }
      } else if (type === 'paymentReceipt') {
        const receiptToDelete = reg.paymentReceipt;
        
        // Delete from Storage
        if (receiptToDelete && receiptToDelete.url) {
          try {
            const fileRef = ref(storage, receiptToDelete.url);
            await deleteObject(fileRef);
          } catch (storageError) {
            console.error('Error deleting receipt from storage:', storageError);
            // Continue with Firestore update even if storage deletion fails
          }
        }

        await updateDoc(doc(db, 'registrations', regId), {
          paymentReceipt: null
        });
        if (selectedReg && selectedReg.id === regId) {
          setSelectedReg({ ...selectedReg, paymentReceipt: null });
        }
      }
      setDeleteAttachmentConfirm(null);
      setAlertMessage('تم حذف المرفق بنجاح');
    } catch (error) {
      console.error('Error deleting attachment:', error);
      setAlertMessage('حدث خطأ أثناء حذف المرفق');
    }
  };

  const markNotifRead = async (id: string) => {
    await updateDoc(doc(db, 'notifications', id), { read: true });
  };

  const seedData = async () => {
    const names = [
      "مهرجان الزواج الجماعي الأول", "مهرجان الزواج الجماعي الثاني", "مهرجان الزواج الجماعي الثالث",
      "مهرجان الزواج الجماعي الرابع", "مهرجان الزواج الجماعي الخامس", "مهرجان الزواج الجماعي السادس",
      "مهرجان الزواج الجماعي السابع", "مهرجان الزواج الجماعي الثامن", "مهرجان الزواج الجماعي التاسع",
      "مهرجان الزواج الجماعي العاشر", "مهرجان الزواج الجماعي الحادي عشر", "مهرجان الزواج الجماعي الثاني عشر",
      "مهرجان الزواج الجماعي الثالث عشر", "مهرجان الزواج الجماعي الرابع عشر", "مهرجان الزواج الجماعي الخامس عشر",
      "مهرجان الزواج الجماعي السادس عشر", "مهرجان الزواج الجماعي السابع عشر", "مهرجان الزواج الجماعي الثامن عشر",
      "مهرجان الزواج الجماعي التاسع عشر", "مهرجان الزواج الجماعي العشرون", "مهرجان الزواج الجماعي الحادي والعشرون",
      "مهرجان الزواج الجماعي الثاني والعشرون", "مهرجان الزواج الجماعي الثالث والعشرون", "مهرجان الزواج الجماعي الرابع والعشرون"
    ];

    for (let i = 0; i < names.length; i++) {
      await addDoc(collection(db, 'festivals'), {
        name: names[i],
        date: `2026-0${(i % 9) + 1}-15`,
        fees: 500,
        isOpen: false,
        order: i + 1
      });
    }
    setShowSeedConfirm(false);
    setAlertMessage('تمت إضافة 24 مهرجان بنجاح.');
  };

  const assignedFestival = userProfile.role === 'supervisor' 
    ? festivals.find(f => f.id === userProfile.assignedFestivalId)
    : null;

  return (
    <>
      <div className={`space-y-4 sm:space-y-8 ${isPrinting ? 'no-print' : ''}`}>
      
      {/* Welcome Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-linear-to-br from-brand-600 to-brand-800 p-6 sm:p-8 rounded-[2rem] text-white shadow-xl shadow-brand-900/20">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 sm:w-20 sm:h-20 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center shrink-0 shadow-inner">
            {userProfile.photoURL ? (
              <img src={userProfile.photoURL} alt={userProfile.displayName} className="w-full h-full object-cover rounded-2xl" referrerPolicy="no-referrer" />
            ) : (
              <User size={32} className="text-white" />
            )}
          </div>
          <div>
            <h2 className="text-xl sm:text-3xl font-black tracking-tight mb-1">مرحباً، {userProfile.displayName}</h2>
            <p className="text-brand-100 font-bold text-xs sm:text-base opacity-90 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              {userProfile.role === 'admin' ? 'مدير النظام الكامل' : `مشرف مهرجان: ${assignedFestival ? assignedFestival.name : 'قيد الانتظار'}`}
            </p>
          </div>
        </div>
        {userProfile.role === 'supervisor' && assignedFestival && (
          <div className="flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-xl border border-white/10">
            <Calendar size={16} className="text-brand-200" />
            <span className="text-xs sm:text-sm font-black whitespace-nowrap">{assignedFestival.name}</span>
          </div>
        )}
      </div>

      {/* Toast Notifications Container */}
      <div className="fixed top-24 left-6 z-[100] flex flex-col gap-3 pointer-events-none w-80">
        <AnimatePresence>
          {toasts.map((toast, index) => (
            <ToastItem key={`${toast.id}-${index}`} toast={toast} onDismiss={() => dismissToast(toast.id)} />
          ))}
        </AnimatePresence>
      </div>

      {/* Dashboard Nav */}
      <div className="flex items-center justify-between gap-2 sm:gap-4 bg-white dark:bg-slate-900 p-1.5 sm:p-2 rounded-xl sm:rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800">
        <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 pb-1.5 sm:pb-0">
          <TabButton active={activeTab === 'registrations'} onClick={() => setActiveTab('registrations')} icon={<FileText size={18} />} label="الطلبات" />
          {userProfile.role === 'admin' && (
            <TabButton active={activeTab === 'festivals'} onClick={() => setActiveTab('festivals')} icon={<Calendar size={18} />} label="المهرجانات" />
          )}
          {(userProfile.role === 'admin' || userProfile.role === 'supervisor') && (
            <TabButton active={activeTab === 'gallery'} onClick={() => setActiveTab('gallery')} icon={<Image size={18} />} label="المعرض" />
          )}
          {(userProfile.role === 'admin' || userProfile.role === 'supervisor') && (
            <TabButton active={activeTab === 'testimonials'} onClick={() => setActiveTab('testimonials')} icon={<MessageSquareHeart size={18} />} label="قصص النجاح" />
          )}
          {(userProfile.role === 'admin' || userProfile.role === 'supervisor') && (
            <TabButton active={activeTab === 'vendors'} onClick={() => setActiveTab('vendors')} icon={<Gift size={18} />} label="عروض الشركاء" />
          )}
          {userProfile.role === 'admin' && (
            <TabButton active={activeTab === 'supervisors'} onClick={() => setActiveTab('supervisors')} icon={<Users size={18} />} label="المشرفين" />
          )}
          {(userProfile.role === 'admin' || userProfile.role === 'supervisor') && (
            <TabButton active={activeTab === 'courses'} onClick={() => setActiveTab('courses')} icon={<Award size={18} />} label="الدورات التأهيلية" />
          )}
          {userProfile.role === 'admin' && (
            <TabButton active={activeTab === 'logs'} onClick={() => setActiveTab('logs')} icon={<History size={18} />} label="سجل النشاطات" />
          )}
          {(userProfile.role === 'admin' || userProfile.role === 'supervisor') && (
            <TabButton active={activeTab === 'analytics'} onClick={() => setActiveTab('analytics')} icon={<LucideBarChart size={18} />} label="الإحصائيات" />
          )}
          {userProfile.role === 'admin' && (
            <TabButton active={activeTab === 'settings'} onClick={() => setActiveTab('settings')} icon={<Settings size={18} />} label="الإعدادات" />
          )}
        </div>

        {/* Notifications Bell */}
        <div className="relative px-2 sm:px-4">
          <button 
            onClick={() => setShowNotifications(!showNotifications)}
            className="p-2 sm:p-3 bg-slate-50 text-slate-600 rounded-lg sm:rounded-xl hover:bg-slate-100 transition relative"
          >
            <Bell size={18} className="sm:w-5 sm:h-5" />
            {notifications.length > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 sm:w-5 sm:h-5 bg-red-500 text-white text-[8px] sm:text-[10px] font-black rounded-full flex items-center justify-center border-2 border-white">
                {notifications.length}
              </span>
            )}
          </button>

          <AnimatePresence>
            {showNotifications && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="absolute left-0 top-full mt-2 w-80 bg-white rounded-2xl shadow-2xl border border-slate-100 z-50 overflow-hidden"
              >
                <div className="p-4 border-b border-slate-50 flex justify-between items-center">
                  <h4 className="font-black text-slate-900 text-base">الإشعارات</h4>
                  <button onClick={() => setShowNotifications(false)} className="text-slate-400 hover:text-slate-600">
                    <X size={16} />
                  </button>
                </div>
                <div className="max-h-80 overflow-y-auto">
                  {notifications.length === 0 ? (
                    <div className="p-8 text-center text-slate-400 text-sm font-bold">لا توجد إشعارات جديدة</div>
                  ) : (
                    notifications.map((n, i) => (
                      <div key={`notif-${n.id || i}`} className={`p-4 border-b border-slate-50 transition cursor-pointer ${!n.read ? 'bg-emerald-50/40 hover:bg-emerald-50' : 'hover:bg-slate-50'}`} onClick={async () => {
                        await markNotifRead(n.id);
                        const reg = registrations.find(r => r.id === n.registrationId);
                        if (reg) {
                          setHighlightPayment(n.type === 'payment_submitted');
                          setSelectedReg(reg);
                          setActiveTab('registrations');
                        } else {
                          // Fallback if data not yet in state
                          setActiveTab('registrations');
                          showToast('جاري تحويلك للطلب...', 'success');
                        }
                        setShowNotifications(false);
                      }}>
                        <div className="flex gap-3">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${n.type === 'payment_submitted' ? 'bg-amber-100 text-amber-600' : 'bg-brand-100 text-brand-600'}`}>
                            {n.type === 'payment_submitted' ? <CreditCard size={14} /> : <FileText size={14} />}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-black text-slate-800 leading-relaxed mb-0.5">{n.message}</p>
                            <div className="flex items-center gap-2">
                              <p className="text-xs text-slate-400 font-bold">{format(n.createdAt?.toDate() || new Date(), 'HH:mm - yyyy/MM/dd')}</p>
                              {!n.read && <span className="w-1.5 h-1.5 bg-brand-500 rounded-full animate-pulse" />}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Content */}
      <div className="bg-white rounded-2xl shadow-sm border border-stone-200 overflow-hidden">
        {activeTab === 'festivals' && userProfile.role === 'admin' && (
          <FestivalsTab
            festivals={festivals}
            registrations={registrations}
            userProfile={userProfile}
            updateFestivalName={updateFestivalName}
            updateFestivalDate={updateFestivalDate}
            updateFestivalEndDate={updateFestivalEndDate}
            updateFestivalFees={updateFestivalFees}
            updateFestivalSiblingPricing={updateFestivalSiblingPricing}
            updateFestivalArchiveStatus={updateFestivalArchiveStatus}
            setEditingSocialFestival={setEditingSocialFestival}
            setFestivalStatusConfirm={setFestivalStatusConfirm}
            setDeleteConfirm={setDeleteConfirm}
            setShowAddFestival={setShowAddFestival}
            setShowSeedConfirm={setShowSeedConfirm}
          />
        )}

        {activeTab === 'registrations' && (
          <div className="p-4 sm:p-8">
            {userProfile.role === 'supervisor' && !userProfile.assignedFestivalId ? (
              <div className="text-center py-12 bg-amber-50 rounded-3xl border border-amber-100">
                <div className="w-16 h-16 bg-amber-100 text-amber-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <AlertCircle size={32} />
                </div>
                <h4 className="text-xl font-black text-slate-900 mb-2">تنبيه: لم يتم تعيين مهرجان</h4>
                <p className="text-slate-500 font-bold text-base max-w-md mx-auto">عذراً، لم يتم تعيين مهرجان لك حتى الآن. يرجى التواصل مع مدير النظام لتعيين المهرجان المسؤول عنه لتتمكن من مراجعة الطلبات.</p>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-5 mb-8">
                  {[
                    { title: 'إجمالي الطلبات', value: statsRegistrations.length, icon: Users, color: 'text-blue-600', bg: 'bg-blue-50', border: 'border-blue-100', filterValue: 'all' },
                    { title: 'قيد المراجعة', value: statsRegistrations.filter(r => r.status === 'pending').length, icon: Clock, color: 'text-amber-600', bg: 'bg-amber-50', border: 'border-amber-100', filterValue: 'pending' },
                    { title: 'الطلبات المقبولة', value: statsRegistrations.filter(r => r.status === 'approved').length, icon: UserCheck, color: 'text-emerald-600', bg: 'bg-emerald-50', border: 'border-emerald-100', filterValue: 'approved' },
                    { title: 'بانتظار السداد', value: statsRegistrations.filter(r => r.paymentStatus === 'pending' || r.paymentStatus === 'pending_verification' || r.paymentStatus === 'rejected').length, icon: CreditCard, color: 'text-brand-600', bg: 'bg-brand-50', border: 'border-brand-100', filterValue: 'pending_payment' },
                    { title: 'الطلبات الناقصة', value: statsRegistrations.filter(r => r.status === 'needs_info').length, icon: AlertCircle, color: 'text-rose-600', bg: 'bg-rose-50', border: 'border-rose-100', filterValue: 'needs_info' },
                    { title: 'الطلبات المرفوضة', value: statsRegistrations.filter(r => r.status === 'rejected').length, icon: XCircle, color: 'text-red-600', bg: 'bg-red-50', border: 'border-red-100', filterValue: 'rejected' },
                  ].map((kpi, i) => {
                    const isActive = selectedStatusFilter === kpi.filterValue;
                    return (
                      <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.05 }}
                        key={`kpi-reg-${kpi.title}-${i}`} 
                        onClick={() => setSelectedStatusFilter(kpi.filterValue)}
                        className={`bg-white p-5 rounded-3xl border transition-all duration-300 flex items-center gap-4 group cursor-pointer active:scale-[0.98] select-none ${
                          isActive 
                            ? 'ring-2 ring-emerald-500 border-emerald-500 shadow-md scale-[1.02]' 
                            : `${kpi.border} shadow-sm hover:shadow-md hover:border-slate-300`
                        }`}
                      >
                        <div className={`p-3.5 rounded-2xl ${kpi.bg} ${kpi.color} group-hover:scale-110 transition-transform duration-300`}>
                          <kpi.icon size={22} />
                        </div>
                        <div>
                          <p className="text-xs font-black text-slate-400 uppercase tracking-wider mb-0.5">{kpi.title}</p>
                          <p className="text-3xl font-black text-slate-900 leading-none">{kpi.value}</p>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>

                <div className="flex flex-col xl:flex-row xl:justify-between xl:items-center gap-5 mb-8 bg-slate-50/50 p-4 sm:p-6 rounded-[2rem] border border-slate-100/80">
                  <div className="flex flex-col gap-1">
                    <h3 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">طلبات التسجيل</h3>
                    <p className="text-slate-500 font-bold text-sm">إجمالي الطلبات المتاحة حالياً: {filteredRegistrations.length}</p>
                  </div>
                  
                  <div className="flex flex-col lg:flex-row gap-3 w-full xl:w-auto">
                    <div className="relative group w-full lg:w-64">
                      <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-emerald-500 transition-colors" size={16} />
                      <input 
                        type="text"
                        placeholder="بحث عن عريس بالاسم أو الهوية..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="bg-white border border-slate-200 pr-10 pl-3 py-2.5 rounded-xl font-bold text-xs focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all w-full outline-none shadow-sm"
                      />
                    </div>
                    
                    <div className="flex gap-2 w-full lg:w-auto">
                      <select 
                        value={selectedStatusFilter}
                        onChange={(e) => setSelectedStatusFilter(e.target.value)}
                        className="bg-white border border-slate-200 px-3 py-2.5 rounded-xl font-bold text-xs focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all w-full lg:w-36 outline-none shadow-sm cursor-pointer"
                      >
                        <option value="all">كل الحالات</option>
                        <option value="pending">قيد المراجعة</option>
                        <option value="approved">مقبول</option>
                        <option value="pending_payment">بانتظار السداد</option>
                        <option value="needs_info">الطلبات الناقصة</option>
                        <option value="rejected">مرفوض</option>
                      </select>
                      
                      <div className="flex items-center gap-2">
                        <button 
                          onClick={exportToExcel}
                          className="bg-emerald-600 text-white px-4 py-2.5 rounded-xl font-black text-xs flex items-center justify-center gap-2 hover:bg-emerald-700 transition shadow-lg shadow-emerald-200/50 whitespace-nowrap"
                        >
                          <Download size={14} /> تصدير
                        </button>
                        
                        {(userProfile.role === 'admin' || userProfile.role === 'supervisor') && (
                          <div className="relative group">
                            <button 
                              className="bg-white text-slate-600 px-3 py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 hover:bg-slate-50 transition border border-slate-200 shadow-sm"
                              title="المزيد من الأدوات"
                            >
                              <Settings size={14} />
                            </button>
                            <div className="absolute left-0 top-full mt-2 w-48 bg-white border border-slate-100 rounded-2xl shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50 p-2 space-y-1">
                              <button 
                                onClick={() => setShowReminderModal(true)}
                                className="w-full text-right bg-amber-50 text-amber-600 px-3 py-2 rounded-lg font-bold text-xs flex items-center gap-2 hover:bg-amber-100 transition"
                              >
                                <Bell size={14} /> تذكير المتأخرين ({getOverdueRegistrations().length})
                              </button>
                              <button 
                                onClick={() => fileInputRef.current?.click()}
                                disabled={isImporting}
                                className="w-full text-right bg-blue-50 text-blue-600 px-3 py-2 rounded-lg font-bold text-xs flex items-center gap-2 hover:bg-blue-100 transition whitespace-nowrap"
                              >
                                <FileText size={14} /> {isImporting ? 'جاري الاستيراد...' : 'استيراد Excel'}
                              </button>
                              <button 
                                onClick={downloadExcelTemplate}
                                className="w-full text-right bg-slate-50 text-slate-600 px-3 py-2 rounded-lg font-bold text-xs flex items-center gap-2 hover:bg-slate-100 transition"
                              >
                                <FileText size={14} /> تحميل النموذج
                              </button>
                              <button 
                                onClick={() => setShowFullReportPrint(true)}
                                className="w-full text-right bg-slate-900 text-white px-3 py-2 rounded-lg font-bold text-xs flex items-center gap-2 hover:bg-slate-800 transition shadow-sm"
                              >
                                <Printer size={14} /> طباعة التقرير
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {userProfile.role === 'admin' && (
                  <div className="flex items-center gap-2 mb-8 overflow-x-auto pb-2 scrollbar-hide">
                    <button
                      onClick={() => setSelectedFestivalFilter('all')}
                      className={`px-4 py-2 rounded-full text-xs font-black transition-all shrink-0 ${
                        selectedFestivalFilter === 'all' 
                        ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-100' 
                        : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                      }`}
                    >
                      الكل
                    </button>
                    {festivals.map((f, i) => (
                      <button
                        key={`fest-filt-${f.id || i}-${i}`}
                        onClick={() => setSelectedFestivalFilter(f.id)}
                        className={`px-4 py-2 rounded-full text-xs font-black transition-all shrink-0 ${
                          selectedFestivalFilter === f.id 
                          ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-100' 
                          : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                        }`}
                      >
                        {f.name}
                      </button>
                    ))}
                  </div>
                )}

                {selectedRegistrations.size > 0 && (
                  <div className="flex flex-wrap items-center gap-3 mb-6 p-4 bg-slate-50 rounded-2xl border border-slate-100 shadow-sm">
                    <div className="flex items-center gap-2 border-l border-slate-200 pl-3 ml-1">
                      <span className="text-xs font-black text-slate-900">تم اختيار {selectedRegistrations.size} طلب</span>
                    </div>
                    
                    <div className="flex flex-wrap items-center gap-2">
                      {(userProfile.role === 'admin' || userProfile.role === 'supervisor') && (
                        <button 
                          onClick={() => performBulkAction('mark_paid')} 
                          className="bg-brand-600 text-white px-4 py-2 rounded-xl text-xs font-bold hover:bg-brand-700 transition shadow-sm flex items-center gap-1.5"
                        >
                          <CreditCard size={14} /> تأكيد سداد المختار
                        </button>
                      )}
                      
                      {userProfile.role === 'admin' && (
                        <div className="flex items-center gap-2 bg-white border border-slate-200 p-1 rounded-xl">
                          <select 
                            value={bulkTargetFestival}
                            onChange={(e) => setBulkTargetFestival(e.target.value)}
                            className="bg-transparent px-2 py-1 rounded-lg text-xs font-bold outline-none focus:ring-0 w-32 sm:w-40"
                          >
                            <option value="">نقل إلى مهرجان...</option>
                            {festivals.map((f, i) => (
                              <option key={`${f.id || `f-${i}`}-${i}`} value={f.id}>{f.name}</option>
                            ))}
                          </select>
                          <button 
                            onClick={bulkTransfer}
                            disabled={!bulkTargetFestival}
                            className="bg-blue-600 text-white px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition"
                          >
                            نقل
                          </button>
                        </div>
                      )}

                      {(userProfile.role === 'admin' || userProfile.role === 'supervisor') && (
                        <button 
                          onClick={() => setShowBulkDeleteConfirm(true)} 
                          className="bg-slate-200 text-slate-600 px-4 py-2 rounded-xl text-xs font-bold hover:bg-red-50 hover:text-red-600 transition flex items-center gap-1.5"
                        >
                          <Trash2 size={14} /> حذف المختار
                        </button>
                      )}

                      <button 
                        onClick={() => setSelectedRegistrations(new Set())} 
                        className="text-slate-400 hover:text-slate-600 px-2 py-2 text-xs font-bold transition"
                      >
                        إلغاء التحديد
                      </button>
                    </div>
                  </div>
                )}

                <div className="flex flex-col lg:flex-row gap-6">
                  <div className={`flex-1 ${selectedReg ? 'hidden lg:block' : 'block'}`}>
                    <div className="overflow-x-auto">
                  {/* Mobile Cards View */}
                  <div className="block sm:hidden space-y-4">
                    {paginatedRegistrations.length === 0 ? (
                      <div className="py-12 text-center bg-slate-50 rounded-2xl border border-slate-100">
                        <div className="flex flex-col items-center gap-2 text-slate-400">
                          <FileText size={32} className="opacity-20" />
                          <p className="text-sm font-bold">لا توجد طلبات تطابق معايير البحث</p>
                        </div>
                      </div>
                    ) : (
                      paginatedRegistrations.map((r, i) => (
                        <RegistrationCard 
                          key={`${r.id}-${i}`} 
                          registration={r} 
                          selected={selectedRegistrations.has(r.id)}
                          onToggleSelect={toggleSelect}
                          onUpdateStatus={updateRegStatus}
                          onUpdateStep={updateRegStep}
                          userProfile={userProfile}
                          festivals={festivals}
                          onViewDetails={(r) => setSelectedReg(r)}
                          onPrint={(r) => { setPrintingReg(r); setShowPrintPreview(true); }}
                          onEdit={(r) => onEditRegistration?.(r)}
                          onShowLogs={(id) => setShowLogsModal(id)}
                          onWhatsAppReminder={sendWhatsAppReminder}
                          onEmailReminder={sendEmailReminder}
                        />
                      ))
                    )}
                  </div>

                  {/* Desktop Table View */}
                  <div className="hidden sm:block overflow-hidden bg-white rounded-3xl border border-slate-100 shadow-sm transition-all duration-300">
                    <table className="w-full text-right border-collapse">
                      <thead>
                        <tr className="bg-slate-50/50 border-b border-slate-100">
                          <th className="px-6 py-5 font-black text-slate-400 text-xs w-12">
                            <div className="flex items-center justify-center">
                              <input 
                                type="checkbox" 
                                checked={selectedRegistrations.size === filteredRegistrations.length && filteredRegistrations.length > 0} 
                                onChange={toggleSelectAll}
                                className="rounded text-emerald-600 focus:ring-emerald-500/20 w-4 h-4 cursor-pointer"
                              />
                            </div>
                          </th>
                          <th className="px-4 py-5 font-black text-slate-400 text-xs cursor-pointer group transition-colors" onClick={() => requestSort('groomName')}>
                            <div className="flex items-center gap-1.5 hover:text-slate-600 transition-colors">
                              العريس <LucideBarChart size={12} className="opacity-0 group-hover:opacity-100 transition-opacity rotate-90" />
                            </div>
                          </th>
                          <th className="px-4 py-5 font-black text-slate-400 text-xs">المهرجان</th>
                          <th className="px-4 py-5 font-black text-slate-400 text-xs cursor-pointer" onClick={() => requestSort('createdAt')}>التاريخ</th>
                          <th className="px-4 py-5 font-black text-slate-400 text-xs">الحالة</th>
                          <th className="px-4 py-5 font-black text-slate-400 text-xs">المرحلة</th>
                          <th className="px-4 py-5 font-black text-slate-400 text-xs">حالة السداد</th>
                          <th className="px-4 py-5 font-black text-slate-400 text-xs text-center">الإجراءات</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-50">
                        {filteredRegistrations.length === 0 ? (
                          <tr>
                            <td colSpan={8} className="py-24 text-center">
                              <div className="flex flex-col items-center gap-3">
                                <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-200 mb-2">
                                  <FileText size={32} />
                                </div>
                                <p className="text-slate-400 font-black text-sm">لا توجد طلبات تطابق معايير البحث</p>
                                <button 
                                  onClick={() => { setSearchTerm(''); setSelectedStatusFilter('all'); setSelectedFestivalFilter('all'); }}
                                  className="text-emerald-600 font-bold text-xs hover:underline"
                                >
                                  إعادة ضبط الفلاتر
                                </button>
                              </div>
                            </td>
                          </tr>
                        ) : (
                          paginatedRegistrations.map((r, i) => (
                            <motion.tr 
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              transition={{ delay: i * 0.03 }}
                              key={`reg-row-${r.id || `temp-${i}`}-${i}`} 
                              className={`group hover:bg-slate-50/80 transition-all duration-200 ${selectedRegistrations.has(r.id) ? 'bg-emerald-50/30' : (siblingGroups.has(r.groomId) ? siblingGroupColors[siblingGroups.get(r.groomId)! % siblingGroupColors.length] : '')}`}
                            >
                              <td className="px-6 py-4">
                                <div className="flex items-center justify-center">
                                  <input 
                                    type="checkbox" 
                                    checked={selectedRegistrations.has(r.id)} 
                                    onChange={() => toggleSelect(r.id)}
                                    className="rounded text-emerald-600 focus:ring-emerald-500/20 w-4 h-4 cursor-pointer"
                                  />
                                </div>
                              </td>
                              <td className="px-4 py-4">
                                <div className="flex flex-col">
                                  <div className="flex items-center gap-2 mb-1">
                                    <div className="flex items-center gap-2">
                                      <div className="font-black text-slate-900 text-sm">{r.groomName}</div>
                                      {r.hasSibling && (
                                        <div className="flex items-center gap-1 bg-emerald-50 text-emerald-600 text-[9px] font-black px-2 py-0.5 rounded-md border border-emerald-200/50 transition-colors group-hover:bg-emerald-100 shadow-sm" title="طلب عائلي مترابط">
                                          <Users size={10} />
                                        </div>
                                      )}
                                    </div>
                                    <div className="flex gap-1.5 translate-y-[1px]">
                                      {r.attachments && r.attachments.length > 0 && (
                                        <div className="flex items-center gap-1 bg-slate-100 text-slate-500 text-[9px] font-black px-2 py-0.5 rounded-md border border-slate-200/50 transition-colors group-hover:bg-blue-100 group-hover:text-blue-600 shadow-sm" title={`يوجد ${r.attachments.length} مرفقات`}>
                                          <Paperclip size={10} />
                                          <span>{r.attachments.length}</span>
                                        </div>
                                      )}
                                      {r.internalNotes && r.internalNotes.length > 0 && (
                                        <div className="w-1.5 h-1.5 bg-brand-500 rounded-full" title="توجد ملاحظات سبر" />
                                      )}
                                    </div>
                                  </div>
                                  <div className="flex items-center gap-1.5">
                                    <span className="text-[10px] text-slate-400 font-bold font-mono tracking-tight">{r.groomId}</span>
                                    <div className="w-1 h-1 bg-slate-200 rounded-full" />
                                    <span className="text-[10px] text-slate-400 font-bold">{r.groomPhone}</span>
                                  </div>
                                </div>
                              </td>
                              <td className="px-4 py-4">
                                <div className="flex flex-col">
                                  <span className="text-[11px] font-black text-slate-900 leading-tight">{r.festivalName}</span>
                                  <span className="text-[9px] text-slate-400 font-bold mt-0.5">الدورة العاشرة</span>
                                </div>
                              </td>
                              <td className="px-4 py-4">
                                <div className="flex flex-col">
                                  <span className="text-[11px] font-black text-slate-600 tracking-tight">
                                    {r.createdAt?.toDate ? format(r.createdAt.toDate(), 'yyyy/MM/dd') : '-'}
                                  </span>
                                  <span className="text-[9px] text-slate-400 font-bold mt-0.5">
                                    {r.createdAt?.toDate ? format(r.createdAt.toDate(), 'HH:mm') : '-'}
                                  </span>
                                </div>
                              </td>
                              <td className="px-4 py-4">
                                <div className="relative group/status rounded-lg overflow-hidden">
                                  <select 
                                    value={r.status} 
                                    onChange={(e) => updateRegStatus(r.id, e.target.value, r.groomName)}
                                    className={`text-[10px] font-black rounded-xl px-3 py-1.5 border-none focus:ring-2 focus:ring-offset-1 transition-all cursor-pointer w-full appearance-none pr-3 pl-6 ${
                                      r.status === 'approved' ? 'bg-emerald-50 text-emerald-700 focus:ring-emerald-500/20' : 
                                      r.status === 'rejected' ? 'bg-rose-50 text-rose-700 focus:ring-rose-500/20' : 
                                      r.status === 'needs_info' ? 'bg-amber-50 text-amber-700 focus:ring-amber-500/20' :
                                      'bg-blue-50 text-blue-700 focus:ring-blue-500/20'
                                    }`}
                                  >
                                    <option value="pending">قيد الدراسة</option>
                                    <option value="needs_info">نقص بيانات</option>
                                    <option value="approved">مقبول نهائياً</option>
                                    <option value="rejected">مرفوض</option>
                                  </select>
                                  <div className="absolute left-2 top-1/2 -translate-y-1/2 pointer-events-none opacity-50">
                                    <ChevronLeft size={10} className="-rotate-90" />
                                  </div>
                                </div>
                              </td>
                              <td className="px-4 py-4">
                                <div className="relative group/step rounded-lg overflow-hidden">
                                  <select 
                                    value={r.currentStep || 0} 
                                    onChange={(e) => updateRegStep(r.id, Number(e.target.value))}
                                    className="text-[10px] font-black rounded-xl px-3 py-1.5 border border-slate-100 focus:ring-2 focus:ring-offset-1 focus:ring-slate-100 transition-all cursor-pointer w-full bg-white text-slate-700 appearance-none pr-3 pl-6 shadow-sm"
                                  >
                                    {(r.status === 'approved') ? (
                                      <option value={3}>الموافقة النهائية</option>
                                    ) : (r.status === 'pending' || r.status === 'needs_info') ? (
                                      <>
                                        <option value={0}>استلام الطلب</option>
                                        <option value={1}>تدقيق الطلب</option>
                                        <option value={2}>مراجعة السداد</option>
                                      </>
                                    ) : (
                                      <>
                                        <option value={0}>استلام الطلب</option>
                                        <option value={1}>تدقيق الطلب</option>
                                        <option value={2}>مراجعة السداد</option>
                                        <option value={3}>الموافقة النهائية</option>
                                      </>
                                    )}
                                  </select>
                                  <div className="absolute left-2 top-1/2 -translate-y-1/2 pointer-events-none opacity-30">
                                    <ChevronLeft size={10} className="-rotate-90" />
                                  </div>
                                </div>
                              </td>
                              <td className="px-4 py-4">
                                <div className="relative group/payment rounded-lg overflow-hidden">
                                  <select 
                                    value={r.paymentStatus || 'pending'}
                                    onChange={(e) => updatePaymentStatus(r.id, e.target.value)}
                                    className={`text-[10px] font-black rounded-xl px-3 py-1.5 border border-transparent focus:ring-2 focus:ring-offset-1 transition-all cursor-pointer w-full appearance-none pr-3 pl-6 ${
                                      r.paymentStatus === 'paid' ? 'text-emerald-700 bg-emerald-50/50 border-emerald-100 focus:ring-emerald-500/20' :
                                      r.paymentStatus === 'rejected' ? 'text-rose-700 bg-rose-50/50 border-rose-100 focus:ring-rose-500/20' :
                                      r.paymentStatus === 'pending_verification' ? 'text-amber-700 bg-amber-50/50 border-amber-100 focus:ring-amber-500/20' :
                                      'text-slate-600 bg-slate-50 border-slate-100 focus:ring-slate-200/20'
                                    }`}
                                  >
                                    <option value="pending">بانتظار السداد</option>
                                    <option value="pending_verification">وصل مرفوع</option>
                                    <option value="paid">تم السداد</option>
                                    <option value="rejected">وصل غير صالح</option>
                                  </select>
                                  <div className="absolute left-2 top-1/2 -translate-y-1/2 pointer-events-none opacity-30">
                                    <ChevronLeft size={10} className="-rotate-90" />
                                  </div>
                                </div>
                              </td>
                              <td className="px-4 py-4">
                                <div className="flex items-center justify-center gap-1.5">
                                  <button onClick={() => setSelectedReg(r)} className="p-2 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-xl transition-all duration-200" title="عرض التفاصيل">
                                    <Eye size={16} />
                                  </button>
                                  
                                  <div className="relative group/more">
                                    <button className="p-2 text-slate-400 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-all duration-200">
                                      <Settings size={16} />
                                    </button>
                                    <div className="absolute left-1/2 -translate-x-1/2 top-full mt-1 w-40 bg-white border border-slate-100 rounded-2xl shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50 p-1.5 space-y-0.5 pointer-events-none group-hover:pointer-events-auto">
                                      <button 
                                        onClick={() => { setPrintingReg(r); setShowPrintPreview(true); }} 
                                        className="w-full text-right text-slate-600 hover:bg-slate-50 px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-2 transition"
                                      >
                                        <Printer size={14} className="opacity-60" /> طباعة
                                      </button>
                                      <button 
                                        onClick={() => onEditRegistration?.(r)}
                                        className="w-full text-right text-slate-600 hover:bg-slate-50 px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-2 transition"
                                      >
                                        <Edit size={14} className="opacity-60" /> تعديل
                                      </button>
                                      {userProfile.role === 'admin' && (
                                        <button 
                                          onClick={() => setShowLogsModal(r.id)}
                                          className="w-full text-right text-slate-600 hover:bg-slate-50 px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-2 transition"
                                        >
                                          <History size={14} className="opacity-60" /> السجل
                                        </button>
                                      )}
                                      <div className="h-px bg-slate-50 my-1 mx-2" />
                                      <button 
                                        onClick={() => sendWhatsAppReminder(r)}
                                        className="w-full text-right text-emerald-600 hover:bg-emerald-50 px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-2 transition"
                                      >
                                        <MessageCircle size={14} /> تذكير واتساب
                                      </button>
                                      <button 
                                        onClick={() => sendEmailReminder(r)}
                                        className="w-full text-right text-blue-600 hover:bg-blue-50 px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-2 transition"
                                      >
                                        <Mail size={14} /> تذكير بريد
                                      </button>
                                    </div>
                                  </div>
                                </div>
                              </td>
                            </motion.tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                  {totalPages > 1 && (
                    <div className="flex justify-center items-center gap-2 mt-6">
                      <button 
                        onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                        disabled={currentPage === 1}
                        className="px-4 py-2 bg-slate-100 rounded-lg font-bold text-sm disabled:opacity-50"
                      >
                        السابق
                      </button>
                      <span className="text-sm font-bold">صفحة {currentPage} من {totalPages}</span>
                      <button 
                        onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                        disabled={currentPage === totalPages}
                        className="px-4 py-2 bg-slate-100 rounded-lg font-bold text-sm disabled:opacity-50"
                      >
                        التالي
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* Desktop Details View */}
              {selectedReg && (
                <div className="hidden lg:block w-96 shrink-0">
                  <RegistrationDetails 
                    registration={selectedReg} 
                    onClose={() => setSelectedReg(null)} 
                    onPrint={() => { setPrintingReg(selectedReg); setShowPrintPreview(true); }}
                    isPrinting={isPrinting}
                    siteSettings={siteSettings}
                  />
                </div>
              )}
            </div>
              </>
            )}
          </div>
        )}

        {activeTab === 'supervisors' && userProfile.role === 'admin' && (
          <SupervisorsTab
            supervisors={supervisors}
            festivals={festivals}
            setShowAddSupervisor={setShowAddSupervisor}
            setEditingSupervisor={setEditingSupervisor}
            setDeleteConfirm={setDeleteConfirm}
          />
        )}

        {activeTab === 'gallery' && (userProfile.role === 'admin' || userProfile.role === 'supervisor') && (
          <div className="p-4 sm:p-8">
            <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4 mb-6 sm:mb-8">
              <div>
                <h3 className="text-xl sm:text-2xl font-black text-slate-900">إدارة معرض الصور</h3>
                <p className="text-xs sm:text-sm text-slate-400 font-bold">إضافة وحذف الصور المعروضة في الصفحة الرئيسية (بحد أقصى 4 صور)</p>
              </div>
              {userProfile.role === 'admin' && (
                <label className="bg-emerald-600 text-white px-4 sm:px-6 py-2 rounded-lg sm:rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 hover:bg-emerald-700 transition cursor-pointer shadow-lg shadow-emerald-100">
                  <Plus size={16} className="sm:w-[18px] sm:h-[18px]" /> رفع صورة
                  <input 
                    type="file" 
                    accept="image/*" 
                    className="hidden" 
                    onChange={async (e) => {
                      const file = e.target.files?.[0];
                      if (!file) return;
                      
                      try {
                        const compressedFile = await imageCompression(file, { maxSizeMB: 1, maxWidthOrHeight: 1920 });
                        const storageRef = ref(storage, `gallery/${Date.now()}_${compressedFile.name}`);
                        await uploadBytes(storageRef, compressedFile);
                        const url = await getDownloadURL(storageRef);
                        await addDoc(collection(db, 'gallery'), {
                          url: url,
                          name: compressedFile.name,
                          createdAt: serverTimestamp()
                        });
                        setAlertMessage('تم رفع الصورة بنجاح');
                      } catch (error) {
                        console.error('Error uploading image:', error);
                        setAlertMessage('فشل رفع الصورة.');
                      }
                    }} 
                  />
                </label>
              )}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
              {galleryImages.map((img, i) => (
                <div key={`img-${img.id || i}`} className="group relative aspect-square rounded-2xl overflow-hidden border border-slate-100 bg-slate-50">
                  <img 
                    src={img.url} 
                    alt={img.name} 
                    className="w-full h-full object-cover transition duration-500 group-hover:scale-110"
                    referrerPolicy="no-referrer"
                  />
                  {userProfile.role === 'admin' && (
                    <div className="absolute inset-0 bg-slate-900/40 opacity-0 group-hover:opacity-100 transition flex items-center justify-center gap-3">
                      <label className="p-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition shadow-xl cursor-pointer" title="تعديل الصورة">
                        <Edit size={20} />
                        <input 
                          type="file" 
                          accept="image/*" 
                          className="hidden" 
                          onChange={async (e) => {
                            const file = e.target.files?.[0];
                            if (!file) return;
                            
                            try {
                              const compressedFile = await imageCompression(file, { maxSizeMB: 1, maxWidthOrHeight: 1920 });
                              const storageRef = ref(storage, `gallery/${Date.now()}_${compressedFile.name}`);
                              await uploadBytes(storageRef, compressedFile);
                              const url = await getDownloadURL(storageRef);
                              await updateDoc(doc(db, 'gallery', img.id), {
                                url: url,
                                name: compressedFile.name
                              });
                              setAlertMessage('تم تعديل الصورة بنجاح');
                            } catch (error) {
                              console.error('Error updating image:', error);
                              setAlertMessage('فشل تعديل الصورة.');
                            }
                          }} 
                        />
                      </label>
                      <button 
                        onClick={() => setImageToDelete({ id: img.id, name: img.name })}
                        className="p-3 bg-red-600 text-white rounded-xl hover:bg-red-700 transition shadow-xl"
                        title="حذف الصورة"
                      >
                        <Trash2 size={20} />
                      </button>
                    </div>
                  )}
                </div>
              ))}
              {galleryImages.length === 0 && (
                <div className="col-span-full py-20 text-center bg-slate-50 rounded-3xl border-2 border-dashed border-slate-200">
                  <Image size={48} className="mx-auto text-slate-200 mb-4" />
                  <p className="text-slate-400 font-bold">لا توجد صور في المعرض حالياً</p>
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'testimonials' && (userProfile.role === 'admin' || userProfile.role === 'supervisor') && (
          <div className="p-4 sm:p-8">
            <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4 mb-6 sm:mb-8">
              <div>
                <h3 className="text-xl sm:text-2xl font-black text-slate-900">قصص النجاح</h3>
                <p className="text-xs sm:text-sm text-slate-400 font-bold">إدارة تجارب الأزواج المستفيدين من الجمعية لعرضها في الصفحة الرئيسية</p>
              </div>
              {userProfile.role === 'admin' && (
                <button 
                  onClick={() => setShowAddTestimonial(true)}
                  className="bg-emerald-600 text-white px-4 sm:px-6 py-2 rounded-lg sm:rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 hover:bg-emerald-700 transition shadow-lg shadow-emerald-100"
                >
                  <Plus size={16} className="sm:w-[18px] sm:h-[18px]" /> إضافة قصة نجاح
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
              {testimonials.map((testimonial, i) => (
                <div key={`testimonial-${testimonial.id || i}`} className="bg-slate-50 p-6 rounded-2xl border border-slate-100 relative group">
                  <div className="flex justify-between items-start mb-4">
                    <h4 className="font-black text-slate-900 text-lg">{testimonial.coupleName}</h4>
                    {userProfile.role === 'admin' && (
                      <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button 
                          onClick={() => setEditingTestimonial(testimonial)}
                          className="p-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 transition"
                          title="تعديل"
                        >
                          <Edit size={16} />
                        </button>
                        <button 
                          onClick={() => setDeleteConfirm({ type: 'testimonial', id: testimonial.id })}
                          className="p-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition"
                          title="حذف"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    )}
                  </div>
                  <p className="text-slate-600 text-sm leading-relaxed mb-4 line-clamp-4">{testimonial.story}</p>
                  <div className="flex items-center justify-between mt-auto pt-4 border-t border-slate-200">
                    <span className="text-xs text-slate-400 font-bold">
                      {testimonial.createdAt?.toDate ? format(testimonial.createdAt.toDate(), 'yyyy/MM/dd') : ''}
                    </span>
                    {userProfile.role === 'admin' ? (
                      <button 
                        onClick={async () => {
                          await updateDoc(doc(db, 'testimonials', testimonial.id), { isActive: !testimonial.isActive });
                        }}
                        className={`text-xs font-bold px-3 py-1 rounded-full transition ${testimonial.isActive ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-200 text-slate-600'}`}
                      >
                        {testimonial.isActive ? 'نشط (معروض)' : 'مخفي'}
                      </button>
                    ) : (
                      <span className={`text-xs font-bold px-3 py-1 rounded-full transition ${testimonial.isActive ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-200 text-slate-600'}`}>
                        {testimonial.isActive ? 'نشط (معروض)' : 'مخفي'}
                      </span>
                    )}
                  </div>
                </div>
              ))}
              {testimonials.length === 0 && (
                <div className="col-span-full py-20 text-center bg-slate-50 rounded-3xl border-2 border-dashed border-slate-200">
                  <MessageSquareHeart size={48} className="mx-auto text-slate-200 mb-4" />
                  <p className="text-slate-400 font-bold">لا توجد قصص نجاح مضافة حالياً</p>
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'logs' && userProfile.role === 'admin' && (
          <div className="p-4 sm:p-8">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
              <div>
                <h3 className="text-xl sm:text-2xl font-black text-slate-900">سجل النشاطات بالكامل</h3>
                <p className="text-xs sm:text-sm text-slate-400 font-bold">متابعة كافة الحركات والعمليات التي تمت في النظام</p>
              </div>
              <div className="flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto">
                <div className="relative w-full sm:w-64">
                  <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input 
                    type="text"
                    placeholder="بحث في السجلات..."
                    value={logsSearchTerm}
                    onChange={(e) => setLogsSearchTerm(e.target.value)}
                    className="w-full pr-10 pl-4 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                  />
                </div>
                <span className="text-xs font-bold text-slate-400 whitespace-nowrap">إجمالي العمليات: {auditLogs.length}</span>
              </div>
            </div>
            
            <div className="bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-right border-collapse">
                  <thead>
                    <tr className="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800">
                      <th className="py-4 px-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">الوقت</th>
                      <th className="py-4 px-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">المستخدم</th>
                      <th className="py-4 px-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">العملية</th>
                      <th className="py-4 px-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">ملاحظات</th>
                      <th className="py-4 px-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">تفاصيل</th>
                    </tr>
                  </thead>
                  <tbody>
                    {auditLogs
                      .filter(log => 
                        !logsSearchTerm || 
                        log.action?.toLowerCase().includes(logsSearchTerm.toLowerCase()) ||
                        log.userName?.toLowerCase().includes(logsSearchTerm.toLowerCase()) ||
                        log.notes?.toLowerCase().includes(logsSearchTerm.toLowerCase()) ||
                        String(log.newValue || '').toLowerCase().includes(logsSearchTerm.toLowerCase())
                      )
                      .slice(0, 100)
                      .map((log, i) => (
                      <tr key={`log-${log.id || `temp-${i}`}`} className="border-b border-slate-100 dark:border-slate-800/50 hover:bg-slate-50/50 dark:hover:bg-slate-800/20 transition-colors">
                        <td className="py-4 px-6 whitespace-nowrap">
                          <div className="flex flex-col">
                            <span className="text-sm font-black text-slate-700 dark:text-slate-300">
                              {log.createdAt?.toDate ? format(log.createdAt.toDate(), 'yyyy/MM/dd') : 'نظامي'}
                            </span>
                            <span className="text-[10px] text-slate-400 font-bold">
                              {log.createdAt?.toDate ? format(log.createdAt.toDate(), 'HH:mm:ss') : ''}
                            </span>
                          </div>
                        </td>
                        <td className="py-4 px-6">
                          <div className="flex items-center gap-2">
                            <div className="w-7 h-7 bg-brand-100 dark:bg-brand-900/30 text-brand-600 dark:text-brand-400 rounded-lg flex items-center justify-center text-[10px] font-black">
                              {log.userName?.charAt(0).toUpperCase() || 'S'}
                            </div>
                            <span className="text-xs font-bold text-slate-600 dark:text-slate-400">{log.userName || 'النظام'}</span>
                          </div>
                        </td>
                        <td className="py-4 px-6">
                          <span className="text-xs font-black text-slate-900 dark:text-white">{log.action}</span>
                        </td>
                        <td className="py-4 px-6">
                          {log.oldValue !== undefined && log.newValue !== undefined ? (
                            <div className="flex items-center gap-2 text-[10px] font-bold">
                              <span className="text-red-500 line-through opacity-60">{String(log.oldValue)}</span>
                              <ChevronRight size={12} className="text-slate-300" />
                              <span className="text-emerald-600 font-black">{String(log.newValue)}</span>
                            </div>
                          ) : (
                            <span className="text-[10px] text-slate-400 font-bold">{log.notes || '-'}</span>
                          )}
                        </td>
                        <td className="py-4 px-6">
                          {log.registrationId && (
                            <button 
                              onClick={() => {
                                const reg = registrations.find(r => r.id === log.registrationId);
                                if (reg) {
                                  setSelectedReg(reg);
                                  setActiveTab('registrations');
                                }
                              }}
                              className="text-[10px] font-black text-brand-600 hover:underline flex items-center gap-1"
                            >
                              <Eye size={12} /> عرض الطلب
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                    {auditLogs.length === 0 && (
                      <tr>
                        <td colSpan={5} className="py-20 text-center">
                          <History size={48} className="mx-auto text-slate-100 mb-4" />
                          <p className="text-slate-400 font-bold">لا توجد سجلات نشاط حالياً</p>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'vendors' && (userProfile.role === 'admin' || userProfile.role === 'supervisor') && (
          <VendorsTab vendors={vendors} userProfile={userProfile} />
        )}

        {activeTab === 'courses' && (userProfile.role === 'admin' || userProfile.role === 'supervisor') && (
          <CoursesTab registrations={registrations} userProfile={userProfile} />
        )}

        {activeTab === 'analytics' && (userProfile.role === 'admin' || userProfile.role === 'supervisor') && (
          <div className="p-4 sm:p-8">
            <h3 className="text-xl sm:text-2xl font-black text-slate-900 mb-6">لوحة التحكم التحليلية</h3>
            <AnalyticsDashboard 
              registrations={registrations} 
              festivals={userProfile.role === 'admin' ? festivals : festivals.filter(f => f.id === userProfile.assignedFestivalId)} 
            />
          </div>
        )}

        {activeTab === 'settings' && userProfile.role === 'admin' && (
          <div className="p-4 sm:p-8">
            <h3 className="text-xl sm:text-2xl font-black text-slate-900 mb-6 sm:mb-8">إعدادات النظام</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-slate-50 p-6 sm:p-8 rounded-2xl sm:rounded-[2.5rem] border border-slate-100 space-y-6">
                <div className="flex items-center justify-between gap-4 pb-4 border-b border-slate-200/60">
                  <div>
                    <h4 className="font-black text-slate-900 mb-1 text-sm sm:text-base">حالة الموقع</h4>
                    <p className="text-[10px] sm:text-xs text-slate-400 font-bold">إغلاق أو فتح الموقع بالكامل للمستخدمين</p>
                  </div>
                  <button 
                    onClick={() => setShowSiteToggleConfirm(true)}
                    className={`w-12 h-6 sm:w-16 sm:h-8 rounded-full transition-all relative shrink-0 ${siteSettings.siteOpen ? 'bg-emerald-500' : 'bg-slate-300'}`}
                  >
                    <div className={`absolute top-1 w-4 h-4 sm:w-6 sm:h-6 bg-white rounded-full shadow-sm transition-all ${siteSettings.siteOpen ? 'right-7 sm:right-9' : 'right-1'}`} />
                  </button>
                </div>

                <div className="flex items-center justify-between gap-4">
                  <div>
                    <h4 className="font-black text-slate-900 mb-1 text-sm sm:text-base">تبويب عروض الشركاء والخصومات</h4>
                    <p className="text-[10px] sm:text-xs text-slate-400 font-bold">تفعيل أو إخفاء تبويب "عروض وخصومات مميزة لكم" بالكامل لبوابة العرسان</p>
                  </div>
                  <button 
                    onClick={async () => {
                      const newVal = siteSettings.showOffersTab !== false ? false : true;
                      setSiteSettings({ ...siteSettings, showOffersTab: newVal });
                      await handleSettingChange('showOffersTab', newVal);
                    }}
                    className={`w-12 h-6 sm:w-16 sm:h-8 rounded-full transition-all relative shrink-0 ${siteSettings.showOffersTab !== false ? 'bg-emerald-500' : 'bg-slate-300'}`}
                  >
                    <div className={`absolute top-1 w-4 h-4 sm:w-6 sm:h-6 bg-white rounded-full shadow-sm transition-all ${siteSettings.showOffersTab !== false ? 'right-7 sm:right-9' : 'right-1'}`} />
                  </button>
                </div>

                <div className="flex items-center justify-between gap-4 pt-4 border-t border-slate-100">
                  <div>
                    <h4 className="font-black text-slate-900 mb-1 text-sm sm:text-base">تبويب الدورة التأهيلية</h4>
                    <p className="text-[10px] sm:text-xs text-slate-400 font-bold">تفعيل أو إخفاء تبويب "الدورة التأهيلية للمقبلين على الزواج" بالكامل لبوابة العرسان</p>
                  </div>
                  <button 
                    onClick={async () => {
                      const newVal = siteSettings.showCoursesTab !== false ? false : true;
                      setSiteSettings({ ...siteSettings, showCoursesTab: newVal });
                      await handleSettingChange('showCoursesTab', newVal);
                    }}
                    className={`w-12 h-6 sm:w-16 sm:h-8 rounded-full transition-all relative shrink-0 ${siteSettings.showCoursesTab !== false ? 'bg-emerald-500' : 'bg-slate-300'}`}
                  >
                    <div className={`absolute top-1 w-4 h-4 sm:w-6 sm:h-6 bg-white rounded-full shadow-sm transition-all ${siteSettings.showCoursesTab !== false ? 'right-7 sm:right-9' : 'right-1'}`} />
                  </button>
                </div>

                <div className="flex items-center justify-between gap-4 pt-4 border-t border-slate-100">
                  <div>
                    <h4 className="font-black text-slate-900 mb-1 text-sm sm:text-base">إظهار عدد الفرسان في بطاقة المهرجان</h4>
                    <p className="text-[10px] sm:text-xs text-slate-400 font-bold">تفعيل أو إخفاء عدد المقبولين في المهرجان من بطاقات المهرجانات بالصفحة الرئيسية</p>
                  </div>
                  <button 
                    onClick={async () => {
                      const newVal = !siteSettings.showRegistrationCount;
                      setSiteSettings({ ...siteSettings, showRegistrationCount: newVal });
                      await handleSettingChange('showRegistrationCount', newVal);
                    }}
                    className={`w-12 h-6 sm:w-16 sm:h-8 rounded-full transition-all relative shrink-0 ${siteSettings.showRegistrationCount ? 'bg-emerald-500' : 'bg-slate-300'}`}
                  >
                    <div className={`absolute top-1 w-4 h-4 sm:w-6 sm:h-6 bg-white rounded-full shadow-sm transition-all ${siteSettings.showRegistrationCount ? 'right-7 sm:right-9' : 'right-1'}`} />
                  </button>
                </div>

                <div className="flex items-center justify-between gap-4 pt-4 border-t border-slate-100">
                  <div>
                    <h4 className="font-black text-slate-900 mb-1 text-sm sm:text-base">تبويب بيانات "اجتماعية وصحية"</h4>
                    <p className="text-[10px] sm:text-xs text-slate-400 font-bold">تفعيل أو إخفاء الخطوة الخاصة بالبيانات الاجتماعية والصحية من استمارة التسجيل</p>
                  </div>
                  <button 
                    onClick={async () => {
                      const newVal = siteSettings.showSocialStep !== false ? false : true;
                      setSiteSettings({ ...siteSettings, showSocialStep: newVal });
                      await handleSettingChange('showSocialStep', newVal);
                    }}
                    className={`w-12 h-6 sm:w-16 sm:h-8 rounded-full transition-all relative shrink-0 ${siteSettings.showSocialStep !== false ? 'bg-emerald-500' : 'bg-slate-300'}`}
                  >
                    <div className={`absolute top-1 w-4 h-4 sm:w-6 sm:h-6 bg-white rounded-full shadow-sm transition-all ${siteSettings.showSocialStep !== false ? 'right-7 sm:right-9' : 'right-1'}`} />
                  </button>
                </div>
              </div>

              <div className="bg-slate-50 p-6 sm:p-8 rounded-2xl sm:rounded-[2.5rem] border border-slate-100 space-y-6">
                <h4 className="font-black text-slate-900 text-sm sm:text-base flex items-center gap-2">
                  <Bell size={18} className="text-amber-600" />
                  إعدادات التنبيهات التلقائية
                </h4>
                
                <div className="space-y-6">
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <h4 className="font-black text-slate-900 mb-1 text-sm">رسائل SMS</h4>
                      <p className="text-[10px] sm:text-xs text-slate-400 font-bold">إرسال رسالة نصية للعريس عند قبول أو رفض طلبه</p>
                    </div>
                    <button 
                      onClick={async () => {
                        const newVal = !siteSettings.enableSmsNotifications;
                        setSiteSettings({ ...siteSettings, enableSmsNotifications: newVal });
                        await handleSettingChange('enableSmsNotifications', newVal);
                      }}
                      className={`w-12 h-6 sm:w-16 sm:h-8 rounded-full transition-all relative shrink-0 ${siteSettings.enableSmsNotifications ? 'bg-emerald-500' : 'bg-slate-300'}`}
                    >
                      <div className={`absolute top-1 w-4 h-4 sm:w-6 sm:h-6 bg-white rounded-full shadow-sm transition-all ${siteSettings.enableSmsNotifications ? 'right-7 sm:right-9' : 'right-1'}`} />
                    </button>
                  </div>

                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <h4 className="font-black text-slate-900 mb-1 text-sm">البريد الإلكتروني (Email)</h4>
                      <p className="text-[10px] sm:text-xs text-slate-400 font-bold">إرسال بريد إلكتروني للعريس عند قبول أو رفض طلبه</p>
                    </div>
                    <button 
                      onClick={async () => {
                        const newVal = !siteSettings.enableEmailNotifications;
                        setSiteSettings({ ...siteSettings, enableEmailNotifications: newVal });
                        await handleSettingChange('enableEmailNotifications', newVal);
                      }}
                      className={`w-12 h-6 sm:w-16 sm:h-8 rounded-full transition-all relative shrink-0 ${siteSettings.enableEmailNotifications ? 'bg-emerald-500' : 'bg-slate-300'}`}
                    >
                      <div className={`absolute top-1 w-4 h-4 sm:w-6 sm:h-6 bg-white rounded-full shadow-sm transition-all ${siteSettings.enableEmailNotifications ? 'right-7 sm:right-9' : 'right-1'}`} />
                    </button>
                  </div>
                </div>
              </div>

              <div className="bg-slate-50 p-6 sm:p-8 rounded-2xl sm:rounded-[2.5rem] border border-slate-100 space-y-6">
                <h4 className="font-black text-slate-900 text-sm sm:text-base flex items-center gap-2">
                  <CreditCard size={18} className="text-emerald-600" />
                  بيانات الحساب البنكي للجمعية
                </h4>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-[10px] sm:text-xs font-black text-slate-400 mb-1.5 mr-1">اسم الجمعية</label>
                    <input 
                      type="text"
                      value={siteSettings.siteName || ''}
                      onChange={(e) => setSiteSettings({ ...siteSettings, siteName: e.target.value })}
                      onBlur={async () => await handleSettingChange('siteName', siteSettings.siteName || '')}
                      className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-xs sm:text-sm font-bold focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                      placeholder="أدخل اسم الجمعية..."
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] sm:text-xs font-black text-slate-400 mb-1.5 mr-1">العنوان الثانوي</label>
                    <input 
                      type="text"
                      value={siteSettings.secondaryTitle || ''}
                      onChange={(e) => setSiteSettings({ ...siteSettings, secondaryTitle: e.target.value })}
                      onBlur={async () => await handleSettingChange('secondaryTitle', siteSettings.secondaryTitle || '')}
                      className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-xs sm:text-sm font-bold focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                      placeholder="أدخل العنوان الثانوي (يظهر تحت اسم الجمعية)..."
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] sm:text-xs font-black text-slate-400 mb-1.5 mr-1">رقم التواصل</label>
                    <input 
                      type="text"
                      value={siteSettings.contactNumber || ''}
                      onChange={(e) => setSiteSettings({ ...siteSettings, contactNumber: e.target.value })}
                      onBlur={async () => await handleSettingChange('contactNumber', siteSettings.contactNumber || '')}
                      className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-xs sm:text-sm font-bold focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                      placeholder="أدخل رقم التواصل..."
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] sm:text-xs font-black text-slate-400 mb-1.5 mr-1">رقم التواصل الثاني</label>
                    <input 
                      type="text"
                      value={siteSettings.contactNumber2 || ''}
                      onChange={(e) => setSiteSettings({ ...siteSettings, contactNumber2: e.target.value })}
                      onBlur={async () => await handleSettingChange('contactNumber2', siteSettings.contactNumber2 || '')}
                      className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-xs sm:text-sm font-bold focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                      placeholder="أدخل رقم التواصل الثاني..."
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] sm:text-xs font-black text-slate-400 mb-1.5 mr-1">رقم الواتساب</label>
                    <input 
                      type="text"
                      value={siteSettings.whatsappNumber || ''}
                      onChange={(e) => setSiteSettings({ ...siteSettings, whatsappNumber: e.target.value })}
                      onBlur={async () => await handleSettingChange('whatsappNumber', siteSettings.whatsappNumber || '')}
                      className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-xs sm:text-sm font-bold focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                      placeholder="أدخل رقم الواتساب..."
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] sm:text-xs font-black text-slate-400 mb-1.5 mr-1">رقم الواتساب الثاني</label>
                    <input 
                      type="text"
                      value={siteSettings.whatsappNumber2 || ''}
                      onChange={(e) => setSiteSettings({ ...siteSettings, whatsappNumber2: e.target.value })}
                      onBlur={async () => await handleSettingChange('whatsappNumber2', siteSettings.whatsappNumber2 || '')}
                      className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-xs sm:text-sm font-bold focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                      placeholder="أدخل رقم الواتساب الثاني..."
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] sm:text-xs font-black text-slate-400 mb-1.5 mr-1">رابط منصة X</label>
                    <input 
                      type="text"
                      value={siteSettings.xLink || ''}
                      onChange={(e) => setSiteSettings({ ...siteSettings, xLink: e.target.value })}
                      onBlur={async () => await handleSettingChange('xLink', siteSettings.xLink || '')}
                      className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-xs sm:text-sm font-bold focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                      placeholder="أدخل رابط منصة X..."
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] sm:text-xs font-black text-slate-400 mb-1.5 mr-1">اسم البنك</label>
                    <input 
                      type="text"
                      value={siteSettings.bankName || ''}
                      onChange={(e) => setSiteSettings({ ...siteSettings, bankName: e.target.value })}
                      onBlur={async () => await handleSettingChange('bankName', siteSettings.bankName || '')}
                      className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-xs sm:text-sm font-bold focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                      placeholder="أدخل اسم البنك..."
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] sm:text-xs font-black text-slate-400 mb-1.5 mr-1">رقم الحساب</label>
                    <input 
                      type="text"
                      value={siteSettings.accountNumber || ''}
                      onChange={(e) => setSiteSettings({ ...siteSettings, accountNumber: e.target.value })}
                      onBlur={async () => await handleSettingChange('accountNumber', siteSettings.accountNumber || '')}
                      className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-xs sm:text-sm font-bold focus:ring-2 focus:ring-emerald-500 outline-none transition-all font-mono"
                      placeholder="أدخل رقم الحساب..."
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] sm:text-xs font-black text-slate-400 mb-1.5 mr-1">رقم الآيبان (IBAN)</label>
                    <input 
                      type="text"
                      value={siteSettings.iban || ''}
                      onChange={(e) => setSiteSettings({ ...siteSettings, iban: e.target.value })}
                      onBlur={async () => await handleSettingChange('iban', siteSettings.iban || '')}
                      className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-xs sm:text-sm font-bold focus:ring-2 focus:ring-emerald-500 outline-none transition-all font-mono"
                      placeholder="SA..."
                    />
                  </div>
                  <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                    <label className="text-xs font-black text-slate-700">تفعيل الدفع الإلكتروني</label>
                    <button
                      onClick={async () => {
                        const newValue = !siteSettings.enableOnlinePayment;
                        setSiteSettings({ ...siteSettings, enableOnlinePayment: newValue });
                        await handleSettingChange('enableOnlinePayment', newValue);
                      }}
                      className={`w-12 h-6 rounded-full transition-all relative ${siteSettings.enableOnlinePayment ? 'bg-emerald-500' : 'bg-slate-300'}`}
                    >
                      <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-sm transition-all ${siteSettings.enableOnlinePayment ? 'right-7' : 'right-1'}`} />
                    </button>
                  </div>
                  <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                    <label className="text-xs font-black text-slate-700">تفعيل التحويل البنكي</label>
                    <button
                      onClick={async () => {
                        const newValue = !siteSettings.enableTransferPayment;
                        setSiteSettings({ ...siteSettings, enableTransferPayment: newValue });
                        await handleSettingChange('enableTransferPayment', newValue);
                      }}
                      className={`w-12 h-6 rounded-full transition-all relative ${siteSettings.enableTransferPayment ? 'bg-emerald-500' : 'bg-slate-300'}`}
                    >
                      <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-sm transition-all ${siteSettings.enableTransferPayment ? 'right-7' : 'right-1'}`} />
                    </button>
                  </div>
                  <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                    <label className="text-xs font-black text-slate-700">إظهار معرض الصور في الصفحة الرئيسية</label>
                    <button
                      onClick={async () => {
                        const newValue = !siteSettings.showGallery;
                        setSiteSettings({ ...siteSettings, showGallery: newValue });
                        await handleSettingChange('showGallery', newValue);
                      }}
                      className={`w-12 h-6 rounded-full transition-all relative ${siteSettings.showGallery ? 'bg-emerald-500' : 'bg-slate-300'}`}
                    >
                      <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-sm transition-all ${siteSettings.showGallery ? 'right-7' : 'right-1'}`} />
                    </button>
                  </div>
                  <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                    <label className="text-xs font-black text-slate-700">إظهار قصص النجاح في الصفحة الرئيسية</label>
                    <button
                      onClick={async () => {
                        const newValue = !siteSettings.showTestimonials;
                        setSiteSettings({ ...siteSettings, showTestimonials: newValue });
                        await handleSettingChange('showTestimonials', newValue);
                      }}
                      className={`w-12 h-6 rounded-full transition-all relative ${siteSettings.showTestimonials ? 'bg-emerald-500' : 'bg-slate-300'}`}
                    >
                      <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-sm transition-all ${siteSettings.showTestimonials ? 'right-7' : 'right-1'}`} />
                    </button>
                  </div>
                  <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                    <label className="text-xs font-black text-slate-700">إظهار الإحصائيات في الصفحة الرئيسية</label>
                    <button
                      onClick={async () => {
                        const newValue = !siteSettings.showStatistics;
                        setSiteSettings({ ...siteSettings, showStatistics: newValue });
                        await handleSettingChange('showStatistics', newValue);
                      }}
                      className={`w-12 h-6 rounded-full transition-all relative ${siteSettings.showStatistics ? 'bg-emerald-500' : 'bg-slate-300'}`}
                    >
                      <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-sm transition-all ${siteSettings.showStatistics ? 'right-7' : 'right-1'}`} />
                    </button>
                  </div>
                  <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                    <label className="text-xs font-black text-slate-700">تفعيل خطوة الشروط والتعليمات قبل التسجيل</label>
                    <button
                      onClick={async () => {
                        const newValue = !siteSettings.showTermsStep;
                        setSiteSettings({ ...siteSettings, showTermsStep: newValue });
                        await handleSettingChange('showTermsStep', newValue);
                      }}
                      className={`w-12 h-6 rounded-full transition-all relative ${siteSettings.showTermsStep ? 'bg-emerald-500' : 'bg-slate-300'}`}
                    >
                      <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-sm transition-all ${siteSettings.showTermsStep ? 'right-7' : 'right-1'}`} />
                    </button>
                  </div>
                </div>
                <p className="text-[9px] sm:text-[10px] text-slate-400 font-bold">سيتم عرض هذه البيانات للمتقدمين في استمارة التسجيل عند خطوة السداد.</p>
              </div>

              <div className="bg-slate-50 p-6 sm:p-8 rounded-2xl sm:rounded-[2.5rem] border border-slate-100 space-y-6">
                <h4 className="font-black text-slate-900 text-sm sm:text-base flex items-center gap-2">
                  <FileText size={18} className="text-emerald-600" />
                  الشروط والتعليمات
                </h4>
                <div className="space-y-4">
                  <div className="flex gap-2">
                    <input 
                      id="new-term-input"
                      type="text"
                      className="flex-1 px-4 py-3 bg-white border border-slate-200 rounded-xl text-xs sm:text-sm font-bold focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
                      placeholder="أضف شرطاً جديداً..."
                      onKeyPress={async (e) => {
                        if (e.key === 'Enter') {
                          const input = e.target as HTMLInputElement;
                          if (input.value.trim()) {
                            const currentTerms = siteSettings.terms || [];
                            const newTerms = [...currentTerms, input.value.trim()];
                            setSiteSettings({ ...siteSettings, terms: newTerms });
                            await handleSettingChange('terms', newTerms);
                            input.value = '';
                          }
                        }
                      }}
                    />
                    <button 
                      onClick={async () => {
                        const input = document.getElementById('new-term-input') as HTMLInputElement;
                        if (input.value.trim()) {
                          const currentTerms = siteSettings.terms || [];
                          const newTerms = [...currentTerms, input.value.trim()];
                          setSiteSettings({ ...siteSettings, terms: newTerms });
                          await handleSettingChange('terms', newTerms);
                          input.value = '';
                        }
                      }}
                      className="px-4 py-2 bg-emerald-600 text-white rounded-xl font-black text-xs hover:bg-emerald-700 transition"
                    >إضافة</button>
                  </div>
                  <div className="space-y-2">
                    {(siteSettings.terms || []).map((term: string, index: number) => (
                      <div key={`term-edit-${index}`} className="flex items-center justify-between p-3 bg-white border border-slate-100 rounded-xl group transition-all hover:border-emerald-200">
                        <div className="flex-1 flex items-center gap-3">
                          <span className="flex-shrink-0 w-5 h-5 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center text-[10px] font-black">{index + 1}</span>
                          {editingTermIndex === index ? (
                            <input 
                              type="text"
                              autoFocus
                              value={editingTermValue}
                              onChange={(e) => setEditingTermValue(e.target.value)}
                              onBlur={async () => {
                                if (editingTermValue.trim() && editingTermValue !== term) {
                                  const newTerms = [...siteSettings.terms];
                                  newTerms[index] = editingTermValue.trim();
                                  setSiteSettings({ ...siteSettings, terms: newTerms });
                                  await handleSettingChange('terms', newTerms);
                                }
                                setEditingTermIndex(null);
                              }}
                              onKeyPress={async (e) => {
                                if (e.key === 'Enter') {
                                  if (editingTermValue.trim() && editingTermValue !== term) {
                                    const newTerms = [...siteSettings.terms];
                                    newTerms[index] = editingTermValue.trim();
                                    setSiteSettings({ ...siteSettings, terms: newTerms });
                                    await handleSettingChange('terms', newTerms);
                                  }
                                  setEditingTermIndex(null);
                                }
                              }}
                              className="flex-1 px-2 py-1 bg-slate-50 border border-emerald-200 rounded text-xs font-bold outline-none focus:ring-1 focus:ring-emerald-500"
                            />
                          ) : (
                            <p className="text-xs font-bold text-slate-700">{term}</p>
                          )}
                        </div>
                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          {editingTermIndex !== index && (
                             <button 
                               onClick={() => {
                                 setEditingTermIndex(index);
                                 setEditingTermValue(term);
                               }}
                               className="p-1.5 text-slate-400 hover:text-blue-500 hover:bg-blue-50 rounded-lg transition-colors"
                               title="تعديل"
                             >
                               <Edit3 size={14} />
                             </button>
                          )}
                          <button 
                            onClick={async () => {
                              const newTerms = (siteSettings.terms || []).filter((_: any, i: number) => i !== index);
                              setSiteSettings({ ...siteSettings, terms: newTerms });
                              await handleSettingChange('terms', newTerms);
                            }}
                            className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                            title="حذف"
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </div>
                    ))}
                    {(!siteSettings.terms || siteSettings.terms.length === 0) && (
                      <p className="text-center py-4 text-slate-400 text-[10px] font-bold italic">لا توجد شروط مضافة حالياً.</p>
                    )}
                  </div>
                </div>
              </div>

              <div className="bg-slate-50 p-6 sm:p-8 rounded-2xl sm:rounded-[2.5rem] border border-slate-100 space-y-6">
                <h4 className="font-black text-slate-900 text-sm sm:text-base flex items-center gap-2">
                  <Paperclip size={18} className="text-blue-600" />
                  إعدادات الملفات المرفقة
                </h4>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-[10px] sm:text-xs font-black text-slate-400 mb-1.5 mr-1">الحد الأقصى لحجم الملف (ميجابايت)</label>
                    <input 
                      type="number"
                      value={siteSettings.maxFileSizeMB || 5}
                      onChange={(e) => setSiteSettings({ ...siteSettings, maxFileSizeMB: Number(e.target.value) })}
                      onBlur={async () => await handleSettingChange('maxFileSizeMB', Number(siteSettings.maxFileSizeMB) || 5)}
                      className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-xs sm:text-sm font-bold focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                      placeholder="5"
                      min="1"
                      max="20"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] sm:text-xs font-black text-slate-400 mb-1.5 mr-1">أنواع الملفات المسموح بها</label>
                    <div className="flex flex-wrap gap-2">
                      {[
                        { label: 'JPG', value: 'image/jpeg' },
                        { label: 'PNG', value: 'image/png' },
                        { label: 'PDF', value: 'application/pdf' },
                        { label: 'DOCX', value: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' }
                      ].map((type) => (
                        <button
                          key={type.value}
                          onClick={async () => {
                            const currentTypes = siteSettings.allowedFileTypes || ['image/jpeg', 'image/png', 'application/pdf'];
                            let newTypes;
                            if (currentTypes.includes(type.value)) {
                              newTypes = currentTypes.filter(t => t !== type.value);
                            } else {
                              newTypes = [...currentTypes, type.value];
                            }
                            // Ensure at least one type is selected
                            if (newTypes.length === 0) return;
                            
                            setSiteSettings({ ...siteSettings, allowedFileTypes: newTypes });
                            await handleSettingChange('allowedFileTypes', newTypes);
                          }}
                          className={`px-3 py-1.5 rounded-lg text-[10px] font-black transition-all ${
                            (siteSettings.allowedFileTypes || ['image/jpeg', 'image/png', 'application/pdf']).includes(type.value)
                            ? 'bg-blue-600 text-white shadow-md'
                            : 'bg-white text-slate-400 border border-slate-200 hover:border-blue-300'
                          }`}
                        >
                          {type.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-[9px] sm:text-[10px] text-slate-400 font-bold">تحكم في قيود رفع الملفات للمتقدمين لضمان جودة البيانات وسرعة الموقع.</p>
              </div>

              <div className="bg-slate-50 p-6 sm:p-8 rounded-2xl sm:rounded-[2.5rem] border border-slate-100 space-y-6">
                <h4 className="font-black text-slate-900 text-sm sm:text-base flex items-center gap-2">
                  <History size={18} className="text-amber-600" />
                  أرشفة البيانات القديمة
                </h4>
                <p className="text-[10px] sm:text-xs text-slate-400 font-bold">نقل الطلبات التي مضى عليها أكثر من عام إلى الأرشيف للحفاظ على سرعة قاعدة البيانات.</p>
                
                <button 
                  onClick={handleArchive}
                  disabled={isArchiving}
                  className={`w-full py-3 rounded-xl font-black transition flex items-center justify-center gap-2 ${isArchiving ? 'bg-slate-100 text-slate-400' : 'bg-amber-600 text-white hover:bg-amber-700 shadow-lg shadow-amber-200 dark:shadow-amber-900/20'}`}
                >
                  {isArchiving ? (
                    <>
                      <Clock className="animate-spin" size={18} />
                      <span>جاري الأرشفة...</span>
                    </>
                  ) : (
                    <>
                      <History size={18} />
                      <span>أرشفة طلبات الأعوام السابقة</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Modals */}
      <AnimatePresence>
        {selectedReg && (
          <div className="fixed inset-0 z-50 flex lg:hidden items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white w-full max-w-4xl max-h-[90vh] rounded-[3rem] shadow-2xl overflow-hidden flex flex-col"
            >
              <div className="p-8 border-b border-slate-100 flex justify-between items-center">
                <h3 className="text-2xl font-black text-slate-900">تفاصيل الطلب</h3>
                <div className="flex gap-3">
                  <button 
                    onClick={handleConfirmPrint} 
                    disabled={isPrinting}
                    className="flex items-center gap-2 px-6 py-3 bg-emerald-600 text-white rounded-2xl hover:bg-emerald-700 transition shadow-lg shadow-emerald-100 font-black text-sm disabled:opacity-50"
                  >
                    {isPrinting ? (
                      <>جاري التجهيز...</>
                    ) : (
                      <>
                        <Printer size={20} /> طباعة التقرير الرسمي
                      </>
                    )}
                  </button>
                  <button onClick={() => { setSelectedReg(null); setHighlightPayment(false); }} className="p-3 bg-slate-100 text-slate-600 rounded-2xl hover:bg-slate-200 transition">
                    <X size={20} />
                  </button>
                </div>
              </div>
              
              <div className="p-8 overflow-y-auto flex-grow">
                <div className="space-y-10 p-4" dir="rtl">
                  <div className="text-center border-b pb-8 mb-8">
                    <h2 className="text-3xl font-black mb-2">استمارة تسجيل زواج جماعي</h2>
                    <p className="text-slate-500 font-bold">{selectedReg.festivalName}</p>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-12">
                    <div className="space-y-6">
                      <h4 className="font-black text-emerald-700 text-lg border-r-4 border-emerald-500 pr-3">بيانات العريس</h4>
                      <div className="space-y-3">
                        <Detail label="الاسم الرباعي" value={selectedReg.groomName} />
                        <Detail label="رقم الهوية" value={selectedReg.groomId} />
                        <Detail label="رقم الجوال" value={selectedReg.groomPhone} />
                        <Detail label="ممثل العريس" value={selectedReg.groomGuardianName} />
                        <Detail label="صلة القرابة" value={selectedReg.groomGuardianRelation} />
                        <Detail label="جوال ممثل العريس" value={selectedReg.groomGuardianPhone} />
                      </div>
                    </div>
                    <div className="space-y-6">
                      <h4 className="font-black text-emerald-700 text-lg border-r-4 border-emerald-500 pr-3">بيانات العروس</h4>
                      <div className="space-y-3">
                        <Detail label="الاسم الرباعي" value={selectedReg.brideName} />
                        <Detail label="رقم الهوية" value={selectedReg.brideId} />
                        <Detail label="رقم الجوال" value={selectedReg.bridePhone} />
                        <Detail label="ممثل العروس" value={selectedReg.guardianName} />
                        <Detail label="صلة القرابة" value={selectedReg.guardianRelation} />
                        <Detail label="جوال ممثل العروس" value={selectedReg.guardianPhone} />
                      </div>
                    </div>
                  </div>

                  {/* Sibling and Fees Information */}
                  <div className="bg-slate-50 p-6 rounded-3xl border border-slate-200/60 space-y-4">
                    <h4 className="font-black text-slate-800 text-base flex items-center gap-2">
                      <Users className="text-emerald-600 animate-pulse" size={20} />
                      تفاصيل الرسوم والاشتراك الأخوي
                    </h4>
                    <div className="grid grid-cols-2 gap-6">
                      <Detail label="رسوم الاشتراك المحتسبة" value={selectedReg.calculatedFees !== undefined ? `${selectedReg.calculatedFees} SAR` : `${selectedReg.fees || 9000} SAR`} />
                      <Detail label="هل له أخ مسجل؟" value={selectedReg.hasSibling ? 'نعم (مستحق لخصم الأخوة)' : 'لا'} />
                    </div>
                    {selectedReg.hasSibling && (
                      <div className="bg-emerald-50/50 p-4 rounded-2xl border border-emerald-100 space-y-2 mt-2">
                        <p className="text-xs text-emerald-800 font-extrabold">بيانات الأخ المرتبط:</p>
                        <div className="grid grid-cols-2 gap-4">
                          <Detail label="اسم الأخ الكامل" value={selectedReg.siblingName || '-'} />
                          <Detail label="رقم هوية الأخ" value={selectedReg.siblingId || '-'} />
                        </div>
                      </div>
                    )}
                  </div>

                  {selectedReg.status === 'rejected' && selectedReg.rejectionReason && (
                    <div className="bg-red-50 p-6 rounded-3xl border border-red-100">
                      <h4 className="font-black text-red-700 text-sm mb-2">سبب الرفض:</h4>
                      <p className="text-red-600 text-sm font-bold leading-relaxed">{selectedReg.rejectionReason}</p>
                    </div>
                  )}

                  {selectedReg.status === 'needs_info' && (
                    <div className="bg-amber-50 p-6 rounded-3xl border border-amber-100 mt-6">
                      <h4 className="font-black text-amber-700 text-sm mb-4">نواقص الطلب:</h4>
                      <textarea
                        value={deficiencies.join('\n')}
                        onChange={(e) => setDeficiencies(e.target.value.split('\n'))}
                        className="w-full p-4 rounded-2xl border border-amber-200 text-sm font-bold bg-white"
                        rows={4}
                        placeholder="اكتب نواقص الطلب هنا (كل نقص في سطر جديد)..."
                      />
                      <button
                        onClick={async () => {
                          try {
                            await updateDoc(doc(db, 'registrations', selectedReg.id), { deficiencies });
                            setSelectedReg({ ...selectedReg, deficiencies });
                            alert('تم حفظ النواقص بنجاح');
                          } catch (err) {
                            handleFirestoreError(err, OperationType.UPDATE, `registrations/${selectedReg.id}`);
                          }
                        }}
                        className="mt-4 bg-amber-600 text-white font-bold py-2 px-4 rounded-xl hover:bg-amber-700 transition-colors"
                      >
                        حفظ النواقص
                      </button>
                    </div>
                  )}

                  <div className="mt-12 pt-12 border-t border-slate-100 grid grid-cols-1 md:grid-cols-2 gap-12">
                    <div>
                      <h4 className="font-black text-slate-900 mb-6">المرفقات</h4>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 no-print">
                        {selectedReg.attachments?.map((att: any, i: number) => (
                          <div key={att.id || `att-${i}`} className="space-y-2 relative group">
                            <p className="text-[10px] font-black text-slate-400 text-center truncate">{att.name}</p>
                            <button onClick={() => setViewingAttachment(att)} className="block w-full aspect-square rounded-2xl overflow-hidden border border-slate-200 shadow-sm hover:shadow-md transition-shadow relative group/btn">
                              <div className="absolute inset-0 bg-slate-900/0 group-hover/btn:bg-slate-900/10 transition-colors z-10 flex items-center justify-center">
                                <Eye className="text-white opacity-0 group-hover/btn:opacity-100 transition-opacity drop-shadow-md" size={24} />
                              </div>
                              {att.type.includes('pdf') ? (
                                <div className="w-full h-full flex items-center justify-center bg-slate-50 text-slate-400">
                                  <FileText size={40} />
                                </div>
                              ) : (
                                <img src={att.url} alt={att.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                              )}
                            </button>
                            <button 
                              onClick={() => setDeleteAttachmentConfirm({ regId: selectedReg.id, index: i, type: 'attachment' })}
                              className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-md z-20 hover:bg-red-600"
                              title="حذف المرفق"
                            >
                              <Trash2 size={12} />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                    {['rejected', 'pending', 'needs_info'].includes(selectedReg.status) ? (
                      <div>
                        <h4 className="font-black text-slate-900 mb-6">حالة السداد</h4>
                        <div className="bg-amber-50 border border-amber-100 p-6 rounded-2xl flex items-center gap-4 no-print">
                          <div className="w-12 h-12 bg-amber-100 text-amber-600 rounded-xl flex items-center justify-center">
                            <Clock size={24} />
                          </div>
                          <div>
                            <p className="font-black text-amber-900 text-lg">في انتظار السداد من قبل العريس</p>
                            <p className="text-xs font-bold text-amber-600">سيتم تفعيل السداد بعد قبول الطلب</p>
                          </div>
                        </div>
                      </div>
                    ) : selectedReg.paymentMethod === 'online' ? (
                      <div>
                        <h4 className="font-black text-slate-900 mb-6">حالة الدفع</h4>
                        <div className="w-full max-w-sm no-print">
                          <div className="bg-emerald-50 border border-emerald-100 p-6 rounded-2xl flex items-center gap-4">
                            <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-xl flex items-center justify-center">
                              <CheckCircle size={24} />
                            </div>
                            <div>
                              <p className="font-black text-emerald-900 text-lg">تم الدفع إلكترونياً</p>
                              <p className="text-xs font-bold text-emerald-600">بوابة الدفع الآمنة</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div ref={paymentSectionRef} className={highlightPayment ? 'ring-2 ring-emerald-600 ring-offset-8 rounded-3xl animate-pulse bg-emerald-50/10' : ''}>
                        <div className="flex justify-between items-center mb-6">
                          <h4 className="font-black text-slate-900">إيصال السداد والتحقق</h4>
                          {selectedReg.paymentReceipt && (
                            <button 
                              onClick={() => {
                                const link = document.createElement('a');
                                link.href = selectedReg.paymentReceipt.url;
                                link.download = selectedReg.paymentReceipt.name;
                                document.body.appendChild(link);
                                link.click();
                                document.body.removeChild(link);
                              }}
                              className="text-blue-600 hover:text-blue-700 flex items-center gap-1 text-xs font-bold"
                            >
                              <Download size={14} /> تحميل الإيصال
                            </button>
                          )}
                        </div>
                        {selectedReg.paymentReceipt ? (
                          <div className="w-40 no-print relative group">
                            <p className="text-[10px] font-black text-slate-400 mb-2">{selectedReg.paymentReceipt.name}</p>
                            <button onClick={() => setViewingAttachment(selectedReg.paymentReceipt)} className="block w-full aspect-square rounded-2xl overflow-hidden border border-slate-200 shadow-sm hover:shadow-md transition-shadow relative group/btn">
                              <div className="absolute inset-0 bg-slate-900/0 group-hover/btn:bg-slate-900/10 transition-colors z-10 flex items-center justify-center">
                                <Eye className="text-white opacity-0 group-hover/btn:opacity-100 transition-opacity drop-shadow-md" size={24} />
                              </div>
                              {selectedReg.paymentReceipt.type.includes('pdf') ? (
                                <div className="w-full h-full flex items-center justify-center bg-slate-50 text-slate-400">
                                  <FileText size={48} />
                                </div>
                              ) : (
                                <img src={selectedReg.paymentReceipt.url} alt="payment receipt" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                              )}
                            </button>
                            <button 
                              onClick={() => setDeleteAttachmentConfirm({ regId: selectedReg.id, index: 0, type: 'paymentReceipt' })}
                              className="absolute top-4 -right-2 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-md z-20 hover:bg-red-600"
                              title="حذف الإيصال"
                            >
                              <Trash2 size={12} />
                            </button>
                          </div>
                        ) : (
                          <div className="no-print">
                            <label className="flex flex-col items-center justify-center w-40 h-40 border-2 border-dashed border-slate-200 rounded-2xl cursor-pointer hover:bg-slate-50 transition group">
                              <div className="flex flex-col items-center justify-center pt-5 pb-6">
                                <Plus size={32} className="text-slate-300 group-hover:text-emerald-500 transition" />
                                <p className="text-[10px] font-black text-slate-400 mt-2">رفع إيصال السداد</p>
                              </div>
                              <input 
                                type="file" 
                                className="hidden" 
                                accept="image/*,application/pdf"
                                onChange={async (e) => {
                                  const file = e.target.files?.[0];
                                  if (!file) return;
                                  
                                  try {
                                    // Only compress images, not PDFs
                                    let fileToUpload = file;
                                    if (file.type.startsWith('image/')) {
                                      fileToUpload = await imageCompression(file, { maxSizeMB: 1, maxWidthOrHeight: 1920 });
                                    }
                                    
                                    const storageRef = ref(storage, `receipts/${Date.now()}_${fileToUpload.name}`);
                                    await uploadBytes(storageRef, fileToUpload);
                                    const url = await getDownloadURL(storageRef);
                                    await updateDoc(doc(db, 'registrations', selectedReg.id), {
                                      paymentReceipt: {
                                        url: url,
                                        name: fileToUpload.name,
                                        type: fileToUpload.type,
                                        uploadedAt: serverTimestamp()
                                      },
                                      paymentStatus: 'pending_verification'
                                    });
                                    setAlertMessage('تم رفع إيصال السداد بنجاح');
                                  } catch (error) {
                                    console.error('Error uploading receipt:', error);
                                    setAlertMessage('فشل رفع الإيصال.');
                                  }
                                }}
                              />
                            </label>
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Internal Notes Section */}
                  <div className="mt-12 pt-12 border-t border-slate-100 no-print">
                    <div className="flex items-center gap-3 mb-6">
                      <div className="w-10 h-10 bg-amber-50 text-amber-600 rounded-xl flex items-center justify-center">
                        <MessageSquareHeart size={20} />
                      </div>
                      <div>
                        <h4 className="font-black text-slate-900 text-lg">الملاحظات الداخلية والمهام</h4>
                        <p className="text-xs font-bold text-slate-500">هذه الملاحظات تظهر للمشرفين والإدارة فقط ولا يراها العريس</p>
                      </div>
                    </div>

                    <div className="bg-slate-50 rounded-3xl p-6 border border-slate-100">
                      <div className="space-y-4 mb-6 max-h-60 overflow-y-auto pr-2">
                        {!selectedReg.internalNotes || selectedReg.internalNotes.length === 0 ? (
                          <div className="text-center py-8">
                            <MessageCircle size={32} className="mx-auto text-slate-300 mb-3" />
                            <p className="text-sm font-bold text-slate-400">لا توجد ملاحظات داخلية حتى الآن</p>
                          </div>
                        ) : (
                          selectedReg.internalNotes.map((note: any, i: number) => (
                            <div key={note.id || `temp-note-${i}`} className={`bg-white p-4 rounded-2xl border shadow-sm ${note.type === 'task' ? (note.status === 'completed' ? 'border-emerald-200 bg-emerald-50/30' : 'border-amber-200 bg-amber-50/30') : 'border-slate-100'}`}>
                              <div className="flex justify-between items-start mb-2">
                                <div className="flex items-center gap-2">
                                  <div className={`w-6 h-6 rounded-full flex items-center justify-center ${note.type === 'task' ? 'bg-amber-100 text-amber-600' : 'bg-emerald-50 text-emerald-600'}`}>
                                    {note.type === 'task' ? <CheckCircle size={12} /> : <User size={12} />}
                                  </div>
                                  <span className="text-xs font-black text-slate-700">{note.createdBy}</span>
                                  {note.type === 'task' && (
                                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-700 mr-2">
                                      مهمة لـ: {supervisors.find(s => s.email === note.assignedTo)?.name || note.assignedTo}
                                    </span>
                                  )}
                                </div>
                                <span className="text-[10px] font-bold text-slate-400">
                                  {note.createdAt?.toDate ? format(note.createdAt.toDate(), 'yyyy/MM/dd HH:mm') : format(new Date(note.createdAt), 'yyyy/MM/dd HH:mm')}
                                </span>
                              </div>
                              <div className="flex items-start gap-3 pr-8">
                                {note.type === 'task' && (
                                  <button 
                                    onClick={() => handleToggleTaskStatus(selectedReg.id, note.id, note.status)}
                                    className={`mt-0.5 shrink-0 ${note.status === 'completed' ? 'text-emerald-500' : 'text-slate-300 hover:text-amber-500'} transition-colors`}
                                  >
                                    <CheckCircle size={18} className={note.status === 'completed' ? 'fill-emerald-50' : ''} />
                                  </button>
                                )}
                                <p className={`text-sm font-bold leading-relaxed ${note.type === 'task' && note.status === 'completed' ? 'text-slate-400 line-through' : 'text-slate-600'}`}>
                                  {note.text}
                                </p>
                              </div>
                            </div>
                          ))
                        )}
                      </div>

                      <div className="space-y-3">
                        <div className="flex gap-2 mb-2">
                          <button
                            onClick={() => setNewNoteType('note')}
                            className={`px-4 py-1.5 rounded-full text-xs font-bold transition-colors ${newNoteType === 'note' ? 'bg-slate-800 text-white' : 'bg-slate-200 text-slate-600 hover:bg-slate-300'}`}
                          >
                            ملاحظة
                          </button>
                          <button
                            onClick={() => setNewNoteType('task')}
                            className={`px-4 py-1.5 rounded-full text-xs font-bold transition-colors ${newNoteType === 'task' ? 'bg-amber-500 text-white' : 'bg-slate-200 text-slate-600 hover:bg-slate-300'}`}
                          >
                            مهمة
                          </button>
                        </div>
                        
                        {newNoteType === 'task' && (
                          <select
                            value={assignedSupervisor}
                            onChange={(e) => setAssignedSupervisor(e.target.value)}
                            className="w-full bg-white border border-slate-200 px-4 py-2.5 rounded-xl font-bold text-sm focus:ring-2 focus:ring-amber-500 outline-none transition"
                          >
                            <option value="">اختر المشرف لإسناد المهمة...</option>
                            {supervisors.map((sup, i) => (
                              <option key={`${sup.id || `sup-${i}`}-${i}`} value={sup.email}>{sup.name} ({sup.email})</option>
                            ))}
                          </select>
                        )}

                        <div className="flex gap-3">
                          <input 
                            type="text"
                            value={newNoteText}
                            onChange={(e) => setNewNoteText(e.target.value)}
                            placeholder={newNoteType === 'task' ? "اكتب تفاصيل المهمة هنا..." : "اكتب ملاحظة جديدة هنا..."}
                            className="flex-1 bg-white border border-slate-200 px-4 py-3 rounded-xl font-bold text-sm focus:ring-2 focus:ring-amber-500 outline-none transition"
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleAddNote(selectedReg.id);
                            }}
                          />
                          <button 
                            onClick={() => handleAddNote(selectedReg.id)}
                            disabled={isAddingNote || !newNoteText.trim() || (newNoteType === 'task' && !assignedSupervisor)}
                            className="bg-amber-500 text-white px-6 py-3 rounded-xl font-black text-sm hover:bg-amber-600 transition shadow-lg shadow-amber-100 disabled:opacity-50 flex items-center gap-2 shrink-0"
                          >
                            {isAddingNote ? 'جاري الإضافة...' : (
                              <>
                                <Send size={16} /> إضافة
                              </>
                            )}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}

        {showAddFestival && (
          <AddFestivalModal onClose={() => setShowAddFestival(false)} supervisors={supervisors} />
        )}

        {showAddSupervisor && (
          <AddSupervisorModal onClose={() => setShowAddSupervisor(false)} festivals={festivals} showToast={showToast} />
        )}

        {editingSupervisor && (
          <EditSupervisorModal supervisor={editingSupervisor} onClose={() => setEditingSupervisor(null)} festivals={festivals} showToast={showToast} />
        )}

        {(showAddTestimonial || editingTestimonial) && (
          <AddTestimonialModal 
            onClose={() => {
              setShowAddTestimonial(false);
              setEditingTestimonial(null);
            }} 
            editingTestimonial={editingTestimonial}
          />
        )}

        {showSiteToggleConfirm && (
          <ConfirmModal 
            title={siteSettings.siteOpen ? 'إغلاق الموقع' : 'فتح الموقع'}
            message={siteSettings.siteOpen ? 'هل أنت متأكد من إغلاق الموقع؟ لن يتمكن المستخدمون من التسجيل في المهرجانات.' : 'هل أنت متأكد من فتح الموقع؟ سيتمكن المستخدمون من التسجيل في المهرجانات المتاحة.'}
            onConfirm={toggleSite}
            onCancel={() => setShowSiteToggleConfirm(false)}
            confirmText="تأكيد"
            icon={siteSettings.siteOpen ? <Lock size={32} /> : <Unlock size={32} />}
            color={siteSettings.siteOpen ? 'red' : 'emerald'}
          />
        )}

        {festivalStatusConfirm && (
          <ConfirmModal 
            title={festivalStatusConfirm.isOpen ? 'فتح التسجيل' : 'إغلاق التسجيل'}
            message={`هل أنت متأكد من ${festivalStatusConfirm.isOpen ? 'فتح' : 'إغلاق'} التسجيل في ${festivalStatusConfirm.name}؟`}
            onConfirm={() => updateFestivalStatus(festivalStatusConfirm.id, festivalStatusConfirm.isOpen)}
            onCancel={() => setFestivalStatusConfirm(null)}
            confirmText="تأكيد"
            icon={festivalStatusConfirm.isOpen ? <Unlock size={32} /> : <Lock size={32} />}
            color={festivalStatusConfirm.isOpen ? 'emerald' : 'red'}
          />
        )}

        {rejectionModal && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="bg-white w-full max-w-sm p-8 rounded-[2.5rem] shadow-2xl">
              <div className="w-16 h-16 bg-red-100 text-red-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <XCircle size={32} />
              </div>
              <h3 className="text-xl font-black text-slate-900 mb-2 text-center">سبب الرفض</h3>
              <p className="text-slate-500 font-bold mb-6 text-center text-sm">يرجى ذكر سبب رفض طلب {rejectionModal.name}</p>
              <textarea 
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-red-500 mb-2 text-sm font-bold h-32"
                placeholder="اكتب السبب هنا..."
                required
              />
              <p className="text-[10px] text-slate-400 font-bold mb-4 text-right">سيظهر هذا السبب للمتقدم عند الاستعلام عن حالة طلبه.</p>
              <div className="flex flex-wrap gap-2 mb-6">
                {['البيانات غير مكتملة', 'المرفقات غير واضحة', 'عدم تطابق البيانات', 'تكرار الطلب'].map(hint => (
                  <button 
                    key={hint}
                    type="button"
                    onClick={() => setRejectionReason(hint)}
                    className="px-3 py-1.5 bg-slate-100 text-slate-500 rounded-lg text-[10px] font-black hover:bg-slate-200 transition border border-slate-200"
                  >
                    {hint}
                  </button>
                ))}
              </div>
              <div className="flex gap-4">
                <button onClick={() => { setRejectionModal(null); setRejectionReason(''); }} className="flex-1 py-4 bg-slate-100 text-slate-600 rounded-2xl font-black hover:bg-slate-200 transition">
                  إلغاء
                </button>
                <button 
                  onClick={submitRejection} 
                  disabled={!rejectionReason.trim()}
                  className="flex-1 py-4 bg-red-600 text-white rounded-2xl font-black hover:bg-red-700 transition shadow-lg shadow-red-100 disabled:opacity-50"
                >
                  تأكيد الرفض
                </button>
              </div>
            </motion.div>
          </div>
        )}

        {needsInfoModal && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="bg-white w-full max-w-sm p-8 rounded-[2.5rem] shadow-2xl">
              <div className="w-16 h-16 bg-amber-100 text-amber-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <AlertCircle size={32} />
              </div>
              <h3 className="text-xl font-black text-slate-900 mb-2 text-center">نواقص الطلب</h3>
              <p className="text-slate-500 font-bold mb-6 text-center text-sm">يرجى تحديد نواقص طلب {needsInfoModal.name}</p>
              <textarea 
                value={needsInfoDeficiencies.join('\n')}
                onChange={(e) => setNeedsInfoDeficiencies(e.target.value.split('\n'))}
                className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-amber-500 mb-2 text-sm font-bold h-32"
                placeholder="اكتب النواقص هنا (كل نقص في سطر جديد)..."
                required
              />
              <p className="text-[10px] text-slate-400 font-bold mb-4 text-right">ستظهر هذه النواقص للمتقدم في بوابة العرسان.</p>
              <div className="flex flex-wrap gap-2 mb-6">
                {['الهوية غير واضحة', 'نقص في المرفقات', 'تعديل الاسم الرباعي', 'تحديث رقم الجوال'].map(hint => (
                  <button 
                    key={hint}
                    type="button"
                    onClick={() => {
                      if (!needsInfoDeficiencies.includes(hint)) {
                        setNeedsInfoDeficiencies([...needsInfoDeficiencies.filter(d => d.trim()), hint]);
                      }
                    }}
                    className="px-3 py-1.5 bg-slate-100 text-slate-500 rounded-lg text-[10px] font-black hover:bg-slate-200 transition border border-slate-200"
                  >
                    {hint}
                  </button>
                ))}
              </div>
              <div className="flex gap-4">
                <button onClick={() => { setNeedsInfoModal(null); setNeedsInfoDeficiencies([]); }} className="flex-1 py-4 bg-slate-100 text-slate-600 rounded-2xl font-black hover:bg-slate-200 transition">
                  إلغاء
                </button>
                <button 
                  onClick={submitNeedsInfo} 
                  disabled={needsInfoDeficiencies.length === 0 || needsInfoDeficiencies.every(d => !d.trim())}
                  className="flex-1 py-4 bg-amber-600 text-white rounded-2xl font-black hover:bg-amber-700 transition shadow-lg shadow-amber-100 disabled:opacity-50"
                >
                  تأكيد إرسال النواقص
                </button>
              </div>
            </motion.div>
          </div>
        )}

        {viewingAttachment && (
          <AttachmentViewerModal 
            attachment={viewingAttachment} 
            onClose={() => setViewingAttachment(null)} 
          />
        )}

        {deleteAttachmentConfirm && (
          <ConfirmModal 
            title="حذف المرفق"
            message="هل أنت متأكد من حذف هذا المرفق؟ لا يمكن التراجع عن هذا الإجراء."
            onConfirm={handleDeleteAttachment}
            onCancel={() => setDeleteAttachmentConfirm(null)}
          />
        )}

        {deleteConfirm && (
          <ConfirmModal 
            title={
              deleteConfirm.type === 'festival' ? 'حذف المهرجان' : 
              deleteConfirm.type === 'supervisor' ? 'حذف المشرف' : 
              'حذف قصة النجاح'
            }
            message={
              deleteConfirm.type === 'festival' ? 'هل أنت متأكد من حذف هذا المهرجان؟ لا يمكن التراجع عن هذا الإجراء.' : 
              deleteConfirm.type === 'supervisor' ? 'هل أنت متأكد من حذف هذا المشرف؟' :
              'هل أنت متأكد من حذف قصة النجاح هذه؟ لا يمكن التراجع عن هذا الإجراء.'
            }
            onConfirm={() => {
              if (deleteConfirm.type === 'festival') deleteFestival(deleteConfirm.id);
              else if (deleteConfirm.type === 'supervisor') deleteSupervisor(deleteConfirm.id);
              else if (deleteConfirm.type === 'testimonial') {
                deleteDoc(doc(db, 'testimonials', deleteConfirm.id));
                setDeleteConfirm(null);
              }
            }}
            onCancel={() => setDeleteConfirm(null)}
          />
        )}

        {showBulkDeleteConfirm && (
          <ConfirmModal 
            title="حذف جماعي"
            message={`هل أنت متأكد من حذف ${selectedRegistrations.size} طلب؟ لا يمكن التراجع عن هذا الإجراء.`}
            onConfirm={deleteSelected}
            onCancel={() => setShowBulkDeleteConfirm(false)}
          />
        )}

        {showReminderModal && (
          <ReminderModal 
            registrations={getOverdueRegistrations()} 
            onClose={() => setShowReminderModal(false)}
            onSendWhatsApp={sendWhatsAppReminder}
          />
        )}

        {showSeedConfirm && (
          <ConfirmModal 
            title="استعادة البيانات الافتراضية"
            message="هل تريد إضافة الـ 24 مهرجان السابقين؟"
            onConfirm={seedData}
            onCancel={() => setShowSeedConfirm(false)}
          />
        )}

        {alertMessage && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="bg-white w-full max-w-sm p-8 rounded-[2.5rem] shadow-2xl text-center">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <CheckCircle size={32} />
              </div>
              <h3 className="text-xl font-black text-slate-900 mb-2">نجاح</h3>
              <p className="text-slate-500 font-bold mb-8">{alertMessage}</p>
              <button onClick={() => setAlertMessage(null)} className="w-full py-4 bg-slate-900 text-white rounded-2xl font-black hover:bg-slate-800 transition">
                موافق
              </button>
            </motion.div>
          </div>
        )}

        {showPrintPreview && printingReg && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }} 
              animate={{ scale: 1, opacity: 1 }} 
              className="bg-white w-full max-w-4xl max-h-[90vh] rounded-[3rem] shadow-2xl overflow-hidden flex flex-col"
            >
              <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-emerald-600 text-white rounded-xl flex items-center justify-center shadow-lg">
                    <Printer size={20} />
                  </div>
                  <h3 className="text-xl font-black text-slate-900">معاينة التقرير الرسمي</h3>
                </div>
                <div className="flex gap-3">
                  <button 
                    onClick={handleConfirmPrint} 
                    disabled={isPrinting}
                    className="flex items-center gap-2 px-6 py-2.5 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 transition shadow-lg shadow-emerald-100 font-black text-sm disabled:opacity-50"
                  >
                    {isPrinting ? (
                      <>جاري التجهيز...</>
                    ) : (
                      <>
                        <Printer size={18} /> تأكيد الطباعة
                      </>
                    )}
                  </button>
                  <button 
                    onClick={() => {
                      setShowPrintPreview(false);
                      setPrintingReg(null);
                    }} 
                    className="p-2.5 bg-white text-slate-400 rounded-xl hover:bg-slate-100 transition border border-slate-200"
                  >
                    <X size={20} />
                  </button>
                </div>
              </div>
              <div className="p-8 overflow-y-auto flex-grow bg-slate-100/30">
                <div className="bg-white shadow-sm rounded-xl overflow-hidden border border-slate-200 mx-auto max-w-[210mm]">
                  <PrintReport registration={printingReg} />
                </div>
              </div>
            </motion.div>
          </div>
        )}

        {imageToDelete && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-[2rem] p-8 max-w-sm w-full shadow-2xl relative"
            >
              <div className="w-16 h-16 bg-red-50 text-red-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <AlertCircle size={32} />
              </div>
              <h3 className="text-xl font-black text-slate-900 text-center mb-2">تأكيد حذف الصورة</h3>
              <p className="text-slate-500 text-center text-sm font-bold mb-8">
                هل أنت متأكد من رغبتك في حذف الصورة "{imageToDelete.name}"؟ لا يمكن التراجع عن هذا الإجراء.
              </p>
              <div className="flex gap-3">
                <button 
                  onClick={() => setImageToDelete(null)}
                  className="flex-1 py-3 bg-slate-100 text-slate-600 rounded-xl font-bold hover:bg-slate-200 transition"
                >
                  إلغاء
                </button>
                <button 
                  onClick={async () => {
                    try {
                      await deleteDoc(doc(db, 'gallery', imageToDelete.id));
                      setAlertMessage('تم حذف الصورة بنجاح');
                    } catch (error) {
                      console.error('Error deleting image:', error);
                      setAlertMessage('حدث خطأ أثناء حذف الصورة');
                    }
                    setImageToDelete(null);
                  }}
                  className="flex-1 py-3 bg-red-600 text-white rounded-xl font-bold hover:bg-red-700 transition"
                >
                  تأكيد الحذف
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Full Report Print Preview */}
      <AnimatePresence>
        {showFullReportPrint && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white w-full max-w-5xl h-[90vh] rounded-[3rem] shadow-2xl overflow-hidden flex flex-col"
            >
              <div className="p-8 border-b border-slate-100 flex justify-between items-center bg-white z-10">
                <div>
                  <h3 className="text-2xl font-black text-slate-900">
                    {selectedFestivalFilter === 'all' ? 'معاينة التقرير الكامل' : `معاينة تقرير ${festivals.find(f => f.id === selectedFestivalFilter)?.name || ''}`}
                  </h3>
                  <p className="text-slate-400 font-bold">
                    {selectedFestivalFilter === 'all' 
                      ? 'سيتم طباعة جميع المتقدمين المسجلين حالياً' 
                      : `سيتم طباعة المتقدمين المسجلين في ${festivals.find(f => f.id === selectedFestivalFilter)?.name || ''}`}
                  </p>
                </div>
                <div className="flex gap-3">
                  <button 
                    onClick={() => setShowFullReportPrint(false)} 
                    className="p-3 bg-slate-100 text-slate-600 rounded-2xl hover:bg-slate-200 transition"
                  >
                    <X size={20} />
                  </button>
                  <button 
                    onClick={() => {
                      const printWindow = window.open('', '_blank', 'width=900,height=700');
                      if (printWindow) {
                        printWindow.document.write(`
                          <html>
                            <head>
                              <title>تقرير المتقدمين</title>
                              <script src="https://cdn.tailwindcss.com"></script>
                              <style>
                                @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Noto+Sans+Arabic:wght@300;400;500;600;700;800;900&family=Cormorant+Garamond:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap');
                                body { font-family: 'Inter', 'Noto Sans Arabic', sans-serif; direction: rtl; background-color: white; }
                              </style>
                            </head>
                            <body>
                              ${document.getElementById('printable-full-report')?.innerHTML || 'لا يوجد بيانات للطباعة'}
                            </body>
                          </html>
                        `);
                        printWindow.document.close();
                        printWindow.focus();
                        // Wait for Tailwind to load
                        setTimeout(() => {
                          printWindow.print();
                          setShowFullReportPrint(false);
                        }, 500);
                      } else {
                        alert('يرجى السماح بفتح النوافذ المنبثقة للطباعة');
                      }
                    }}
                    className="px-8 bg-emerald-600 text-white rounded-2xl font-black hover:bg-emerald-700 transition flex items-center gap-2 shadow-xl shadow-emerald-100"
                  >
                    <Printer size={20} /> تأكيد الطباعة
                  </button>
                </div>
              </div>
              
              <div className="flex-grow overflow-y-auto p-12 bg-slate-50">
                <div className="shadow-2xl mx-auto max-w-[210mm]">
                  <FullRegistrationsReport registrations={registrations.filter(r => selectedFestivalFilter === 'all' || r.festivalId === selectedFestivalFilter)} />
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Audit Logs Modal */}
      <AnimatePresence>
        {showLogsModal && (
          <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white w-full max-w-2xl max-h-[80vh] rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col"
            >
              <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-amber-100 text-amber-600 rounded-xl flex items-center justify-center">
                    <History size={20} />
                  </div>
                  <div>
                    <h3 className="text-xl font-black text-slate-900">سجل العمليات</h3>
                    <p className="text-[10px] font-bold text-slate-400">تتبع التغييرات التي تمت على هذا الطلب</p>
                  </div>
                </div>
                <button 
                  onClick={() => setShowLogsModal(null)}
                  className="p-2 bg-white text-slate-400 rounded-xl hover:bg-slate-100 transition border border-slate-200"
                >
                  <X size={20} />
                </button>
              </div>
              
              <div className="flex-grow overflow-y-auto p-6">
                <div className="space-y-4">
                  {auditLogs.filter(log => log.registrationId === showLogsModal).length === 0 ? (
                    <div className="text-center py-12">
                      <History size={48} className="mx-auto text-slate-100 mb-4" />
                      <p className="text-slate-400 font-bold">لا توجد سجلات لهذا الطلب بعد</p>
                    </div>
                  ) : (
                    auditLogs
                      .filter(log => log.registrationId === showLogsModal)
                      .map((log, i) => {
                        const translateStatus = (status: string) => {
                          if (status === 'pending') return 'قيد المراجعة والدراسة';
                          if (status === 'approved') return 'مقبول';
                          if (status === 'rejected') return 'مرفوض';
                          return status;
                        };
                        
                        return (
                          <div key={`log-timeline-${log.id || `temp-${i}`}`} className="relative pr-8 pb-6 border-r-2 border-slate-100 last:border-0 last:pb-0">
                            <div className="absolute top-0 -right-[9px] w-4 h-4 rounded-full bg-white border-2 border-emerald-500 z-10" />
                            <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
                              <div className="flex justify-between items-start mb-3">
                                <div className="flex items-center gap-2">
                                  <div className="w-8 h-8 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-600">
                                    <User size={14} />
                                  </div>
                                  <div>
                                    <span className="block text-sm font-black text-slate-900">{log.action}</span>
                                    <span className="block text-[10px] font-bold text-slate-500">بواسطة: {log.userName}</span>
                                  </div>
                                </div>
                                <span className="text-[10px] font-bold text-slate-400 bg-slate-50 px-2 py-1 rounded-lg">
                                  {log.createdAt?.toDate ? format(log.createdAt.toDate(), 'yyyy/MM/dd HH:mm') : 'جاري التحميل...'}
                                </span>
                              </div>
                              
                              {log.oldValue && log.newValue && (
                                <div className="mt-4 p-3 bg-slate-50 rounded-xl border border-slate-100">
                                  <p className="text-[10px] font-bold text-slate-400 mb-2">تفاصيل التغيير:</p>
                                  <div className="flex items-center justify-between gap-2 text-xs font-bold">
                                    <div className="flex-1 bg-white p-2 rounded-lg border border-red-100 text-red-600 text-center shadow-sm">
                                      <span className="block text-[8px] text-red-400 mb-1">القيمة السابقة</span>
                                      {translateStatus(log.oldValue)}
                                    </div>
                                    <div className="w-8 h-8 shrink-0 bg-white rounded-full flex items-center justify-center shadow-sm border border-slate-100">
                                      <ChevronLeft size={14} className="text-slate-400" />
                                    </div>
                                    <div className="flex-1 bg-white p-2 rounded-lg border border-emerald-100 text-emerald-600 text-center shadow-sm">
                                      <span className="block text-[8px] text-emerald-400 mb-1">القيمة الجديدة</span>
                                      {translateStatus(log.newValue)}
                                    </div>
                                  </div>
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {editingSocialFestival && (
          <SocialMediaModal 
            festival={editingSocialFestival} 
            onClose={() => setEditingSocialFestival(null)} 
            onUpdate={updateFestivalSocial}
          />
        )}
      </AnimatePresence>

      </div>

      {/* Hidden Printable Report */}
      <div id="printable-report" className="hidden print:block">
        {(selectedReg || printingReg) && <PrintReport registration={selectedReg || printingReg} />}
      </div>
      <div id="printable-full-report" className="hidden">
        <FullRegistrationsReport registrations={registrations.filter(r => selectedFestivalFilter === 'all' || r.festivalId === selectedFestivalFilter)} />
      </div>

      {/* Toast Notification */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.9 }}
            className={`fixed bottom-6 left-1/2 -translate-x-1/2 z-[100] text-white px-6 py-3 rounded-2xl shadow-2xl flex items-center gap-3 ${toastMessage.type === 'error' ? 'bg-red-600' : 'bg-slate-900'}`}
          >
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${toastMessage.type === 'error' ? 'bg-white/20 text-white' : 'bg-emerald-500/20 text-emerald-400'}`}>
              {toastMessage.type === 'error' ? <AlertCircle size={18} /> : <CheckCircle size={18} />}
            </div>
            <span className="font-bold text-sm">{toastMessage.message}</span>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

function ConfirmModal({ title, message, onConfirm, onCancel, confirmText = 'تأكيد الحذف', icon, color = 'red' }: any) {
  const iconColorClass = color === 'red' ? 'bg-red-100 text-red-600' : 'bg-emerald-100 text-emerald-600';
  const btnColorClass = color === 'red' ? 'bg-red-600 hover:bg-red-700 shadow-red-100' : 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-100';

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="bg-white w-full max-w-sm p-8 rounded-[2.5rem] shadow-2xl text-center">
        <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6 ${iconColorClass}`}>
          {icon || <Trash2 size={32} />}
        </div>
        <h3 className="text-xl font-black text-slate-900 mb-2">{title}</h3>
        <p className="text-slate-500 font-bold mb-8">{message}</p>
        <div className="flex gap-4">
          <button onClick={onCancel} className="flex-1 py-4 bg-slate-100 text-slate-600 rounded-2xl font-black hover:bg-slate-200 transition">
            إلغاء
          </button>
          <button onClick={onConfirm} className={`flex-1 py-4 text-white rounded-2xl font-black transition shadow-lg ${btnColorClass}`}>
            {confirmText}
          </button>
        </div>
      </motion.div>
    </div>
  );
}

function TabButton({ active, onClick, icon, label }: any) {
  return (
    <button 
      onClick={onClick}
      className={`flex items-center whitespace-nowrap gap-1.5 sm:gap-2 px-3 sm:px-6 py-2 sm:py-3 rounded-lg sm:rounded-xl text-xs sm:text-base font-black transition-all ${
        active ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-200' : 'text-slate-500 hover:bg-slate-50'
      }`}
    >
      {React.cloneElement(icon as React.ReactElement, { size: 14, className: "sm:w-[18px] sm:h-[18px]" })}
      {label}
    </button>
  );
}

function Detail({ label, value }: any) {
  return (
    <div className="flex justify-between items-center border-b border-slate-50 pb-2">
      <span className="text-slate-400 font-bold text-xs">{label}:</span>
      <span className="text-slate-900 font-black text-sm">{value}</span>
    </div>
  );
}

function AddFestivalModal({ onClose, supervisors }: any) {
  const [name, setName] = useState('');
  const [date, setDate] = useState('');
  const [fees, setFees] = useState(500);
  const [supervisorId, setSupervisorId] = useState('');
  const [siblingDiscountType, setSiblingDiscountType] = useState<'none' | 'second_free' | 'third_free' | 'custom_prices'>('none');
  const [twoBrothersFees, setTwoBrothersFees] = useState(15000);
  const [threeBrothersFees, setThreeBrothersFees] = useState(22000);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const docRef = await addDoc(collection(db, 'festivals'), {
      name, 
      date, 
      fees: Number(fees), 
      isOpen: true, 
      supervisorId,
      siblingDiscountType,
      twoBrothersFees: Number(twoBrothersFees),
      threeBrothersFees: Number(threeBrothersFees)
    });
    
    if (supervisorId) {
      await updateDoc(doc(db, 'users', supervisorId), { assignedFestivalId: docRef.id });
    }
    
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="bg-white w-full max-w-md p-8 rounded-[2.5rem] shadow-2xl overflow-y-auto max-h-[90vh]">
        <h3 className="text-2xl font-black text-slate-900 mb-6">إضافة مهرجان جديد</h3>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-xs font-black text-slate-400 mb-2">اسم المهرجان</label>
            <input type="text" value={name} onChange={e => setName(e.target.value)} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500" required />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-black text-slate-400 mb-2">التاريخ</label>
              <input type="date" value={date} onChange={e => setDate(e.target.value)} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500" required />
            </div>
            <div>
              <label className="block text-xs font-black text-slate-400 mb-2">رسوم الاشتراك</label>
              <input type="number" value={fees} onChange={e => setFees(Number(e.target.value))} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500" required />
            </div>
          </div>
          <div>
            <label className="block text-xs font-black text-slate-400 mb-2">المشرف المسؤول</label>
            <select value={supervisorId} onChange={e => setSupervisorId(e.target.value)} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500">
              <option value="">اختر مشرفاً...</option>
              {supervisors.map((s: any, i: number) => (
                <option key={`${s.id || `s-${i}`}-${i}`} value={s.id}>{s.email}</option>
              ))}
            </select>
          </div>

          <div className="border-t border-slate-100 pt-4 space-y-4">
            <div>
              <label className="block text-xs font-black text-slate-400 mb-2 font-black text-emerald-600">نظام رسوم/خصم الإخوة</label>
              <select 
                value={siblingDiscountType} 
                onChange={e => setSiblingDiscountType(e.target.value as any)} 
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 font-bold text-slate-700"
              >
                <option value="none">لا يوجد خصم (الرسوم كاملة لكل أخ)</option>
                <option value="second_free">الأخ الثاني مجاناً</option>
                <option value="third_free">الأخ الثالث مجاناً</option>
                <option value="custom_prices">رسوم مخصصة للمجموعات الأخوية</option>
              </select>
            </div>

            {siblingDiscountType === 'custom_prices' && (
              <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-black text-slate-400 mb-2">رسوم الأخوين معاً</label>
                  <input type="number" value={twoBrothersFees} onChange={e => setTwoBrothersFees(Number(e.target.value))} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 font-bold" required />
                </div>
                <div>
                  <label className="block text-xs font-black text-slate-400 mb-2">رسوم الثلاثة إخوة معاً</label>
                  <input type="number" value={threeBrothersFees} onChange={e => setThreeBrothersFees(Number(e.target.value))} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 font-bold" required />
                </div>
              </motion.div>
            )}
          </div>

          <div className="flex gap-4 pt-4">
            <button type="button" onClick={onClose} className="flex-1 py-3 font-bold text-slate-500 hover:bg-slate-50 rounded-xl transition">إلغاء</button>
            <button type="submit" className="flex-1 py-3 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-700 transition shadow-lg shadow-emerald-100">إضافة</button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}

function EditSupervisorModal({ supervisor, onClose, festivals, showToast }: any) {
  const [email, setEmail] = useState(supervisor.email || '');
  const [displayName, setDisplayName] = useState(supervisor.displayName || '');
  const [phone, setPhone] = useState(supervisor.phone || '');
  const [password, setPassword] = useState(supervisor.password || '');
  const [assignedFestivalId, setAssignedFestivalId] = useState(supervisor.assignedFestivalId || '');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const normalizedEmail = email.toLowerCase().trim();
      const normalizedPassword = password.trim();

      if (normalizedPassword && normalizedPassword.length < 6) {
        throw new Error('كلمة المرور يجب أن لا تقل عن 6 خانات');
      }

      showToast('جاري حفظ البيانات وتحديث خوادم الدخول...', 'success');
      
      // Sync with Auth (Admin feature to allow changing passwords)
      const syncRes = await fetch('/api/sync-user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          email: normalizedEmail, 
          password: normalizedPassword,
          oldPassword: supervisor.password, // Original password from before update
          displayName 
        })
      });

      if (!syncRes.ok) {
        const err = await syncRes.json();
        throw new Error(err.error || 'فشل مزامنة بيانات الدخول');
      }

      const syncData = await syncRes.json();
      
      if (syncData.code === 'SYNC_NEEDED') {
        showToast(syncData.message, 'error');
      }

      const supervisorData = { 
        email: normalizedEmail, 
        displayName, 
        phone, 
        password: normalizedPassword,
        assignedFestivalId,
        uid: syncData.uid,
        role: 'supervisor'
      };
      
      // Update Firestore
      await updateDoc(doc(db, 'users', supervisor.id), supervisorData);
      
      // If doc ID was email and email changed, we should probably move it, but keeping it simple for now as updateDoc works.
      
      showToast('تم تحديث بيانات المشرف بنجاح');

      if (assignedFestivalId) {
        await updateDoc(doc(db, 'festivals', assignedFestivalId), { supervisorId: supervisor.id });
      }

      onClose();
    } catch (error: any) {
      console.error('Error updating supervisor:', error);
      showToast(error.message || 'حدث خطأ أثناء تحديث بيانات المشرف', 'error');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="bg-white w-full max-w-md p-8 rounded-[2.5rem] shadow-2xl">
        <h3 className="text-2xl font-black text-slate-900 mb-6">تعديل بيانات المشرف</h3>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-xs font-black text-slate-400 mb-2">الاسم الكامل</label>
            <input type="text" value={displayName} onChange={e => setDisplayName(e.target.value)} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500" required />
          </div>
          <div>
            <label className="block text-xs font-black text-slate-400 mb-2">رقم الجوال</label>
            <input type="tel" value={phone} onChange={e => setPhone(e.target.value)} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500" required />
          </div>
          <div>
            <label className="block text-xs font-black text-slate-400 mb-2">البريد الإلكتروني</label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500" required />
          </div>
          <div>
            <label className="block text-xs font-black text-slate-400 mb-2">كلمة المرور</label>
            <input type="text" value={password} onChange={e => setPassword(e.target.value)} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500" placeholder="أدخل كلمة المرور..." />
          </div>
          <div>
            <label className="block text-xs font-black text-slate-400 mb-2">المهرجان المخصص</label>
            <select value={assignedFestivalId} onChange={e => setAssignedFestivalId(e.target.value)} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500">
              <option value="">اختر مهرجاناً...</option>
              {festivals.map((f: any, i: number) => (
                <option key={`edit-sup-fest-${f.id || i}-${i}`} value={f.id}>{f.name}</option>
              ))}
            </select>
          </div>
          <div className="flex gap-4 pt-4">
            <button type="button" onClick={onClose} className="flex-1 py-3 font-bold text-slate-500 hover:bg-slate-50 rounded-xl transition">إلغاء</button>
            <button type="submit" className="flex-1 py-3 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-700 transition shadow-lg shadow-emerald-100">حفظ التغييرات</button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}

function AddSupervisorModal({ onClose, festivals, showToast }: any) {
  const [email, setEmail] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [assignedFestivalId, setAssignedFestivalId] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const normalizedEmail = email.toLowerCase().trim();
      const normalizedPassword = password.trim();

      if (!normalizedPassword || normalizedPassword.length < 6) {
        throw new Error('كلمة المرور مطلوبة للمشرف الجديد ويجب أن لا تقل عن 6 خانات');
      }

      showToast('جاري إنشاء الحساب ومزامنة البيانات...', 'success');
      
      // Sync with Auth (Create or Update)
      const syncRes = await fetch('/api/sync-user', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          email: normalizedEmail, 
          password: normalizedPassword,
          displayName 
        })
      });

      if (!syncRes.ok) {
        const err = await syncRes.json();
        throw new Error(err.error || 'فشل إنشاء حساب الدخول');
      }

      const syncData = await syncRes.json();

      if (syncData.code === 'SYNC_NEEDED') {
        showToast(syncData.message, 'error');
      }

      const q = query(collection(db, 'users'), where('email', '==', normalizedEmail));
      const snap = await getDocs(q);
      let supervisorDocId = '';
      
      const supervisorData = { 
        email: normalizedEmail, 
        displayName, 
        phone, 
        password: normalizedPassword,
        role: 'supervisor', 
        assignedFestivalId,
        uid: syncData.uid
      };
      
      if (!snap.empty) {
        supervisorDocId = snap.docs[0].id;
        await updateDoc(doc(db, 'users', supervisorDocId), supervisorData);
        showToast('تم تحديث بيانات المشرف بنجاح');
      } else {
        // Use the auth UID as the document ID for new users
        await setDoc(doc(db, 'users', syncData.uid), supervisorData);
        supervisorDocId = syncData.uid;
        showToast('تم إضافة المشرف بنجاح');
      }

      if (assignedFestivalId) {
        await updateDoc(doc(db, 'festivals', assignedFestivalId), { supervisorId: supervisorDocId });
      }

      onClose();
    } catch (error: any) {
      console.error('Error adding supervisor:', error);
      showToast(error.message || 'حدث خطأ أثناء إضافة المشرف', 'error');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="bg-white w-full max-w-md p-8 rounded-[2.5rem] shadow-2xl">
        <h3 className="text-2xl font-black text-slate-900 mb-6">إضافة مشرف جديد</h3>
        <p className="text-xs text-slate-400 font-bold mb-6">أدخل البريد الإلكتروني للمشرف. يمكن للمشرف تسجيل الدخول باستخدام البريد الإلكتروني وكلمة المرور الخاصة به.</p>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-xs font-black text-slate-400 mb-2">الاسم الكامل</label>
            <input type="text" value={displayName} onChange={e => setDisplayName(e.target.value)} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500" required />
          </div>
          <div>
            <label className="block text-xs font-black text-slate-400 mb-2">رقم الجوال</label>
            <input type="tel" value={phone} onChange={e => setPhone(e.target.value)} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500" required />
          </div>
          <div>
            <label className="block text-xs font-black text-slate-400 mb-2">البريد الإلكتروني</label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500" required />
          </div>
          <div>
            <label className="block text-xs font-black text-slate-400 mb-2">كلمة المرور</label>
            <input type="text" value={password} onChange={e => setPassword(e.target.value)} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500" required placeholder="أدخل كلمة المرور..." />
          </div>
          <div>
            <label className="block text-xs font-black text-slate-400 mb-2">المهرجان المخصص</label>
            <select value={assignedFestivalId} onChange={e => setAssignedFestivalId(e.target.value)} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500">
              <option value="">اختر مهرجاناً...</option>
              {festivals.map((f: any, i: number) => (
                <option key={`add-sup-fest-${f.id || i}-${i}`} value={f.id}>{f.name}</option>
              ))}
            </select>
          </div>
          <div className="flex gap-4 pt-4">
            <button type="button" onClick={onClose} className="flex-1 py-3 font-bold text-slate-500 hover:bg-slate-50 rounded-xl transition">إلغاء</button>
            <button type="submit" className="flex-1 py-3 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-700 transition shadow-lg shadow-emerald-100">إضافة</button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}

function SocialMediaModal({ festival, onClose, onUpdate }: { festival: any, onClose: () => void, onUpdate: (id: string, field: string, value: string) => Promise<void> }) {
  const [links, setLinks] = useState<Record<string, string>>({
    phone: festival.phone || '',
    phone2: festival.phone2 || '',
    whatsapp: festival.whatsapp || '',
    whatsapp2: festival.whatsapp2 || '',
    website: festival.website || '',
    instagram: festival.instagram || '',
    xLink: festival.xLink || '',
    facebook: festival.facebook || '',
    snapchat: festival.snapchat || '',
    tiktok: festival.tiktok || '',
    youtube: festival.youtube || '',
    telegram: festival.telegram || ''
  });

  const handleChange = (field: string, value: string) => {
    setLinks(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = async () => {
    for (const [field, value] of Object.entries(links)) {
      if (value !== (festival[field as keyof any] || '')) {
        await onUpdate(festival.id, field, value as string);
      }
    }
    onClose();
  };

  const socialFields = [
    { id: 'phone', label: 'رقم الاتصال الأول', icon: <Phone size={18} />, placeholder: '05xxxxxxxx' },
    { id: 'phone2', label: 'رقم الاتصال الثاني', icon: <Phone size={18} />, placeholder: '05xxxxxxxx' },
    { id: 'whatsapp', label: 'واتساب الأول', icon: <MessageCircle size={18} />, placeholder: '9665xxxxxxxx' },
    { id: 'whatsapp2', label: 'واتساب الثاني', icon: <MessageCircle size={18} />, placeholder: '9665xxxxxxxx' },
    { id: 'website', label: 'الموقع الإلكتروني', icon: <Globe size={18} />, placeholder: 'https://...' },
    { id: 'instagram', label: 'انستقرام', icon: <Instagram size={18} />, placeholder: 'اسم المستخدم' },
    { id: 'xLink', label: 'منصة X', icon: <Twitter size={18} />, placeholder: 'اسم المستخدم' },
    { id: 'facebook', label: 'فيسبوك', icon: <Facebook size={18} />, placeholder: 'رابط الصفحة' },
    { id: 'snapchat', label: 'سناب شات', icon: <Ghost size={18} />, placeholder: 'اسم المستخدم' },
    { id: 'tiktok', label: 'تيك توك', icon: <Video size={18} />, placeholder: 'اسم المستخدم' },
    { id: 'youtube', label: 'يوتيوب', icon: <Youtube size={18} />, placeholder: 'رابط القناة' },
    { id: 'telegram', label: 'تيلجرام', icon: <Send size={18} />, placeholder: 'اسم المستخدم أو الرابط' },
  ];

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }} 
        animate={{ scale: 1, opacity: 1 }} 
        className="bg-white w-full max-w-2xl p-8 rounded-[2.5rem] shadow-2xl max-h-[90vh] overflow-y-auto"
      >
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-emerald-100 text-emerald-600 rounded-2xl">
              <Share2 size={24} />
            </div>
            <div>
              <h3 className="text-2xl font-black text-slate-900">روابط التواصل</h3>
              <p className="text-sm font-bold text-slate-400">{festival.name}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-xl transition text-slate-400">
            <X size={24} />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {socialFields.map((field, i) => (
            <div key={`${field.id || `field-${i}`}-${i}`} className="space-y-2">
              <label className="flex items-center gap-2 text-xs font-black text-slate-400 uppercase tracking-wider">
                {field.icon}
                {field.label}
              </label>
              <input 
                type="text" 
                value={links[field.id as keyof typeof links]} 
                onChange={(e) => handleChange(field.id, e.target.value)}
                placeholder={field.placeholder}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 font-bold text-slate-700 transition-all"
              />
            </div>
          ))}
        </div>

        <div className="flex gap-4 mt-10">
          <button 
            onClick={onClose} 
            className="flex-1 py-4 font-bold text-slate-500 hover:bg-slate-50 rounded-2xl transition"
          >
            إلغاء
          </button>
          <button 
            onClick={handleSave} 
            className="flex-1 py-4 bg-emerald-600 text-white font-bold rounded-2xl hover:bg-emerald-700 transition shadow-lg shadow-emerald-100 flex items-center justify-center gap-2"
          >
            <CheckCircle size={20} />
            حفظ الروابط
          </button>
        </div>
      </motion.div>
    </div>
  );
}

function AddTestimonialModal({ onClose, editingTestimonial }: { onClose: () => void, editingTestimonial?: any }) {
  const [coupleName, setCoupleName] = useState(editingTestimonial?.coupleName || '');
  const [story, setStory] = useState(editingTestimonial?.story || '');
  const [isActive, setIsActive] = useState(editingTestimonial ? editingTestimonial.isActive : true);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!coupleName || !story) return;

    const data = {
      coupleName,
      story,
      isActive,
      updatedAt: serverTimestamp()
    };

    if (editingTestimonial) {
      await updateDoc(doc(db, 'testimonials', editingTestimonial.id), data);
    } else {
      await addDoc(collection(db, 'testimonials'), {
        ...data,
        createdAt: serverTimestamp()
      });
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="bg-white w-full max-w-md p-8 rounded-[2.5rem] shadow-2xl">
        <h3 className="text-2xl font-black text-slate-900 mb-6">{editingTestimonial ? 'تعديل قصة نجاح' : 'إضافة قصة نجاح'}</h3>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-xs font-black text-slate-400 mb-2">اسم الزوجين (أو العائلة)</label>
            <input type="text" value={coupleName} onChange={e => setCoupleName(e.target.value)} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500" placeholder="مثال: أحمد وسارة" required />
          </div>
          <div>
            <label className="block text-xs font-black text-slate-400 mb-2">قصة النجاح</label>
            <textarea value={story} onChange={e => setStory(e.target.value)} rows={5} className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 resize-none" placeholder="اكتب تجربة الأزواج هنا..." required />
          </div>
          <div className="flex items-center gap-3">
            <input type="checkbox" id="isActive" checked={isActive} onChange={e => setIsActive(e.target.checked)} className="w-5 h-5 rounded text-emerald-600 focus:ring-emerald-500" />
            <label htmlFor="isActive" className="text-sm font-bold text-slate-700">عرض في الصفحة الرئيسية</label>
          </div>
          <div className="flex gap-4 pt-4">
            <button type="button" onClick={onClose} className="flex-1 py-3 font-bold text-slate-500 hover:bg-slate-50 rounded-xl transition">إلغاء</button>
            <button type="submit" className="flex-1 py-3 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-700 transition shadow-lg shadow-emerald-100">{editingTestimonial ? 'حفظ التعديلات' : 'إضافة'}</button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}

function AttachmentViewerModal({ attachment, onClose }: { attachment: { url: string, type: string, name: string }, onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/90 backdrop-blur-sm" onClick={onClose}>
      <motion.div 
        initial={{ scale: 0.95, opacity: 0 }} 
        animate={{ scale: 1, opacity: 1 }} 
        className="relative w-full max-w-5xl max-h-[90vh] flex flex-col bg-white dark:bg-slate-900 rounded-3xl overflow-hidden shadow-2xl"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between p-4 border-b border-slate-100 dark:border-slate-800">
          <h3 className="font-black text-slate-900 dark:text-white truncate pr-4">{attachment.name}</h3>
          <div className="flex items-center gap-2">
            <a 
              href={attachment.url} 
              target="_blank" 
              rel="noreferrer" 
              className="p-2 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-xl hover:bg-blue-100 dark:hover:bg-blue-900/40 transition-colors"
              title="فتح في نافذة جديدة"
            >
              <ExternalLink size={20} />
            </a>
            <a 
              href={attachment.url} 
              target="_blank" 
              rel="noreferrer" 
              download={attachment.name}
              className="p-2 bg-brand-50 dark:bg-brand-900/20 text-brand-600 dark:text-brand-400 rounded-xl hover:bg-brand-100 dark:hover:bg-brand-900/40 transition-colors"
              title="تحميل"
            >
              <Download size={20} />
            </a>
            <button onClick={onClose} className="p-2 bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 rounded-xl hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors">
              <X size={20} />
            </button>
          </div>
        </div>
        <div className="flex-1 overflow-auto bg-slate-100/50 dark:bg-slate-950 p-4 flex items-center justify-center min-h-[50vh]">
          {attachment.type.includes('pdf') ? (
            <iframe src={attachment.url} className="w-full h-[70vh] rounded-xl border-0" title={attachment.name} />
          ) : (
            <img src={attachment.url} alt={attachment.name} className="max-w-full max-h-[75vh] object-contain rounded-xl" referrerPolicy="no-referrer" />
          )}
        </div>
      </motion.div>
    </div>
  );
}

function ToastItem({ toast, onDismiss }: { key?: any; toast: any; onDismiss: () => void }) {
  useEffect(() => {
    const timer = setTimeout(() => {
      onDismiss();
    }, 6000);
    return () => clearTimeout(timer);
  }, [onDismiss]);

  return (
    <motion.div
      initial={{ opacity: 0, x: -100, scale: 0.9 }}
      animate={{ opacity: 1, x: 0, scale: 1 }}
      exit={{ opacity: 0, x: -100, scale: 0.9 }}
      className="bg-white dark:bg-slate-900 border-l-4 border-emerald-500 dark:border-emerald-400 shadow-2xl rounded-2xl p-4 flex gap-4 w-80 pointer-events-auto border border-slate-100 dark:border-slate-850 backdrop-blur-md relative overflow-hidden group"
    >
      <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 rounded-full -mr-8 -mt-8 transition-transform duration-500 group-hover:scale-125" />
      
      <div className="w-10 h-10 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 rounded-xl flex items-center justify-center shrink-0 self-start shadow-sm relative">
        <div className="absolute inset-0 bg-emerald-500/20 rounded-xl animate-ping opacity-30" />
        <Bell size={18} className="animate-pulse" />
      </div>

      <div className="flex-1">
        <h4 className="font-sans font-black text-xs text-slate-900 dark:text-white leading-tight mb-1 text-right">
          تسجيل طلب جديد في المهرجان!
        </h4>
        <p className="text-[11px] font-sans font-bold text-slate-705 dark:text-slate-300 text-right">
          قام العريس <span className="text-emerald-600 dark:text-emerald-400 font-extrabold">{toast.groomName}</span> بالتسجيل.
        </p>
        {toast.festivalName && (
          <div className="mt-2 flex items-center justify-end gap-1.5">
            <span className="text-[9px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 px-2 py-0.5 rounded-full">
              {toast.festivalName}
            </span>
          </div>
        )}
      </div>

      <button
        onClick={onDismiss}
        className="text-slate-400 hover:text-slate-605 dark:hover:text-slate-200 transition p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 h-fit self-start shrink-0"
      >
        <X size={14} />
      </button>
    </motion.div>
  );
}

function ReminderModal({ registrations, onClose, onSendWhatsApp }: { registrations: any[], onClose: () => void, onSendWhatsApp: (reg: any) => void }) {
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }} 
        animate={{ scale: 1, opacity: 1 }} 
        className="bg-white w-full max-w-4xl p-8 rounded-[2.5rem] shadow-2xl flex flex-col max-h-[90vh]"
      >
        <div className="flex justify-between items-center mb-6">
          <div>
            <h3 className="text-2xl font-black text-slate-900">تذكير المتأخرين ({registrations.length})</h3>
            <p className="text-sm text-slate-400 font-bold">قائمة العرسان الذين لم يكملوا بياناتهم أو السداد لأكثر من 24 ساعة</p>
          </div>
          <button onClick={onClose} className="p-2 bg-slate-100 text-slate-400 rounded-xl hover:bg-slate-200 transition">
            <X size={24} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto space-y-4 pr-1">
          {registrations.length === 0 ? (
            <div className="text-center py-20 bg-slate-50 rounded-3xl border border-slate-100">
              <CheckCircle size={48} className="mx-auto text-emerald-100 mb-4" />
              <p className="text-slate-400 font-bold">لا يوجد عرسان متأخرين حالياً. جميع الطلبات محدثة!</p>
            </div>
          ) : (
            registrations.map((reg, i) => (
              <div key={`remind-reg-${reg.id || i}-${i}`} className="flex flex-col sm:flex-row items-center justify-between p-5 bg-slate-50 border border-slate-100 rounded-2xl gap-4 hover:border-emerald-200 transition-all group">
                <div className="flex items-center gap-4 w-full sm:w-auto">
                  <div className="w-12 h-12 bg-white rounded-xl border border-slate-200 flex items-center justify-center text-slate-400 font-black shrink-0 relative text-lg">
                     {i + 1}
                  </div>
                  <div className="min-w-0">
                    <h4 className="font-black text-slate-900 truncate">{reg.groomName}</h4>
                    <div className="flex flex-wrap gap-2 mt-1">
                      <span className="text-[10px] font-bold bg-white px-2 py-0.5 rounded-full border border-slate-200 text-slate-500">
                         {reg.festivalName}
                      </span>
                      <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                        reg.status === 'pending' ? 'bg-amber-100 text-amber-600' : 
                        reg.status === 'needs_info' ? 'bg-blue-100 text-blue-600' :
                        'bg-slate-200 text-slate-500'
                      }`}>
                         {reg.status === 'pending' ? 'قيد المراجعة' : reg.status === 'needs_info' ? 'بانتظار إكمال البيانات' : reg.status}
                      </span>
                      {(!reg.paymentStatus || reg.paymentStatus === 'pending') && (
                        <span className="text-[10px] font-black bg-red-100 text-red-600 px-2 py-0.5 rounded-full">
                           بانتظار السداد
                        </span>
                      )}
                      <span className="text-[10px] font-bold text-slate-400 flex items-center gap-1">
                        <Clock size={10} />
                        منذ: {reg.createdAt?.toDate ? format(reg.createdAt.toDate(), 'yyyy/MM/dd') : 'غير محدد'}
                      </span>
                    </div>
                  </div>
                </div>
                
                <div className="flex gap-2 w-full sm:w-auto">
                   <button 
                    onClick={() => onSendWhatsApp(reg)}
                    className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-6 py-3 bg-emerald-600 text-white rounded-xl font-bold text-sm hover:bg-emerald-700 transition shadow-lg shadow-emerald-100"
                   >
                     <Phone size={18} /> تذكير واتساب
                   </button>
                </div>
              </div>
            ))
          )}
        </div>

        {registrations.length > 0 && (
           <div className="mt-8 p-4 bg-emerald-50 rounded-2xl border border-emerald-100 flex items-center gap-3">
             <div className="w-10 h-10 bg-emerald-100 text-emerald-600 rounded-xl flex items-center justify-center shrink-0">
               <Bell size={20} />
             </div>
             <p className="text-xs font-bold text-emerald-800 leading-relaxed">
               تذكير: يتم إرسال الرسائل يدوياً عبر فتح رابط الواتساب لكل عريس. يرجى التأكد من إتمام العملية لكل شخص في القائمة.
             </p>
           </div>
        )}
      </motion.div>
    </div>
  );
}
