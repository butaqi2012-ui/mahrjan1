import React, { useState, useEffect } from 'react';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import { Users, CheckCircle, Clock, XCircle } from 'lucide-react';
import { cache } from '../utils/cache';

enum OperationType {
  GET = 'get',
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  console.error(`Firestore Error [${operationType}] at ${path}:`, error);
}

export function PublicStats() {
  const [stats, setStats] = useState({ total: 0, approved: 0, pending: 0, rejected: 0 });

  useEffect(() => {
    const cachedStats = cache.get<any>('public_stats');
    if (cachedStats) {
      setStats(cachedStats);
    }

    const unsub = onSnapshot(doc(db, 'public_stats', 'global'), (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data() as any;
        setStats(data);
        cache.set('public_stats', data);
      }
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, 'public_stats/global');
    });
    return () => unsub();
  }, []);

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
      <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-blue-50 text-blue-500 flex items-center justify-center shrink-0">
          <Users size={20} />
        </div>
        <div>
          <p className="text-[10px] font-bold text-slate-400 mb-0.5">إجمالي المسجلين</p>
          <h4 className="text-xl font-black text-slate-800">{stats.total}</h4>
        </div>
      </div>
      <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-emerald-50 text-emerald-500 flex items-center justify-center shrink-0">
          <CheckCircle size={20} />
        </div>
        <div>
          <p className="text-[10px] font-bold text-slate-400 mb-0.5">الطلبات المقبولة</p>
          <h4 className="text-xl font-black text-slate-800">{stats.approved}</h4>
        </div>
      </div>
      <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-amber-50 text-amber-500 flex items-center justify-center shrink-0">
          <Clock size={20} />
        </div>
        <div>
          <p className="text-[10px] font-bold text-slate-400 mb-0.5">قيد المراجعة</p>
          <h4 className="text-xl font-black text-slate-800">{stats.pending}</h4>
        </div>
      </div>
      <div className="bg-white p-4 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-red-50 text-red-500 flex items-center justify-center shrink-0">
          <XCircle size={20} />
        </div>
        <div>
          <p className="text-[10px] font-bold text-slate-400 mb-0.5">الطلبات المرفوضة</p>
          <h4 className="text-xl font-black text-slate-800">{stats.rejected}</h4>
        </div>
      </div>
    </div>
  );
}
