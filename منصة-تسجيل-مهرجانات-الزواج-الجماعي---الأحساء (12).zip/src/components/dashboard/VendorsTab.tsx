import React, { useState } from 'react';
import { Plus, Edit, Trash2, Gift, Tag, Phone, MapPin, Search, X, Check, Eye, XCircle } from 'lucide-react';
import { collection, addDoc, updateDoc, deleteDoc, doc } from 'firebase/firestore';
import { db, auth } from '../../firebase';
import { motion, AnimatePresence } from 'motion/react';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

const handleFirestoreError = (error: unknown, operationType: OperationType, path: string | null) => {
  const errorMessage = error instanceof Error ? error.message : String(error);
  
  const errInfo: FirestoreErrorInfo = {
    error: errorMessage,
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };

  // Handle specific "soft" errors
  if (errorMessage.includes('No document to update')) {
    console.warn('Firestore Warning (Soft): ', JSON.stringify(errInfo));
    return; // Don't throw for missing documents during updates
  }

  console.error('Firestore Error in VendorsTab: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
};

interface Vendor {
  id?: string;
  name: string;
  category: string;
  categoryLabel: string;
  discount: string;
  desc: string;
  code: string;
  phone: string;
  address: string;
  createdAt?: string;
}

interface VendorsTabProps {
  vendors: Vendor[];
  userProfile: {
    role: string;
    [key: string]: any;
  };
}

export function VendorsTab({ vendors, userProfile }: VendorsTabProps) {
  const [vendorQuery, setVendorQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingVendor, setEditingVendor] = useState<Vendor | null>(null);
  
  // Form fields state
  const [name, setName] = useState('');
  const [category, setCategory] = useState('halls');
  const [discount, setDiscount] = useState('');
  const [desc, setDesc] = useState('');
  const [code, setCode] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Delete confirm state
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const categories = [
    { id: 'halls', label: 'قاعات الأفراح' },
    { id: 'hospitality_teams', label: 'فرق ضيافة وتجهيز' },
    { id: 'furniture', label: 'الأثاث والأجهزة الكهربائية' },
    { id: 'catering', label: 'المطابخ والضيافة' },
    { id: 'photography', label: 'استوديوهات التصوير' },
    { id: 'hotels', label: 'فنادق وشهر العسل' }
  ];

  const getCategoryLabel = (catId: string) => {
    const found = categories.find(c => c.id === catId);
    return found ? found.label : 'أخرى';
  };

  const openAddModal = () => {
    setEditingVendor(null);
    setName('');
    setCategory('halls');
    setDiscount('');
    setDesc('');
    setCode('');
    setPhone('');
    setAddress('');
    setError('');
    setIsModalOpen(true);
  };

  const openEditModal = (vendor: Vendor) => {
    setEditingVendor(vendor);
    setName(vendor.name);
    setCategory(vendor.category);
    setDiscount(vendor.discount);
    setDesc(vendor.desc);
    setCode(vendor.code);
    setPhone(vendor.phone);
    setAddress(vendor.address);
    setError('');
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !discount || !desc || !code || !phone || !address) {
      setError('يرجى تعبئة جميع الحقول المطلوبة');
      return;
    }

    setIsSubmitting(true);
    setError('');

    const vendorData = {
      name,
      category,
      categoryLabel: getCategoryLabel(category),
      discount,
      desc,
      code: code.trim().toUpperCase(),
      phone: phone.trim(),
      address,
      createdAt: editingVendor?.createdAt || new Date().toISOString()
    };

    try {
      if (editingVendor?.id) {
        // Edit existing
        const docRef = doc(db, 'vendors', editingVendor.id);
        await updateDoc(docRef, vendorData);
      } else {
        // Add new
        await addDoc(collection(db, 'vendors'), vendorData);
      }
      setIsModalOpen(false);
    } catch (err: any) {
      console.error('Error saving vendor:', err);
      setError('حدث خطأ غير متوقع أثناء حفظ البيانات');
      handleFirestoreError(err, editingVendor?.id ? OperationType.UPDATE : OperationType.CREATE, editingVendor?.id ? `vendors/${editingVendor.id}` : 'vendors');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'vendors', id));
      setDeleteConfirmId(null);
    } catch (err) {
      console.error('Error deleting vendor:', err);
      handleFirestoreError(err, OperationType.DELETE, `vendors/${id}`);
    }
  };

  // Filter vendors
  const filteredVendors = vendors.filter(v => {
    const matchesCategory = selectedCategory === 'all' || v.category === selectedCategory;
    const matchesQuery = 
      v.name.toLowerCase().includes(vendorQuery.toLowerCase()) || 
      v.desc.toLowerCase().includes(vendorQuery.toLowerCase()) ||
      v.code.toLowerCase().includes(vendorQuery.toLowerCase()) ||
      v.address.toLowerCase().includes(vendorQuery.toLowerCase());
    return matchesCategory && matchesQuery;
  });

  return (
    <div className="p-4 sm:p-8">
      {/* Tab Header */}
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4 mb-8">
        <div>
          <h3 className="text-xl sm:text-2xl font-black text-slate-900">إدارة شركاء النجاح والخصومات</h3>
          <p className="text-xs sm:text-sm text-slate-400 font-bold mt-1">التحكم في كوبونات الخصم والخدمات المقدمة للعرسان بعد قبول طلباتهم</p>
        </div>
        {userProfile.role === 'admin' && (
          <button 
            onClick={openAddModal} 
            className="bg-emerald-600 text-white px-5 py-2.5 rounded-xl font-bold text-sm sm:text-base flex items-center justify-center gap-2 hover:bg-emerald-700 transition shadow-md active:scale-95"
          >
            <Plus size={18} />
            إضافة شريك/عرض جديد
          </button>
        )}
      </div>

      {/* Filter and search bars */}
      <div className="bg-slate-50 dark:bg-slate-900/40 p-5 rounded-2xl border border-slate-100 dark:border-slate-800 mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <span className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400">
            <Search size={18} />
          </span>
          <input 
            type="text" 
            value={vendorQuery}
            onChange={(e) => setVendorQuery(e.target.value)}
            placeholder="ابحث باسم الشريك، كود الخصم، أو العرض الكوبون..."
            className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl pr-11 pl-4 py-2.5 text-sm sm:text-base text-slate-900 dark:text-white font-bold focus:ring-2 focus:ring-emerald-500 outline-none transition"
          />
          {vendorQuery && (
            <button 
              onClick={() => setVendorQuery('')}
              className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
            >
              <X size={16} />
            </button>
          )}
        </div>

        {/* Categories Tabs */}
        <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-hide shrink-0 max-w-full">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-3.5 py-2 rounded-lg text-xs font-black transition whitespace-nowrap ${
              selectedCategory === 'all' 
                ? 'bg-emerald-600 text-white' 
                : 'bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-400 border border-slate-100 dark:border-slate-700 hover:bg-slate-50'
            }`}
          >
            كل الشركاء ({vendors.length})
          </button>
          {categories.map((cat) => {
            const count = vendors.filter(v => v.category === cat.id).length;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3.5 py-2 rounded-lg text-xs font-black transition whitespace-nowrap ${
                  selectedCategory === cat.id 
                    ? 'bg-emerald-600 text-white' 
                    : 'bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-400 border border-slate-100 dark:border-slate-700 hover:bg-slate-50'
                }`}
              >
                {cat.label} ({count})
              </button>
            );
          })}
        </div>
      </div>

      {/* Grid List */}
      {filteredVendors.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredVendors.map((vendor) => (
            <div 
              key={vendor.id}
              className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 hover:shadow-md transition flex flex-col justify-between overflow-hidden relative group"
            >
              <div className="p-5 space-y-4">
                {/* Header elements */}
                <div className="flex justify-between items-start gap-2">
                  <span className="px-2 py-0.5 bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 rounded text-xs font-bold shrink-0">
                    {vendor.categoryLabel}
                  </span>
                  <div className="flex items-center gap-1 px-2.5 py-0.5 bg-rose-50 text-rose-600 rounded-full font-black text-xs sm:text-sm">
                    <Tag size={12} />
                    {vendor.discount}
                  </div>
                </div>

                {/* Body elements */}
                <div>
                  <h4 className="font-black text-slate-900 dark:text-white text-base sm:text-lg mb-1.5 leading-snug group-hover:text-emerald-600 transition-colors">
                    {vendor.name}
                  </h4>
                  <p className="text-slate-500 dark:text-slate-400 text-sm font-semibold leading-relaxed line-clamp-3">
                    {vendor.desc}
                  </p>
                </div>

                {/* Details layout */}
                <div className="space-y-1.5 pt-3 border-t border-slate-50 dark:border-slate-700 text-xs font-bold text-slate-400">
                  <div className="flex items-center gap-2">
                    <MapPin size={11} className="text-slate-300 shrink-0" />
                    <span className="text-slate-500 dark:text-slate-300 truncate">{vendor.address}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone size={11} className="text-slate-300 shrink-0" />
                    <span className="font-mono text-slate-500 dark:text-slate-300 inline-block dir-ltr">{vendor.phone}</span>
                  </div>
                </div>
              </div>

              {/* Action layout */}
              <div className="bg-slate-50 dark:bg-slate-900/50 px-5 py-3 border-t border-slate-100 dark:border-slate-700 flex items-center justify-between gap-4">
                <div className="flex items-center gap-1 bg-white dark:bg-slate-800 px-2 py-1 rounded-lg border border-slate-100 dark:border-slate-700 text-xs font-black text-slate-700 dark:text-slate-200">
                  <span className="text-slate-400 text-[11px] font-bold ml-1">الكود:</span>
                  <span className="font-mono">{vendor.code}</span>
                </div>
                
                {userProfile.role === 'admin' && (
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={() => openEditModal(vendor)}
                      className="p-1.5 text-slate-400 hover:text-emerald-600 transition"
                      title="تعديل"
                    >
                      <Edit size={16} />
                    </button>
                    <button 
                      onClick={() => setDeleteConfirmId(vendor.id || null)}
                      className="p-1.5 text-slate-400 hover:text-red-500 transition"
                      title="حذف"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-slate-50 dark:bg-slate-900/20 py-16 px-6 text-center rounded-2xl border border-dashed border-slate-200 dark:border-slate-800">
          <Gift size={48} className="mx-auto text-slate-200 dark:text-slate-700 mb-4 animate-bounce" style={{ animationDuration: '3s' }} />
          <h5 className="text-slate-800 dark:text-slate-100 font-black text-base mb-1">لا توجد عروض أو شركاء حالياً</h5>
          <p className="text-slate-400 font-bold text-xs max-w-sm mx-auto leading-relaxed">
            لم يقم النظام بتحميل أو إضافة عروض نشطة تطابق هذا الفلتر بعد. قم بإضافة أول شريك نجاح بالضغط على الزر أعلاه!
          </p>
        </div>
      )}

      {/* Confirmation modal for delete */}
      <AnimatePresence>
        {deleteConfirmId && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }} 
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-800 w-full max-w-sm p-6 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-2xl"
            >
              <div className="w-14 h-14 bg-red-50 dark:bg-red-950/20 text-red-600 dark:text-red-400 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Trash2 size={28} />
              </div>
              <h3 className="text-lg font-black text-slate-900 dark:text-white mb-2 text-center">تأكيد الحذف</h3>
              <p className="text-slate-500 dark:text-slate-400 font-bold mb-6 text-center text-xs leading-relaxed">
                هل أنت متأكد من رغبتك في حذف هذا الشريك؟ سيؤدي ذلك لإزالة التبويب والعرض نهائياً من شاشات العرسان أيضاً.
              </p>
              <div className="flex gap-3">
                <button 
                  onClick={() => handleDelete(deleteConfirmId)}
                  className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl shadow-md transition"
                >
                  حذف نهائي
                </button>
                <button 
                  onClick={() => setDeleteConfirmId(null)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 font-bold text-xs rounded-xl transition"
                >
                  إلغاء التراجع
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Add / Edit Overlay Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, y: 15 }} 
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 15 }}
              className="bg-white dark:bg-slate-800 w-full max-w-lg p-6 sm:p-8 rounded-3xl border border-slate-100 dark:border-slate-700 shadow-2xl relative my-8"
            >
              {/* Close Button */}
              <button 
                onClick={() => setIsModalOpen(false)}
                className="absolute left-6 top-6 p-1.5 rounded-lg bg-slate-50 dark:bg-slate-700 text-slate-450 hover:text-slate-700 hover:bg-slate-100 transition"
              >
                <X size={18} />
              </button>

              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-emerald-50 dark:bg-emerald-950/30 text-emerald-600 dark:text-emerald-400 rounded-xl flex items-center justify-center shrink-0">
                  <Gift size={20} />
                </div>
                <div>
                  <h4 className="text-lg font-black text-slate-900 dark:text-white">
                    {editingVendor ? 'تعديل بيانات شريك النجاح' : 'إضافة عرض وشريك نجاح جديد'}
                  </h4>
                  <p className="text-[10px] sm:text-xs text-slate-450 font-bold mt-0.5">يرجى ملء تفاصيل الشركة والعرض الترويجي بدقة</p>
                </div>
              </div>

              {error && (
                <div className="p-3 bg-red-55 border border-red-200/50 rounded-xl text-red-700 text-xs font-bold mb-4 flex items-center gap-2 leading-relaxed">
                  <XCircle className="shrink-0" size={16} />
                  <span>{error}</span>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Name */}
                <div>
                  <label className="block text-xs font-black text-slate-500 dark:text-slate-300 mb-1.5 mr-1">اسم الشريك / الشركة *</label>
                  <input 
                    type="text" 
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="مثال: مطابخ الرياض الكبرى للولائم"
                    className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-slate-900 dark:text-white font-semibold outline-none focus:ring-2 focus:ring-emerald-500 transition"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Category */}
                  <div>
                    <label className="block text-xs font-black text-slate-500 dark:text-slate-300 mb-1.5 mr-1">تصنيف النشاط *</label>
                    <select 
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-slate-900 dark:text-white font-semibold outline-none focus:ring-2 focus:ring-emerald-500 transition"
                    >
                      {categories.map(c => (
                        <option key={c.id} value={c.id}>{c.label}</option>
                      ))}
                    </select>
                  </div>

                  {/* Discount */}
                  <div>
                    <label className="block text-xs font-black text-slate-500 dark:text-slate-300 mb-1.5 mr-1">قيمة الخصم الترويجي *</label>
                    <input 
                      type="text" 
                      required
                      value={discount}
                      onChange={(e) => setDiscount(e.target.value)}
                      placeholder="مثال: 25% خصم، كوبون 500 ريال"
                      className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-slate-900 dark:text-white font-semibold outline-none focus:ring-2 focus:ring-emerald-500 transition"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Promo Code */}
                  <div>
                    <label className="block text-xs font-black text-slate-500 dark:text-slate-300 mb-1.5 mr-1">كود الخصم الحصري *</label>
                    <input 
                      type="text" 
                      required
                      value={code}
                      onChange={(e) => setCode(e.target.value)}
                      placeholder="مثال: DIYAF15"
                      className="w-full font-mono bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-slate-900 dark:text-white font-bold outline-none focus:ring-2 focus:ring-emerald-500 transition text-right"
                    />
                  </div>

                  {/* Phone */}
                  <div>
                    <label className="block text-xs font-black text-slate-500 dark:text-slate-300 mb-1.5 mr-1">رقم هاتف التواصل *</label>
                    <input 
                      type="text" 
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="مثال: 0501234567"
                      className="w-full font-mono bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-slate-900 dark:text-white font-semibold outline-none focus:ring-2 focus:ring-emerald-500 transition text-right"
                    />
                  </div>
                </div>

                {/* Address */}
                <div>
                  <label className="block text-xs font-black text-slate-500 dark:text-slate-300 mb-1.5 mr-1">الموقع والمدينة *</label>
                  <input 
                    type="text" 
                    required
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="مثال: الرياض - طريق التخصصي"
                    className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-slate-900 dark:text-white font-semibold outline-none focus:ring-2 focus:ring-emerald-500 transition"
                  />
                </div>

                {/* Desc */}
                <div>
                  <label className="block text-xs font-black text-slate-500 dark:text-slate-300 mb-1.5 mr-1">تفاصيل ومميزات العرض للمستفيد *</label>
                  <textarea 
                    value={desc}
                    required
                    onChange={(e) => setDesc(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-slate-900 dark:text-white font-semibold outline-none focus:ring-2 focus:ring-emerald-500 transition h-28 resize-none"
                    placeholder="اكتب هنا شروط الاستفادة ومميزات الباقة..."
                  />
                </div>

                <div className="flex gap-4 pt-4 border-t border-slate-100 dark:border-slate-700">
                  <button 
                    type="submit"
                    disabled={isSubmitting}
                    className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm rounded-xl transition shadow-md active:scale-95 disabled:opacity-55 flex items-center justify-center gap-2"
                  >
                    {isSubmitting ? (
                      <>
                        <div className="w-4 h-4 rounded-full border-2 border-white/30 border-t-white animate-spin" />
                        <span>جاري الحفظ والرفع...</span>
                      </>
                    ) : (
                      <>
                        <Check size={16} />
                        <span>{editingVendor ? 'تم حفظ التعديلات' : 'إضافة إلى القائمة'}</span>
                      </>
                    )}
                  </button>
                  <button 
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 dark:bg-slate-750 text-slate-700 dark:text-slate-200 font-bold text-xs sm:text-sm rounded-xl transition"
                  >
                    إلغاء التراجع
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
